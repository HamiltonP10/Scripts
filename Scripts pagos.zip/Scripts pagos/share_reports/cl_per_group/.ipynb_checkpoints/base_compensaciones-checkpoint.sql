--no_cache
with paid_lots_ini as (
select distinct pl.id as paid_lot_id
from cl_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl
left join cl_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
left join cl_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores st on st.payment_reference_id = pl.payment_reference_id and not st._fivetran_deleted
  where not PL._FIVETRAN_DELETED
  and PAY_START_DATE>='2020-03-01' 
  and pl.status<>'CANCELED'
  
)

,orders as
(
    with paid_lots as (
      select
        t.paid_lot_id,
        model_id as order_id,
        sum(amount) as compensations
      from
        cl_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
      join
        paid_lots_ini pl on pl.paid_lot_id=t.paid_lot_id
      left join
        cl_core_orders_public.orders o on o.id = t.model_id and coalesce(o._fivetran_deleted,false)=false
      left join
        cl_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores s on s.store_id = t.store_id and coalesce(s._fivetran_deleted,false)=false
      where not t._fivetran_deleted --and
        --o.created_at::date between '2019-11-01' and '2019-11-15'
        and transaction_reason_id = 18
        and coalesce(t._fivetran_deleted,false)=false
        and s.is_marketplace = false
      group by
        1,2
      having
        abs(sum(amount)) > 0
      )

      select
      os.*, pl.paid_lot_id,pl.compensations as rappicreditos_real
      from cl_core_orders_public.orders os
      inner join paid_lots pl on os.id = pl.order_id
      where not os._fivetran_deleted
  )

,t1 as (
select o.id as order_id,
paid_lot_id,
  date_trunc('week',zt.TIMESTAMP)::date as semana,
case when o.deliveryboy_id is null then o.storekeeper_id else o.deliveryboy_id end as id_rt,
--snippet JPB Tickets categoria
            case when TAGS::text like '%producto_diferente%' or  TAGS::text like '%me_trajeron_un_producto_diferente%' then 'Producto Diferente'
when TAGS::text like '%pedido_incompleto%' or  TAGS::text like  '%no_me_llego_algun_producto%' or  TAGS::text like '%missing_product%'  then 'Pedido Incompleto'
when TAGS::text like '%mal_estado%' or  TAGS::text like '%producto_llego_en_mal_estado%'  then 'Producto Mal Estado'
when TAGS::text like '%demora_pedido%' or  TAGS::text like  '%demora_de_orden%' then 'Demora'
when TAGS::text like '%problemas_rt%' or  TAGS::text like  '%tuve_problemas_con_mi_rt%' then 'Rappitendero'
when TAGS::text like '%cobraron_más%' or  TAGS::text like  '%anteriores-me_cobraron_de_mas%' then 'Cobro de más'
when TAGS::text like '%utilizar_rc%' or TAGS::text like '%rc_nocargados%' or TAGS::text like '%borraron_rc%' or  TAGS::text like '%se_me_borraron_los_rappicreditos%' or TAGS::text like '%no_aplico_rappicreditos%' then 'Rappicreditos'
when TAGS::text like '%usar_promo%' or TAGS::text like '%promo_na%' or TAGS::text like '%ingreso_cupón%' or TAGS::text like '%35min%' or  TAGS::text like  '%como_funciona_una_promocion%' or  TAGS::text like  '%no_me_aplico_35_minutos_o_gratis%' or  TAGS::text like  '%no_me_aplico_una_promocion%' or  TAGS::text like   '%no_me_aplico_un_cupon%' then 'Promociones'
when TAGS::text like '%no_puedo_hacer_pedidos%' then 'No puedo hacer Pedidos'
when TAGS::text like '%cancelación_sinaviso%' or  TAGS::text like  '%cancelaron_desaparecio_mi_pedido%' then 'Cancelacion sin aviso'
when TAGS::text like '%cobrado_nollego%' or  TAGS::text like  '%me_cobraron_y_no_llego%' then 'Cobro no llego pedido'
when TAGS::text like '%prime%' or  TAGS::text like '%no_aplico_rappiprime_en_mi_ped%'  or  TAGS::text like '%dar_de_baja_rappiprime%' then 'Prime'
when TAGS::text like '%factura%' then 'Factura'
--Categorias no incluidas
when TAGS::text like '%usar_app%' or TAGS::text like '%tengo_antojo%' or TAGS::text like '%spam_%' or TAGS::text like '%ser_rt%' or TAGS::text like '%ser_aliado%' or TAGS::text like '%opinión_importa%' or TAGS::text like '%nuestra_oferta%' or TAGS::text like '%ingreso_cupon%' or TAGS::text like '%eliminar_notificaciones%' or TAGS::text like '%configurazion_tc%' or TAGS::text like '%como_pedir%' or TAGS::text like '%como_pagar%' or TAGS::text like '%cambiar_tel%' or TAGS::text like '%cambiar_dirección%' or TAGS::text like '%como_funciona_una_rappi_favor%' or TAGS::text like '%configuracion_tc%' or TAGS::text like '%aviso_privacidad%'
or TAGS::text like '%rappi-empieza_a_usar_la_app%'
or TAGS::text like '%quiero_aparecer_en_rappi%'
or TAGS::text like '%eliminar_notificaciones_del_app%'
or TAGS::text like '%como_funciona_una_promocion%'
or TAGS::text like '%cambiar_telefono%'
or TAGS::text like '%como_puedo_pagar%'
or TAGS::text like '%tu_opinion_nos_importa%'
or TAGS::text like  '%dc.spam%'
or TAGS::text like '%como_utilizar_rappi-realiza_tu_primer%'
or TAGS::text like '%dudas_frecuentes-nuestra_cobertura%'
or TAGS::text like '%cuenta-agregar_tarjeta%'
or TAGS::text like '%dar_de_baja_cuenta%'
or TAGS::text like '%promociones-cupon_de_referido%'
or TAGS::text like '%promociones-ingresa_cupon%'
or TAGS::text like '%cuenta-cambiar_correo%'
or TAGS::text like '%mi_cuenta-agregar_direccion%' then 'Non order related'
else TAGS::text
end
        --

            categoria,
case when categoria in ('Producto Diferente','Pedido Incompleto','Producto Mal Estado') then '1' else '2' end as priority,
  stores.store_id,
  stores.store_name,
  stores.store_brand_id,
  stores.name as brandname,
 zt.USER_ID as user_id,
  --round(valor_orden.valor_orden,0) as valor_orden,
--max(round(rctos.amount,0)) as rappicreditos,
min(try_cast(zt.TICKET_ID as int))ticket_id ,
round(sum( distinct o.rappicreditos_real ),2) rappicreditos_real

from orders o
left join cl_MG_MS_REPLSET_TICKET_MANAGER.TICKETS zt on zt.order_id::text = o.id::text
left join cl_core_orders_calculated_information.orders cal on o.id = cal.order_ID

left join
(select st.store_id, st.name as store_name, st.store_brand_id, sb.name,
case when v.sub_group is null then 'Antojo' else v.sub_group end as vertical
from cl_grability_public.stores st
left join cl_grability_public.verticals v on st.type = v.store_type
left join cl_grability_public.store_brands sb on st.store_brand_id = sb.id) stores on cal.store_id = stores.store_id

/*left join cl_grability_public.rappi_credit_transaction_order_support_cms rctos on try_cast(zt.CUSTOM_ORDER_ID_OBLIGATORIO_ as int) = rctos.order_id::varchar

left join(
select o.id, o.total_value, o.total_value - coalesce(cargos, 0) + coalesce(total_charge_discount + total_order_discount, 0) + coalesce(rpd.amount, 0) + coalesce(rappicreditos, 0) as valor_orden
from orders o
left join cl_grability_public.order_discounts od on o.id = od.order_id and od._fivetran_deleted = false
left join cl_grability_public.rappi_pay_debits rpd on o.id = rpd.order_id and rpd.state = 'APPROVED' and rpd._fivetran_deleted = false
left join (
 select order_id, sum(-amount) as rappicreditos
 from cl_grability_public.rappi_credit_transactions
 where state = 'debited'
 group by order_id
)rc on o.id = rc.order_id
left join (
 select order_id, sum(value) as cargos
 from cl_grability_public.order_charges
 where _fivetran_deleted = false
 group by order_id
)oc on o.id = oc.order_id
and o._fivetran_deleted = false) valor_orden on valor_orden.id = try_cast(zt.CUSTOM_ORDER_ID_OBLIGATORIO_ as int)*/


--where zt.custom_pais in ('br')
--and stores.vertical in ('Restaurantes')


group by 1,2,3,4,5,6,7,8,9,10,11
  --,10
)

,final as (
select

-- ok.order_id,
-- ok.fecha,
-- ok.categoria,
-- ok.rappicreditos,
-- ok.tienda,
-- ok.store_id,
-- ok.description,
-- ok.product_id,
-- p.name product_name,
-- ok.product_price--,
distinct

ok.store_id,
ok.paid_lot_id,
ok.tienda,
ok.fecha,
ok.order_id,
ok.categoria,
ok.description,
p.name product_name,
ok.product_price,
ok.rappicreditos_real,
priority,
comentario

from (
select t1.order_id,
t1.paid_lot_id,
--t1.valor_orden,
o.created_at::timestamp_ntz as Fecha,
t1.categoria,
--t1.rappicreditos,
t1.rappicreditos_real ,
t1.store_name as Tienda,
t1.store_id,
t1.brandname as Marca,

zt.COMMENT,
(zt.COMMENT:body)::text description,


TRIM(REGEXP_REPLACE(substring(zt.COMMENT:body, CHARINDEX('Product ID: ', zt.COMMENT:body) + 12, 10), '[^[:digit:]]', '')) as product_id,
replace(TRIM(REGEXP_REPLACE(substring(zt.COMMENT:body, CHARINDEX('Product Price: ', zt.COMMENT:body) + 12, 10), '[^[:digit:]]', ' ')),' ','.') as product_price,
TRIM(REGEXP_REPLACE(substring(zt.COMMENT:body, CHARINDEX('Quantity: ', zt.COMMENT:body) + 12, 10), '[^[:digit:]]', '')) as quantity,
case when SPLIT_PART(zt.comment:body,'Comentário do usuário:',2) = ''
        then case when SPLIT_PART(zt.comment:body,'User comment:',2) = ''
            then SPLIT_PART(zt.comment:body,'Comentario de usuario:',2)
            else SPLIT_PART(zt.comment:body,'User comment:',2) end
        else SPLIT_PART(zt.comment:body,'Comentário do usuário:',2) end as comentario,

t1.priority
from t1
left join cl_MG_MS_REPLSET_TICKET_MANAGER.TICKETS zt on t1.order_id::text=zt.order_id::text

left join orders o on t1.order_id = o.id::text
) ok
left join cl_grability_public.products p on ok.product_id::text = p.id::text

--where categoria in ('Producto Diferente','Pedido Incompleto')
--or (categoria = 'Producto Mal Estado' and (case when ok.comentario1 ilike '%frio%' then 'pagamos' when ok.comentario1 ilike '%frío%' then 'pagamos'  when ok.comentario1 ilike '%fría%' then 'pagamos'  when ok.comentario1 ilike '%fria%' then 'pagamos' when ok.comentario1 ilike '%frio%' then 'pagamos' when ok.comentario1 ilike '%sin%' and ok.comentario1 ilike '%verdu%' then 'no pagamos' when ok.comentario1 ilike '%sin%' and ok.comentario1 ilike '%papa%' then 'no pagamos' when ok.comentario1 ilike '%sin%' and ok.comentario1 ilike '%ques%' then 'no pagamos' when ok.comentario1 ilike '%sin%' and ok.comentario1 ilike '%tocine%' then 'no pagamos' when ok.comentario1 ilike '%crudo%' then 'no pagamos' when ok.comentario1 ilike '%crudo%' then 'no pagamos' when ok.comentario1 ilike '%quemada%' then 'no pagamos' when ok.comentario1 ilike '%incomplet%' then 'no pagamos' when ok.comentario1 ilike '%dañad%' then 'no pagamos' when ok.comentario1 ilike '%amarg%' then 'no pagamos' when ok.comentario1 ilike '%viej%' then 'no pagamos' when ok.comentario1 ilike '%mal%' and ok.comentario1 ilike '%sabor%' then 'no pagamos' when ok.comentario1 ilike '%tamañ%' then 'no pagamos' when ok.comentario1 ilike '%equivocad%' then 'no pagamos' when ok.comentario1 ilike '%resec%' then 'no pagamos' when ok.comentario1 ilike '%enferm%' then 'no pagamos' when ok.comentario1 ilike '%vomit%' then 'no pagamos' when ok.comentario1 ilike '%ahumad%' then 'no pagamos' when ok.comentario1 ilike '%insipi%' then 'no pagamos' when ok.comentario1 ilike '%descompues%' then 'no pagamos' when ok.comentario1 ilike '%dura%' then 'no pagamos' when ok.comentario1 ilike '%amarg%' then 'no pagamos' when ok.comentario1 ilike '%diarre%' then 'no pagamos' when ok.comentario1 ilike '%duro%' then 'no pagamos' when ok.comentario1 ilike '%pichas%' then 'no pagamos' when ok.comentario1 ilike '%con%' and ok.comentario1 ilike '%azuc%' then 'no pagamos' when ok.comentario1 ilike '%con%' and ok.comentario1 ilike '%sal%' then 'no pagamos' when ok.comentario1 ilike '%con%' and ok.comentario1 ilike '%pimineta%' then 'no pagamos' when ok.comentario1 ilike '%con%' and ok.comentario1 ilike '%azuc%' then 'no pagamos' when ok.comentario1 ilike '%sin%' and ok.comentario1 ilike '%azuc%' then 'no pagamos' when ok.comentario1 ilike '%sin%' and ok.comentario1 ilike '%sal%' then 'no pagamos' when ok.comentario1 ilike '%sin%' and ok.comentario1 ilike '%pimienta%' then 'no pagamos' when ok.comentario1 ilike '%tocine%' then 'no pagamos' when ok.comentario1 ilike '%gusano%' then 'no pagamos' when ok.comentario1 ilike '%ranci%' then 'no pagamos' when ok.comentario1 ilike '%sin%' and ok.comentario1 ilike '%salsa%' then 'no pagamos' when ok.comentario1 ilike '%alergi%' then 'no pagamos' when ok.comentario1 ilike '%alérgic%' then 'no pagamos' when ok.comentario1 ilike '%pelo%' then 'no pagamos' when ok.comentario1 ilike '%huelen%' then 'no pagamos' when ok.comentario1 ilike '%olor%' then 'no pagamos' when ok.comentario1 ilike '%desabrid%' then 'no pagamos' when ok.comentario1 ilike '%blandit%' then 'no pagamos' when ok.comentario1 ilike '%maluc%' then 'no pagamos' when ok.comentario1 ilike '%maluquit%' then 'no pagamos' when ok.comentario1 ilike '%intox%' then 'no pagamos' when ok.comentario1 ilike '%queso%' then 'no pagamos' when ok.comentario1 ilike '%cocci%' then 'no pagamos' when ok.comentario1 ilike '%cocinad%' then 'no pagamos' when ok.comentario1 ilike '%gusan%' then 'no pagamos' when ok.comentario1 ilike '%estab%' and ok.comentario1 ilike '%pasad%' then 'no pagamos' when ok.comentario2 ilike '%frio%' then 'pagamos' when ok.comentario2 ilike '%frío%' then 'pagamos'  when ok.comentario2 ilike '%fría%' then 'pagamos'  when ok.comentario2 ilike '%fria%' then 'pagamos' when ok.comentario2 ilike '%frio%' then 'pagamos' when ok.comentario2 ilike '%sin%' and ok.comentario2 ilike '%verdu%' then 'no pagamos' when ok.comentario2 ilike '%sin%' and ok.comentario2 ilike '%papa%' then 'no pagamos' when ok.comentario2 ilike '%sin%' and ok.comentario2 ilike '%ques%' then 'no pagamos' when ok.comentario2 ilike '%sin%' and ok.comentario2 ilike '%tocine%' then 'no pagamos' when ok.comentario2 ilike '%crudo%' then 'no pagamos' when ok.comentario2 ilike '%crudo%' then 'no pagamos' when ok.comentario2 ilike '%quemada%' then 'no pagamos' when ok.comentario2 ilike '%dañad%' then 'no pagamos' when ok.comentario2 ilike '%amarg%' then 'no pagamos' when ok.comentario2 ilike '%viej%' then 'no pagamos' when ok.comentario2 ilike '%mal%' and ok.comentario2 ilike '%sabor%' then 'no pagamos' when ok.comentario2 ilike '%tamañ%' then 'no pagamos' when ok.comentario2 ilike '%equivocad%' then 'no pagamos' when ok.comentario2 ilike '%resec%' then 'no pagamos' when ok.comentario2 ilike '%enferm%' then 'no pagamos' when ok.comentario2 ilike '%vomit%' then 'no pagamos' when ok.comentario2 ilike '%ahumad%' then 'no pagamos' when ok.comentario2 ilike '%insipi%' then 'no pagamos' when ok.comentario2 ilike '%descompues%' then 'no pagamos' when ok.comentario2 ilike '%dura%' then 'no pagamos' when ok.comentario2 ilike '%amarg%' then 'no pagamos' when ok.comentario2 ilike '%diarre%' then 'no pagamos' when ok.comentario2 ilike '%duro%' then 'no pagamos' when ok.comentario2 ilike '%pichas%' then 'no pagamos' when ok.comentario2 ilike '%con%' and ok.comentario2 ilike '%azuc%' then 'no pagamos' when ok.comentario2 ilike '%con%' and ok.comentario2 ilike '%sal%' then 'no pagamos' when ok.comentario2 ilike '%con%' and ok.comentario2 ilike '%pimineta%' then 'no pagamos' when ok.comentario2 ilike '%con%' and ok.comentario2 ilike '%azuc%' then 'no pagamos' when ok.comentario2 ilike '%sin%' and ok.comentario2 ilike '%azuc%' then 'no pagamos' when ok.comentario2 ilike '%sin%' and ok.comentario2 ilike '%sal%' then 'no pagamos' when ok.comentario2 ilike '%sin%' and ok.comentario2 ilike '%pimienta%' then 'no pagamos' when ok.comentario2 ilike '%tocine%' then 'no pagamos' when ok.comentario2 ilike '%gusano%' then 'no pagamos' when ok.comentario2 ilike '%ranci%' then 'no pagamos' when ok.comentario2 ilike '%sin%' and ok.comentario2 ilike '%salsa%' then 'no pagamos' when ok.comentario2 ilike '%alergi%' then 'no pagamos' when ok.comentario2 ilike '%alérgic%' then 'no pagamos' when ok.comentario2 ilike '%pelo%' then 'no pagamos' when ok.comentario2 ilike '%huelen%' then 'no pagamos' when ok.comentario2 ilike '%olor%' then 'no pagamos' when ok.comentario2 ilike '%desabrid%' then 'no pagamos' when ok.comentario2 ilike '%blandit%' then 'no pagamos' when ok.comentario2 ilike '%maluc%' then 'no pagamos' when ok.comentario2 ilike '%maluquit%' then 'no pagamos' when ok.comentario2 ilike '%intox%' then 'no pagamos' when ok.comentario2 ilike '%queso%' then 'no pagamos' when ok.comentario2 ilike '%cocci%' then 'no pagamos' when ok.comentario2 ilike '%incomplet%' then 'no pagamos' when ok.comentario2 ilike '%cocinad%' then 'no pagamos' when ok.comentario2 ilike '%gusan%' then 'no pagamos' when ok.comentario2 ilike '%estab%' and ok.comentario2 ilike '%pasad%' then 'no pagamos' else 'pagamos' end) <> 'pagamos')

)

,rank as (
select
*,
rank() over ( partition by order_id order by fecha, priority,categoria, description,product_name ) as rank
from final
)

(
select
paid_lot_id,
STORE_ID  ,

TIENDA  ,
FECHA::varchar as FECHA ,
ORDER_ID  ,
CATEGORIA ,
--DESCRIPTION ,
PRODUCT_NAME  ,
try_cast(PRODUCT_PRICE as float) as PRODUCT_PRICE ,
abs(RAPPICREDITOS_REAL) as RAPPICREDITOS_REAL,
comentario
from rank
where rank=1
)