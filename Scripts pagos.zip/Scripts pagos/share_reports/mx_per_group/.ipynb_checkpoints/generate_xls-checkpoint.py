# -*- coding: utf-8 -*-
# >>> pip uninstall openpyxl
# >>> pip install openpyxl==3.0.1
import openpyxl
import snowflake.connector
from openpyxl.utils.dataframe import dataframe_to_rows
import datetime
import pandas as pd
import numpy as np
import pathlib
import yagmail
from openpyxl.worksheet.datavalidation import DataValidation
import multiprocessing
from multiprocessing import Queue
from multiprocessing import Pool
from functools import partial

q = Queue()


PATH = pathlib.Path(__file__).parent.resolve()

file_template = 'template.xlsx'



def cleaner(wb, sheet_tab, first_row, last_row):

	sheet = wb.get_sheet_by_name(sheet_tab)
	print('Removing ', sheet_tab)
	sheet.delete_rows(first_row,last_row)


def clean_template():


	wb = openpyxl.load_workbook(filename=file_template,data_only=False)

	cleaner(wb,'Ordenes',3,1500000)
	cleaner(wb,'Detalles Compensaciones',3,1500000)
	cleaner(wb,'Productos',2,1500000)
	cleaner(wb,'Ajustes',2,1500000)
	wb.save(file_template)	


def download_snowflake(sql_file):
	
	con = snowflake.connector.connect(
        host='hg51401.snowflakecomputing.com',
        user='BI_PAGOS_USER',
        password='TvPVriohtYT*%oqvnZ$@UzY2',
        account='hg51401',
        database='FIVETRAN',
        warehouse='VARIABLE_LOAD'
	)
	cur = con.cursor()
	cur.execute(open(str(PATH.joinpath(sql_file)), "r").read())
	result = cur.fetchall()
	colnames = [desc[0] for desc in cur.description]
	df = pd.DataFrame(result) 
	df.columns = colnames
	return df


def append_data(wb,sheet_name,df):

	sheet = wb.get_sheet_by_name(sheet_name)
	print('Dataframe ',sheet_name)
	for r in dataframe_to_rows(df, index=False, header=False):
		sheet.append(r)

print('Downloading Base')
df_base = download_snowflake('base.sql')
print('Downloading Compensaciones')
df_compensaciones = download_snowflake('base_compensaciones.sql')
print('Downloading Produts')
df_products = download_snowflake('products.sql')
print('Downloading Ajustes')
df_adj = download_snowflake('adjustments.sql')

paid_lots = df_base.PAID_LOT_ID.unique()


df_groups = download_snowflake('groups.sql')
df_groups = df_groups.groupby('GROUP_NAME')['PAID_LOT_ID'].apply(list).reset_index(name='new')
print(df_groups.head())

# print('Next Step')
groups = df_groups.values.tolist()


def generate_xls():

	
	
	for group in groups:
		wb = openpyxl.load_workbook(filename=file_template,data_only=False)	
		sheet = wb.get_sheet_by_name('Resumen')
		sheet['E8'] = group[0]
		# print(group[1])
		store_base = df_base.loc[df_base['PAID_LOT_ID'].isin(group[1])]
		print(store_base.head())
		append_data(wb,'Ordenes',store_base)

		store_file = str(PATH.joinpath('generated_excel',str(group[1][0]) + '.xlsx'))

		store_compensaciones = df_compensaciones.loc[df_compensaciones['PAID_LOT_ID'].isin(group[1])]
		append_data(wb,'Detalles Compensaciones',store_compensaciones)

		store_products = df_products.loc[df_products['PAID_LOT_ID'].isin(group[1])]
		append_data(wb,'Productos',store_products)

		adj = df_adj.loc[df_adj['PAID_LOT_ID'].isin(group[1])]
		append_data(wb,'Ajustes',adj)

		wb.save(store_file)
 

def main():

	clean_template()
	generate_xls()


	# with Pool(5) as p:
	# 	data = p.map(generate_xls, paid_lots)


if __name__ == '__main__':
	main()