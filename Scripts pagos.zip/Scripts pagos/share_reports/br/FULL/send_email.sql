
update BR_WRITABLE.PARTNER_PAYMENT_REPORTS
set ready_to_email = true
where country = 'BR'
and paid_lot_id in
(
select distinct pl.id
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.paid_lots pl
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id = pl.balance_request_id
where pay_start_date >= '2021-01-04'
)