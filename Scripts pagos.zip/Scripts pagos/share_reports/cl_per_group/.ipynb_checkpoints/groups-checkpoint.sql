
 
 select distinct g.group_name,pl.id as paid_lot_id
from CL_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl
left join CL_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
left join CL_PGLR_MS_PARTNER_PAYMENT_PUBLIC.STORE_PAYMENT_REFERENCES pr on pr.payment_reference_id = pl.payment_reference_id and not pr._fivetran_deleted
left join CL_PGLR_MS_PARTNER_PAYMENT_PUBLIC.STORES st on st.store_id = pr.store_id and not st._fivetran_deleted
join br_writable.partner_payment_groups g on g.store_id = st.store_id and g.country = 'CL'
where not PL._FIVETRAN_DELETED
and PAY_START_DATE >='2022-07-25'
 and  PAY_END_DATE <='2022-07-31'
  --and g.group_name ilike '%lov%'
  and pl.status<>'CANCELED'