# -*- coding: utf-8 -*-
"""
Created on Tue Jan 26 09:10:31 2021

@author: David.Romero
"""
"""--------------------------------PARÁMETROS------------------------------"""

#Parametros de Busqueda
FI="2022-06-06"            #Fecha de Inicio de Búsqueda
FF="2022-06-13"            #Fecha de Fin de Búsqueda
FA="2022-06-13"            #Fecha de Fin de Búsqueda
Frecuencia=(1,5)           #Numero de frecuencia asociada a la búsqueda




"""------------------------------------------------------------------------"""
"""--------------NO MODIFICAR NADA DE AQUÍ EN ADELANTE---------------------"""
#Importación de Librerias
import snowflake.connector as sf
import pandas as pd
import math
from datetime import datetime
TiempoInicio= datetime.now()
#Creación de la conexión con Snowflake
con = sf.connect(
user= 'hamilton.pacanchique@rappi.com',
account= 'hg51401',
warehouse='PAGOS_ANALYSTS',
database='FIVETRAN',
schema='PUBLIC',
authenticator='externalbrowser'
)
#Cursor o consola de Sql en Python
cs=con.cursor()
Fecha_Ajuste=pd.to_datetime(FA).date()
Fecha_Inicio=pd.to_datetime(FI).date()
Fecha_Fin=pd.to_datetime(FF).date()
print("Buen Día, el tiempo promedio de ejecución es de 6 minutos")
print("Los ajustes se crearán para el periodo "+str(Fecha_Inicio)+" al "+str(Fecha_Fin))


"""----------------------------StockOut y TC Query-------------------------"""
SO_sql=("""
        SELECT 
      t.created_at::DATE,
      T.PAID_LOT_ID,
      t.model_id,
      o.state,
      s.store_id,
      om.support_reason,
      STT.PORCENTAJE_CANCELACION,
      COM.commission_percentage,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 1 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 20 THEN T.AMOUNT ELSE 0 END) AS VENTA,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 10 THEN T.AMOUNT ELSE 0 END)AJ_CANCELLATION_VALUE,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 1 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 20 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 23 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 24 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 18 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 29 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 32 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 10 THEN T.AMOUNT ELSE 0 END) AS      SUB_TOTAL,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 2 THEN T.AMOUNT ELSE 0 END) +  SUM(CASE WHEN T.TRANSACTION_REASON_ID = 28 THEN T.AMOUNT ELSE 0 END)
    +  SUM(CASE WHEN T.TRANSACTION_REASON_ID = 27 THEN T.AMOUNT ELSE 0 END) +  SUM(CASE WHEN T.TRANSACTION_REASON_ID = 21 THEN T.AMOUNT ELSE 0 END) AS CM_COMISSION,
    SUM(CASE WHEN T.TRANSACTION_REASON_ID = 3 THEN T.AMOUNT ELSE 0 END) AS IVA,
    SUM(T.AMOUNT) TOTAL_ORDER
FROM MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.TRANSACTIONS T
    JOIN MX_CORE_ORDERS_PUBLIC.ORDERS Ol ON T.model_id = Ol.ID
                                      AND Ol.STATE ILIKE 'CANCEL%'
    JOIN MX_CORE_ORDERS_PUBLIC.ORDERS O ON O.ID = T.model_id
    LEFT JOIN MX_PGLR_MS_STORES_PUBLIC.STORES_vw S ON S.STORE_ID = T.STORE_ID AND S._FIVETRAN_DELETED = FALSE
    LEFT JOIN CO_PGLR_MS_STORES_PUBLIC.STORE_BRANDS_vw SB ON SB.ID = S.STORE_BRAND_ID
    LEFT JOIN OPS_GLOBAL.CANCELLATION_REASONS tas on tas.order_id = t.model_id
    LEFT JOIN ( SELECT  DISTINCT ORDER_ID, 
                   MAX(replace((params:cancelation_reason), '"')  ) as support_reason,
                   max(case when type ilike '%integration%' then created_at end) as integration 
                FROM MX_CORE_ORDERS_PUBLIC.ORDER_MODIFICATIONS
                WHERE _FIVETRAN_DELETED = FALSE 
                GROUP BY 1
                 )OM ON OM.ORDER_ID = T.model_id
    LEFT JOIN (SELECT 
                  ST.STORE_ID, 
                   max(VALUE) AS PORCENTAJE_CANCELACION
               FROM MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_contracts st 
                  LEFT JOIN MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts c on st.contract_id = c.id
                  LEFT JOIN MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contract_conditions cc on cc.contract_id = c.id
                WHERE cc.contract_condition_type_id = 13 group by 1) stt on stt.store_id = t.store_id 
    LEFT JOIN (select * 
                      from (select distinct
                                      order_id,
                                      commission_percentage,
                                      rank() over(partition by order_id order by order_version desc) as rank
                                      from MX_PGLR_MS_PARTNER_PAYMENT_DATA.order_commission where _fivetran_deleted <> TRUE
                                 ) T where rank=1 ) COM ON COM.ORDER_ID = T.MODEL_ID
    INNER JOIN MX_PGLR_MS_PARTNER_PAYMENT_DATA.ORDER_DATA OD ON T.MODEL_ID = OD.ID AND NOT OD._FIVETRAN_DELETED
    INNER JOIN MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.CONTRACTS CON ON CON.ID = OD.CONTRACT_ID AND NOT CON._FIVETRAN_DELETED AND CON.FREQUENCY_TYPE_ID NOT IN (7,8,9)
where  T.CREATED_AT::DATE BETWEEN (dateadd(day,-40,current_date())) AND (current_date())  and support_reason  in ('crsan_closed_store','crsan_product_not_available') AND TAS.COUNTRY = 'MX'--- AND  (LEVEL_3 = 'store_closed' OR LEVEL_3 = 'stockout_no_automation_typification')
group by 1,2,3,4,5,6,7,8
having TOTAL_ORDER > 0
        """)
cs.execute(SO_sql)
SO_df = cs.fetch_pandas_all()
if SO_df.empty:
    print("Sin información de Stockout y TC" )
else:
    print("Información cargada: Stockout y tienda cerrada" )
SO_df_Filter=SO_df[(SO_df['T.CREATED_AT::DATE']>=Fecha_Inicio)]
SO_df_Filter=SO_df_Filter[SO_df_Filter['T.CREATED_AT::DATE']<=Fecha_Fin]
SO_df_Filter['TOTAL_ORDER']=round(SO_df_Filter['TOTAL_ORDER'].astype('float'),2)


CSV_Headlines=['store_id','order_id','amount','date','description','reason']
SO_Adj=pd.DataFrame(columns=CSV_Headlines)
SO_Adj['store_id']=SO_df_Filter['STORE_ID']
SO_Adj['order_id']=''
SO_Adj['amount']=SO_df_Filter['TOTAL_ORDER']*-1
SO_Adj['date']=Fecha_Ajuste
SO_Adj['description']='Ordenes Canceladas por Producto Faltante y Tienda Cerrada'+' del '+str(Fecha_Inicio)+' al '+str(Fecha_Fin)
SO_Adj['reason']='others_rest_over_pay'
SO_Adj['type']='Stockout y TC'
#SO_Adj.to_csv('MX_Adj_SO.csv',index=False)
"""-------------------------Ally Another Reason Query----------------------"""
Ally_another_sql=("""
with modifications as (
 select 
   order_id,
   max(case when type ilike '%cancel%' then created_at::date end) as cancelation_time,
   max(case when type = 'taken_visible_order' and params:partner_id is not null then created_at::timestamp_ntz end ) as taken_partner,
   max(case when type = 'assign_to_partner_integration_v2' and params:partner_id is not null then created_at::timestamp_ntz end ) as taken_partner_integrado,
   max(case when type = 'taken_visible_order' and params:storekeeper_id is not null then created_at::timestamp_ntz end) as taken_rt,
   max(case when type = 'release_order_request' then created_at::timestamp_ntz end) as request_liberacion,
   max(case when type = 'replace_storekeeper' then created_at::timestamp_ntz end) as reemplazo_manual,
  max(case when type = 'release_order_by_cms_request' then created_at::timestamp_ntz end) as libero
 from mx_core_orders_public.order_modifications
 where not _fivetran_deleted 
 group by 1
),
reasons as (
 select *
 from (select order_id,
           row_number() over (partition by order_id order by created_at desc, id desc) as rank,
           created_at::timestamp_ntz as cancelation_time,
           type as cancelation_state,
           replace(PARSE_JSON(params:cancellation_info):reason:reason_id, '"') as cancelation_reason
        from mx_core_orders_public.order_modifications 
        where not _fivetran_deleted 
        and type ilike '%cancel%'
      )
 where rank = 1 
)
SELECT distinct 
      t.created_at::DATE,
      T.PAID_LOT_ID,
      t.model_id,
      o.state,
      s.store_id,
      r.cancelation_reason as support_reason,
      STT.PORCENTAJE_CANCELACION,
      COM.commission_percentage,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 1 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 20 THEN T.AMOUNT ELSE 0 END) AS VENTA,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 10 THEN T.AMOUNT ELSE 0 END)AJ_CANCELLATION_VALUE,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 1 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 20 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 23 THEN T.AMOUNT ELSE 0 END) + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 24 THEN T.AMOUNT ELSE 0 END)
      + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 18 THEN T.AMOUNT ELSE 0 END) + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 29 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 32 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 10 THEN T.AMOUNT ELSE 0 END) AS      SUB_TOTAL,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 6 THEN T.AMOUNT ELSE 0 END)RT_RETEFUENTE_CC_DC,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 9 THEN T.AMOUNT ELSE 0 END)RT_ICA_CC_DC,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 2 THEN T.AMOUNT ELSE 0 END) +  SUM( CASE WHEN T.TRANSACTION_REASON_ID = 28 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 27 THEN T.AMOUNT ELSE 0 END) +  SUM(CASE WHEN T.TRANSACTION_REASON_ID = 21 THEN T.AMOUNT ELSE 0 END) AS CM_COMISSION,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 11 THEN T.AMOUNT ELSE 0 END) AS BANK_SPENDINGS,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 3 THEN T.AMOUNT ELSE 0 END) AS IVA,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 4 THEN T.AMOUNT ELSE 0 END) AS RETEFUNETE,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 5 THEN T.AMOUNT ELSE 0 END) AS RETEICA,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 25 THEN T.AMOUNT ELSE 0 END) AS RETEIVA,
      SUM(T.AMOUNT) TOTAL_ORDER
    FROM mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.TRANSACTIONS T
    JOIN mx_CORE_ORDERS_PUBLIC.ORDERS Ol ON T.model_id = Ol.ID AND Ol.STATE ILIKE 'CANCEL%'
    JOIN mx_CORE_ORDERS_PUBLIC.ORDERS O ON O.ID = T.model_id
    LEFT JOIN MX_PGLR_MS_STORES_PUBLIC.STORES_vw S ON S.STORE_ID = T.STORE_ID AND S._FIVETRAN_DELETED = FALSE
    LEFT JOIN MX_PGLR_MS_STORES_PUBLIC.STORE_BRANDS_vw SB ON SB.ID = S.STORE_BRAND_ID
    left join modifications m on m.order_id = t.model_id
    left join reasons r on r.order_id = t.model_id
    join (select distinct 
               order_id
               from mx_pg_ms_realtime_interface_public.notifications
               where (sender_type ilike '%rappite%' or sender_type ilike '%personals%')
               and notification_type in (
  'RT_PROBLEMS_WITH_RESTAURANT_NOT_RELEASED_ORDER', 
  'RT_OTHER_RT_PICKED_UP_MY_ORDER_V3',
  'RT_OTHER_RT_PICKED_UP_MY_ORDER', 
  'RT_PROBLEMS_WITH_RESTAURANT_ORDER_DOES_NOT_APPEAR', 
  'RT_PROBLEMS_WITH_RESTAURANT_LATE')
               ) riesgo on riesgo.order_id = t.model_id
    left join (select distinct store_type, 
                 first_value(sub_group) over(partition by store_type order by _fivetran_synced desc) as subvertical, 
                 first_value("GROUP") over(partition by store_type order by _fivetran_synced desc) as vertical 
               from mx_grability_public.verticals 
               where not _fivetran_deleted
               ) v on s.type = v.store_type 
    LEFT JOIN (SELECT 
                ST.STORE_ID, 
                max(VALUE) AS PORCENTAJE_CANCELACION
               FROM mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_contracts st 
               LEFT JOIN mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts c on st.contract_id = c.id
               LEFT JOIN mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contract_conditions cc on cc.contract_id = c.id
               WHERE cc.contract_condition_type_id = 13
              group by 1 ) stt on stt.store_id = t.store_id 
   LEFT JOIN (select * 
              from (select distinct
                      order_id,
                      commission_percentage,
                      rank() over(partition by order_id order by order_version, created_at desc) as rank
                      from mx_PGLR_MS_PARTNER_PAYMENT_DATA.order_commission where _fivetran_deleted <> TRUE
                    ) T where rank=1 ) COM ON COM.ORDER_ID = T.MODEL_ID
    INNER JOIN MX_PGLR_MS_PARTNER_PAYMENT_DATA.ORDER_DATA OD ON T.MODEL_ID = OD.ID AND NOT OD._FIVETRAN_DELETED
    INNER JOIN MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.CONTRACTS CON ON CON.ID = OD.CONTRACT_ID AND NOT CON._FIVETRAN_DELETED AND CON.FREQUENCY_TYPE_ID NOT IN (7,8,9)
where 
T.CREATED_AT::DATE BETWEEN (dateadd(day,-40,current_date())) AND (dateadd(day,-1,current_date())) 
and subvertical in ('Restaurantes')
and (taken_partner is not null or taken_partner_integrado is not null) 
and o.state ilike '%cancel%'
and cancelation_reason = 'crsan_ally_another_reason'
and request_liberacion is null and reemplazo_manual is null and libero is null
group by 1,2,3,4,5,6,7,8
having TOTAL_ORDER > 0
""")
cs.execute(Ally_another_sql)
All_Another_df = cs.fetch_pandas_all()
if All_Another_df.empty:
    print("Sin información de Riesgos RT" )
else:
    print("Información cargada: Riesgos RT" )
All_Another_df_Filter=All_Another_df[(All_Another_df['T.CREATED_AT::DATE']>=Fecha_Inicio)]
All_Another_df_Filter=All_Another_df_Filter[All_Another_df_Filter['T.CREATED_AT::DATE']<=Fecha_Fin]
All_Another_df_Filter['TOTAL_ORDER']=round(All_Another_df_Filter['TOTAL_ORDER'].astype('float'),2)

Ally_Other_Adj=pd.DataFrame(columns=CSV_Headlines)

Ally_Other_Adj['store_id']=All_Another_df_Filter['STORE_ID']
Ally_Other_Adj['order_id']=''
Ally_Other_Adj['amount']=All_Another_df_Filter['TOTAL_ORDER']*-1
Ally_Other_Adj['date']=Fecha_Ajuste
Ally_Other_Adj['description']='Ordenes canceladas por demora de entrega a RT'+' del '+str(Fecha_Inicio)+' al '+str(Fecha_Fin)
Ally_Other_Adj['reason']='others_rest_over_pay'
Ally_Other_Adj['type']='Riesgos RT'
#Ally_Other_Adj.to_csv('AR_Adj_Ally_other.csv',index=False)

"""-------------Aliados (Store Id, Contrato, Fechas, Freq) Query-----------"""
Aliados_sql=(
   """ 
select DISTINCT
			      st.store_id,
            st.name,
            spr.PAYMENT_REFERENCE_ID,
            st.IS_MARKETPLACE,
            sc.CONTRACT_ID, 
            con.frequency_type_id, 
            con.created_at as creacion_contrato,
            con.START_DATE,
            con.END_DATE,
            iff(COUNT(DISTINCT case when (convert_timezone('UTC','America/Mexico_City',current_date::TIMESTAMP_NTZ) between con.START_DATE and con.END_DATE) and (convert_timezone('UTC','America/Mexico_City',current_date::TIMESTAMP_NTZ) between sl.START_DATE and sl.END_DATE) AND ob.slot_id is not null THEN CON.ID ELSE NULL END) over (partition by st.store_id)>0 and COUNT(DISTINCT case when ob.slot_id is null THEN sl.ID ELSE NULL END) over (partition by st.store_id)=0,'SI','NO') AS CONTRATO_OK,
            'MX' as pais
                --cc.contract_condition_type_id, cc.value


        from MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores st
        left join
        (
             select sc.store_id, max(sc.contract_id) as contract_id from
                MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_contracts sc
          left join MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts c on sc.contract_id = c.id
                where c.end_date >= current_date()
          group by 1
        ) sc 
        on sc.store_id=st.store_id 
        left join MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts con on con.id=sc.contract_id and not con._fivetran_deleted
        left join MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.slots sl on sl.CONTRACT_ID=con.id and not sl._fivetran_deleted
        left join MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.objectives ob on ob.slot_id=sl.id and not ob._fivetran_deleted
        left join
              (
                SELECT store_id,
                     max(PAYMENT_REFERENCE_ID) as PAYMENT_REFERENCE_ID
                FROM
                (
                select *, row_number () over (partition by store_id order by created_at desc) as unico
                from MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_payment_references spr
                where not spr._fivetran_deleted and created_at is not null
               )
                where unico=1 group by 1
              )spr on spr.store_id= st.store_id
    
        where not st._fivetran_deleted

"""
    )
cs.execute(Aliados_sql)
Aliados_df = cs.fetch_pandas_all()
Columnas_Aliados=list(Aliados_df.columns)
Columnas_Aliados[0]='store_id'
Aliados_df.columns=Columnas_Aliados
if Aliados_df.empty:
    print("Sin información de Aliados" )
else:
    print("Información cargada: Aliados (Freq., Contratos, etc.)" )
    
    
    
"""-------------Sushi Roll Query-----------"""    
Sushi_Roll_Sql=(
    """
    --no_cache;
with
----------------------------------------------- Calculos Pago V2 ----------------------------------------------------
pago_v2 as (
         select
         t.store_id,
         payment_version,
         week(PAY_START_DATE::date) as semana,
         year(PAY_START_DATE::date) as ano,
         br.PAY_START_DATE::date as start_date_v2,
         br.PAY_END_DATE::date as end_date_v2,
         model_id as order_id_v2,
         t.paid_lot_id,
         t.created_at::date as created_at_transactions,
         sum(case when tr.id = 1 then t.amount else 0 end) as total_order_v2,
         sum(case when tr.id = 2 then t.amount else 0 end) as commission_product_v2,
         sum(case when tr.id = 3 then t.amount else 0 end) as sale_tax_v2,
         sum(case when tr.id = 4 then t.amount else 0 end) as retention_retefuente_v2,
         sum(case when tr.id = 5 then t.amount else 0 end) as retention_ica_v2,
         sum(case when tr.id = 6 then t.amount else 0 end) as retention_retefuente_cc_dc_v2,
         sum(case when tr.id = 7 then t.amount else 0 end) as marketplace_v2,
         sum(case when tr.id = 8 then t.amount else 0 end) as cofins_v2,
         sum(case when tr.id = 9 then t.amount else 0 end) as retention_ica_cc_dc_v2,
         sum(case when tr.id = 10 then t.amount else 0 end) as cancellation_value_v2,
         sum(case when tr.id = 11 then t.amount else 0 end) as bank_spending_v2,
         sum(case when tr.id = 12 then t.amount else 0 end) as piss_v2,
         sum(case when tr.id = 13 then t.amount else 0 end) as reteica_cc_dc_without_impoconsumo_v2,
         sum(case when tr.id = 14 then t.amount else 0 end) as refuente_cc_dc_without_impoconsumo_v2,
         sum(case when tr.id = 15 then t.amount else 0 end) as adjustments_order_v2,
         sum(case when tr.id = 16 then t.amount else 0 end) as adjustments_no_order_v2,
         sum(case when tr.id = 17 then t.amount else 0 end) as integration_fee_v2,
         sum(case when tr.id = 18 then t.amount else 0 end) as compensation_v2,
         sum(case when tr.id = 19 then t.amount else 0 end) as discount_by_marketplace_in_cash_v2,
         sum(case when tr.id = 20 then t.amount else 0 end) as total_order_whim_v2,
         sum(case when tr.id = 21 then t.amount else 0 end) as commission_product_without_impoconsumo_v2,
         sum(case when tr.id = 22 then t.amount else 0 end) as delay_fee_v2,
         sum(case when tr.id = 23 then t.amount else 0 end) as shipping_partner_no_limit_v2,
         sum(case when tr.id = 24 then t.amount else 0 end) as shipping_partner_limit_v2,
         sum(case when tr.id = 25 then t.amount else 0 end) as reteiva_v2,
         sum(case when tr.id = 26 then t.amount else 0 end) as marketplace_charge_v2,
         sum(case when tr.id = 27 then t.amount else 0 end) as commission_whim_v2,
         sum(case when tr.id = 28 then t.amount else 0 end) as commission_whim_without_impoconsumo_v2,
         sum(case when tr.id = 29 then t.amount else 0 end) as rt_pay_v2,
         sum(case when tr.id = 30 then t.amount else 0 end) as fee_activation_marketplace_v2,
         sum(case when tr.id = 31 then t.amount else 0 end) as free_shipping_v2,
         sum(case when tr.id = 32 then t.amount else 0 end) as other_discounts_v2,
         sum(case when tr.id = 47 then t.amount else 0 end) as iss_v2,
         sum(case when tr.id = 48 then t.amount else 0 end) as marketplace_fee_no_cash_v2,
         sum(case when tr.id = 49 then t.amount else 0 end) as perception_tax_v2,
         sum(case when tr.id = 50 then t.amount else 0 end) as cbda_tax_v2,
         sum(t.amount - case when tr.name ilike ('%adjustment%') then t.amount else 0 end) as pago_sin_ajustes_v2,
         sum(case when tr.name ilike ('%adjustment%') then t.amount else 0 end) as ajustes_v2,
         sum(t.amount) as pago_total_v2,
         listagg(distinct sc.commission, ', ') within group (order by sc.commission) as commission_percentage_v2,
         listagg(distinct sc.cancellation_percentage, ', ') within group (order by sc.cancellation_percentage) as cancellation_percentage_v2,
         listagg(distinct sc.allow_comsuption_tax, ', ') within group (order by sc.allow_comsuption_tax) as ALLOW_CONSUMPTION_TAX_v2,
         max(store_is_cashless) as store_is_cashless_v2,
         max(store_is_no_pay) as store_is_no_pay_v2,
         max(order_state) as order_state_v2,
         max(payment_method) as payment_method_v2,
         max(cooking_time) as cooking_time_v2
         from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
         inner join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transaction_reasons tr on t.transaction_reason_id = tr.id
         left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl on t.paid_lot_id = pl.id and not PL._FIVETRAN_DELETED
         left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
         left join rappi_payments_staging.stores_payment_vdos s on s.store_id = t.store_id and s.COUNTRY = 'MX' and s.week = week(PAY_START_DATE::date) and NOT br._FIVETRAN_DELETED
  --- cruce con store_contracts
         left join (
                    select
                    model_id as order_id,
                    max(store_is_cashless) as store_is_cashless,
                    max(store_is_no_pay) as store_is_no_pay,
                    max(order_state) as order_state,
                    max(payment_method) as payment_method,
                    max(cooking_time) as cooking_time,
                    round(avg(T2.commission_percentage),4)::text as commission,
                    round(avg(case when T3.contract_condition_type_id=13 then T3.value else null end)/100,2)::text as cancellation_percentage,
                    (case when ( max(case when T3.contract_condition_type_id=6 then T3.value else null end) = 1 )
                          then TRUE
                          else (case when ( max(case when T3.contract_condition_type_id=6 then T3.value else null end) = 0 ) then FALSE else null end) end)::text as allow_comsuption_tax
                    from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t1
                    left join (  select
                                  *
                                  from (
                                      select distinct
                                      order_id,
                                      commission_percentage,
                                      order_version,
                                      rank() over(partition by order_id order by order_version desc) as rank
                                      from mx_PGLR_MS_PARTNER_PAYMENT_DATA.order_commission where _fivetran_deleted <> TRUE
                                 ) T where rank=1 ) T2 on t1.model_id = T2.order_id
                    left join mx_PGLR_MS_PARTNER_PAYMENT_DATA.order_data od on t1.model_id = od.id and od._fivetran_deleted <> TRUE
                    left join ( select
                                cc.contract_id,
                                sc.store_id,
                                cc.contract_condition_type_id,
                                cc.value,
                                cc.start_date,
                                coalesce(lead(cc.start_date) over(partition by cc.contract_id,sc.store_id,cc.contract_condition_type_id order by cc.start_date asc, cc.id asc),current_date) as end_date
                                from mx_PGLR_MS_PARTNER_PAYMENT_public.contract_conditions cc
                                inner join mx_PGLR_MS_PARTNER_PAYMENT_public.store_contracts sc on cc.contract_id = sc.contract_id and sc._fivetran_deleted <> TRUE
                                where cc.contract_condition_type_id in (6,13) and cc._fivetran_deleted <> TRUE ) T3 on t1.store_id = T3.store_id and od.contract_id = t3.contract_id and  od.order_created_at::date between T3.start_date::date and T3.end_date::date
                    where t1._fivetran_deleted <> TRUE
                    group by 1
                              ) sc on sc.order_id = t.model_id
         where --model_id=62913335
                t._fivetran_deleted <> TRUE
--             	and paid_lot_id is not null
--             	and ((week(pay_start_date::date) >= 16 and year(pay_start_date::date) = 2019) or (pay_start_date::date >= '2020-01-01'))
         group by 1,2,3,4,5,6,7,8,9
        ),
pago_base_data_v2 as (
  select
  pb.*,
  'V2' as llave_version
  from pago_v2 pb
  ),
final_2 as (
  select
  pbd2.ano year_num ,
  pbd2.semana semana_num,
  (pbd2.order_id_v2) as order_id,
  pbd2.created_at_transactions,
  (pbd2.paid_lot_id) as paid_lot_id,
  (pbd2.store_id) as stores_ids,
  (pbd2.start_date_v2 ) as fecha_inicio_semana,
  (pbd2.end_date_v2 ) as fecha_fin_semana,
  (pbd2.cancellation_percentage_v2) as cancellation_percentage,
  (pbd2.commission_percentage_v2) as commission_percentage,
  (pbd2.ALLOW_CONSUMPTION_TAX_v2) as ALLOW_CONSUMPTION_TAX,
  pbd2.payment_version,
  (pbd2.total_order_v2) as Venta,
  (pbd2.total_order_whim_v2) as total_order_whim,
  (pbd2.shipping_partner_limit_v2 + pbd2.shipping_partner_no_limit_v2) as shipping_partner,
  (pbd2.compensation_v2) as compensations,
  (pbd2.rt_pay_v2) as RT_pay,
  (pbd2.other_discounts_v2) as other_discounts,
  (pbd2.total_order_v2 + pbd2.total_order_whim_v2 + (pbd2.shipping_partner_limit_v2 + pbd2.shipping_partner_no_limit_v2) + pbd2.compensation_v2 + pbd2.rt_pay_v2 + pbd2.other_discounts_v2 + pbd2.cancellation_value_v2 ) as subtotal_transfer_value,
  (pbd2.sale_tax_v2) as IVA,
  (pbd2.commission_product_v2 + pbd2.commission_product_without_impoconsumo_v2 + pbd2.commission_whim_v2 + pbd2.commission_whim_without_impoconsumo_v2) as commission,
  (pbd2.bank_spending_v2) as bank_spendings,
  (pbd2.retention_retefuente_v2) as retefuente,
  (pbd2.retention_ica_v2) as reteica,
  (pbd2.reteiva_v2) as reteiva,
  (pbd2.retention_retefuente_cc_dc_v2 + pbd2.refuente_cc_dc_without_impoconsumo_v2) as retefuente_cc_dc,
  (pbd2.retention_ica_cc_dc_v2 + pbd2.reteica_cc_dc_without_impoconsumo_v2) as reteica_cc_dc,
  (pbd2.pago_total_v2) as total_order_payment,
  (pbd2.ajustes_v2) as ajustes,
  (pbd2.payment_method_v2) as payment_method,
  ( case when pbd2.store_is_no_pay_v2 is null then null else
            ( case when (pbd2.store_is_no_pay_v2 and pbd2.order_state_v2 not in ('canceled_by_partner_inactivity','canceled_partner_order_refused')) or (pbd2.cooking_time_v2 > 0)
                 then 'tablet'
                 else 'fuera_tablet' end) end ) as order_type,
  ( pbd2.cancellation_value_v2) as cancellation_value ,
  ( pbd2.order_state_v2 ) as order_state
  from pago_base_data_v2 pbd2
  )
select
year_num ,
semana_num,
paid_lot_id,
f.order_id,
o.created_at::date as order_created_at,
f.created_at_transactions,
stores_ids,
s.name as store_name,
fecha_inicio_semana,
fecha_fin_semana,
f.payment_version,
payment_version,
cancellation_percentage,
commission_percentage,
Venta + total_order_whim as venta,
shipping_partner as DAA_shipping_partner,
other_discounts as DDA_other_discounts,
RT_pay as AJ_RT_pay,
compensations as AJ_compensations,
cancellation_value as AJ_cancellation_value,
subtotal_transfer_value as Subtotal,
commission as CM_commission,
IVA as IMP_IVA,
total_order_payment,
f.order_type,
f.payment_method,
f.order_state
from final_2 f
left join mx_grability_public.stores s on f.stores_ids = s.store_id and s._fivetran_deleted <> TRUE
left join mx_core_orders_public.orders o on o.id = f.order_id and o._fivetran_deleted <> TRUE
where (o.created_at::date between '"""+str(Fecha_Inicio)+"""'::date and '"""+str(Fecha_Fin)+"""'::date)
and (s.name ilike ('Sushi Roll %'))
    """
    )
cs.execute(Sushi_Roll_Sql)
Sushi_Roll_List=cs.fetchall()
Columns=pd.DataFrame(cs.description)
Columns=Columns.loc[:][0]
Sushi_Roll_df=pd.DataFrame(Sushi_Roll_List,columns=(Columns))
#Sushi_Roll_df = cs.fetch_pandas_all()
if Sushi_Roll_df.empty:
    print("Sin información de Sushi Roll" )
else:
    print("Información cargada: Sushi Roll" )

Reporte_Duvan=Sushi_Roll_df[Sushi_Roll_df['CANCELLATION_PERCENTAGE']==0.35]
print("Se han encontrado ",str(len(Reporte_Duvan))," incidencias para reportar a Duván Orozco" )
Sushi_Roll_Filter=Sushi_Roll_df[(Sushi_Roll_df['CANCELLATION_PERCENTAGE']!=0.35)&(Sushi_Roll_df['AJ_CANCELLATION_VALUE']==0)]
Sushi_Roll_Adj=pd.DataFrame(columns=CSV_Headlines)
Reporte_Duvan.to_excel('Reporte_Duvan_Sushi.xlsx',index=False)
Sushi_Roll_Filter.to_excel('Sushi_Roll_OK.xlsx',index=False)
#Sushi_Roll_Adj['store_id']=Sushi_Roll_Filter['STORES_IDS']
#Sushi_Roll_Adj['amount']=Sushi_Roll_Filter['AMOUNT']
#Sushi_Roll_Adj['date']=Fecha_Ajuste.strftime('%d/%m/%Y')
#Sushi_Roll_Adj['reason']=Sushi_Roll_Adj['REASON']
#Sushi_Roll_Adj['description']=Sushi_Roll_Adj['DESCRIPTION']
Sushi_Roll_Adj['type']='Sushi Roll'


"""--------------------------COMISION CONDONADAS----------------------------"""
Ajuste_Manual_Comision_16_5_sql=(
    """
    select store_id,
       'COMISION CONDONADA SEMAFORO ROJO DEL '||'"""+str(Fecha_Inicio)+"""'||' al '|| '"""+str(Fecha_Fin)+"""' AS description,
       sum(devolucion_COMMISSION) AS amount,
         CURRENT_DATE - interval '1w' AS date,
         'others_sum_commission_change' as reason
from
(
select t.store_id,
       abs(amount-(amount*0.165/COMMISSION_PERCENTAGE)) as devolucion_COMMISSION,
      devolucion_COMMISSION*0.16 as devolucion_iva

from MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions T
left join mx_pglr_ms_partner_payment_data.order_data od on od.id = t.MODEL_ID and not od._fivetran_deleted  
LEFT JOIN 
(
  
    SELECT *
    FROM
    (
    SELECT ORDER_ID,
           COMMISSION_PERCENTAGE,
           ROW_NUMBER() OVER (PARTITION BY ORDER_ID ORDER BY CREATED_AT::TIMESTAMP_NTZ DESC) AS UNICO
    FROM MX_PGLR_MS_PARTNER_PAYMENT_data.order_commission OC
    WHERE NOT OC._FIVETRAN_DELETED
    )

    WHERE UNICO=1

) COM ON COM.ORDER_ID=T.MODEL_ID

WHERE NOT T._FIVETRAN_DELETED AND T.TRANSACTION_REASON_ID IN (2,21,27,28) AND COMMISSION_PERCENTAGE>0.165 and od.delivery_method!='pickup' and (convert_timezone('UTC','America/Mexico_City',t.created_at::timestamp_ntz)::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""') and t.store_id in (1923204887,1923283949,1923220383,1923200368,1923200373,1923222996,1306713603,1923201445,1923285774,1923218665,1306711874,1923223057,1923218435,1923218153,1923216808,1923227582,1923243472,1306710207,1306718424,1923211039,1923239099,1923264538,1923217512,1923217721,1923217540,1923217548,1923223092,1923220766,1923211735,1923225028,1923243198,1923243414,1923249845,1923209151)
)
group by store_id
    
    """)
#cs.execute(Ajuste_Manual_Comision_16_5_sql)
#Ajuste_Manual_Comision_16_5_Lista=cs.fetch_pandas_all()
#if Ajuste_Manual_Comision_16_5_Lista.empty:
#    print("Sin información de Comision 16.5%" )
#else:
#    print("Información cargada: Comision 16.5%" )

# Comision_16_5_Adj=pd.DataFrame(columns=CSV_Headlines)
# Comision_16_5_Adj['store_id']=Ajuste_Manual_Comision_16_5_Lista['STORE_ID']
# Comision_16_5_Adj['amount']=Ajuste_Manual_Comision_16_5_Lista['AMOUNT'].astype('float').round(2)
# Comision_16_5_Adj['date']=Fecha_Ajuste.strftime('%d/%m/%Y')
# Comision_16_5_Adj['reason']=Ajuste_Manual_Comision_16_5_Lista['REASON']
# Comision_16_5_Adj['description']=Ajuste_Manual_Comision_16_5_Lista['DESCRIPTION']
# Comision_16_5_Adj['type']='Condonados'

Ajuste_Manual_Iva_16_5_sql=("""
  select store_id,
       'IVA CONDONADA SEMAFORO ROJO DEL '||'"""+str(Fecha_Inicio)+"""'||' al '|| '"""+str(Fecha_Fin)+"""' AS description,
       sum(devolucion_iva) AS amount,
         CURRENT_DATE - interval '1w' AS date,
         'others_sum_commission_change' as reason
from
(
select t.store_id,
       abs(amount-(amount*0.165/COMMISSION_PERCENTAGE)) as devolucion_COMMISSION,
      devolucion_COMMISSION*0.16 as devolucion_iva
from MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions T
left join mx_pglr_ms_partner_payment_data.order_data od on od.id = t.MODEL_ID and not od._fivetran_deleted  
LEFT JOIN 
(
    SELECT *
    FROM
    (
    SELECT ORDER_ID,
           COMMISSION_PERCENTAGE,
           ROW_NUMBER() OVER (PARTITION BY ORDER_ID ORDER BY CREATED_AT::TIMESTAMP_NTZ DESC) AS UNICO
    FROM MX_PGLR_MS_PARTNER_PAYMENT_data.order_commission OC
    WHERE NOT OC._FIVETRAN_DELETED
    )
    WHERE UNICO=1
) COM ON COM.ORDER_ID=T.MODEL_ID
WHERE NOT T._FIVETRAN_DELETED AND T.TRANSACTION_REASON_ID IN (2,21,27,28) AND COMMISSION_PERCENTAGE>0.165 and od.delivery_method!='pickup' and (convert_timezone('UTC','America/Mexico_City',t.created_at::timestamp_ntz)::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""') and t.store_id in (1923204887,1923283949,1923220383,1923200368,1923200373,1923222996,1306713603,1923201445,1923285774,1923218665,1306711874,1923223057,1923218435,1923218153,1923216808,1923227582,1923243472,1306710207,1306718424,1923211039,1923239099,1923264538,1923217512,1923217721,1923217540,1923217548,1923223092,1923220766,1923211735,1923225028,1923243198,1923243414,1923249845,1923209151)
)
group by store_id   
"""     )
# cs.execute(Ajuste_Manual_Iva_16_5_sql)
# Ajuste_Manual_Iva_16_5_df=cs.fetch_pandas_all()
# if Ajuste_Manual_Iva_16_5_df.empty:
#     print("Sin información de IVA 16.5%" )
# else:
#     print("Información cargada: IVA 16.5%" )

# IVA_16_5_Adj=pd.DataFrame(columns=CSV_Headlines)
# IVA_16_5_Adj['store_id']=Ajuste_Manual_Iva_16_5_df['STORE_ID']
# IVA_16_5_Adj['amount']=Ajuste_Manual_Iva_16_5_df['AMOUNT'].astype('float').round(2)
# IVA_16_5_Adj['date']=Fecha_Ajuste.strftime('%d/%m/%Y')
# IVA_16_5_Adj['reason']=Ajuste_Manual_Iva_16_5_df['REASON']
# IVA_16_5_Adj['description']=Ajuste_Manual_Iva_16_5_df['DESCRIPTION']
# IVA_16_5_Adj['type']='Condonados'


Ajuste_Manual_ComisionPickup_16_5_sql=("""
  select store_id,
       'COMISION CONDONADA SEMAFORO ROJO DEL '||'"""+str(Fecha_Inicio)+"""'||' al '|| '"""+str(Fecha_Fin)+"""' AS description,
       sum(devolucion_COMMISSION) AS amount,
         CURRENT_DATE - interval '1w' AS date,
         'others_sum_commission_change' as reason
from
(
select t.store_id,
       abs(amount) as devolucion_COMMISSION,
       devolucion_COMMISSION*0.16 as devolucion_iva

from MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions T
left join mx_pglr_ms_partner_payment_data.order_data od on od.id = t.MODEL_ID and not od._fivetran_deleted  
LEFT JOIN 
(
  
    SELECT *
    FROM
    (
    SELECT ORDER_ID,
           COMMISSION_PERCENTAGE,
           ROW_NUMBER() OVER (PARTITION BY ORDER_ID ORDER BY CREATED_AT::TIMESTAMP_NTZ DESC) AS UNICO
    FROM MX_PGLR_MS_PARTNER_PAYMENT_data.order_commission OC
    WHERE NOT OC._FIVETRAN_DELETED
    )

    WHERE UNICO=1

) COM ON COM.ORDER_ID=T.MODEL_ID

WHERE NOT T._FIVETRAN_DELETED AND T.TRANSACTION_REASON_ID IN (2,21,27,28) and od.delivery_method='pickup' and (convert_timezone('UTC','America/Mexico_City',t.created_at::timestamp_ntz)::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""') and t.store_id in (1923204887,1923283949,1923220383,1923200368,1923200373,1923222996,1306713603,1923201445,1923285774,1923218665,1306711874,1923223057,1923218435,1923218153,1923216808,1923227582,1923243472,1306710207,1306718424,1923211039,1923239099,1923264538,1923217512,1923217721,1923217540,1923217548,1923223092,1923220766,1923211735,1923225028,1923243198,1923243414,1923249845,1923209151)
)
group by store_id
"""     )
# cs.execute(Ajuste_Manual_ComisionPickup_16_5_sql)
# Ajuste_Manual_ComisionPickup_16_5_df=cs.fetch_pandas_all()
# if Ajuste_Manual_ComisionPickup_16_5_df.empty:
#     print("Sin información de Comision PickUp 16.5%" )
# else:
#     print("Información cargada: Comision PickUp 16.5%" )

# Comision_PickUp_16_5_Adj=pd.DataFrame(columns=CSV_Headlines)
# Comision_PickUp_16_5_Adj['store_id']=Ajuste_Manual_ComisionPickup_16_5_df['STORE_ID']
# Comision_PickUp_16_5_Adj['amount']=Ajuste_Manual_ComisionPickup_16_5_df['AMOUNT'].astype('float').round(2)
# Comision_PickUp_16_5_Adj['date']=Fecha_Ajuste.strftime('%d/%m/%Y')
# Comision_PickUp_16_5_Adj['reason']=Ajuste_Manual_ComisionPickup_16_5_df['REASON']
# Comision_PickUp_16_5_Adj['description']=Ajuste_Manual_Iva_16_5_df['DESCRIPTION']
# Comision_PickUp_16_5_Adj['type']='Condonados'

Ajuste_Manual_IvaPickup_16_5_sql=("""
select store_id,
       'IVA CONDONADA SEMAFORO ROJO DEL '||'"""+str(Fecha_Inicio)+"""'||' al '|| '"""+str(Fecha_Fin)+"""' AS description,
       sum(devolucion_iva) AS amount,
         CURRENT_DATE - interval '1w' AS date,
         'others_sum_commission_change' as reason
from
(
select t.store_id,
       abs(amount) as devolucion_COMMISSION,
      devolucion_COMMISSION*0.16 as devolucion_iva

from MX_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions T
left join mx_pglr_ms_partner_payment_data.order_data od on od.id = t.MODEL_ID and not od._fivetran_deleted  
LEFT JOIN 
(
  
    SELECT *
    FROM
    (
    SELECT ORDER_ID,
           COMMISSION_PERCENTAGE,
           ROW_NUMBER() OVER (PARTITION BY ORDER_ID ORDER BY CREATED_AT::TIMESTAMP_NTZ DESC) AS UNICO
    FROM MX_PGLR_MS_PARTNER_PAYMENT_data.order_commission OC
    WHERE NOT OC._FIVETRAN_DELETED
    )

    WHERE UNICO=1

) COM ON COM.ORDER_ID=T.MODEL_ID

WHERE NOT T._FIVETRAN_DELETED AND T.TRANSACTION_REASON_ID IN (2,21,27,28) and od.delivery_method='pickup' and (convert_timezone('UTC','America/Mexico_City',t.created_at::timestamp_ntz)::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""') and t.store_id in (1923204887,1923283949,1923220383,1923200368,1923200373,1923222996,1306713603,1923201445,1923285774,1923218665,1306711874,1923223057,1923218435,1923218153,1923216808,1923227582,1923243472,1306710207,1306718424,1923211039,1923239099,1923264538,1923217512,1923217721,1923217540,1923217548,1923223092,1923220766,1923211735,1923225028,1923243198,1923243414,1923249845,1923209151)
)
group by store_id
"""     )
# cs.execute(Ajuste_Manual_IvaPickup_16_5_sql)
# Ajuste_Manual_IvaPickup_16_5_df=cs.fetch_pandas_all()
# if Ajuste_Manual_IvaPickup_16_5_df.empty:
#     print("Sin información de IVA PickUp 16.5%" )
# else:
#     print("Información cargada: IVA PickUp 16.5%" )

# IVA_PickUp_16_5_Adj=pd.DataFrame(columns=CSV_Headlines)
# IVA_PickUp_16_5_Adj['store_id']=Ajuste_Manual_IvaPickup_16_5_df['STORE_ID']
# IVA_PickUp_16_5_Adj['amount']=Ajuste_Manual_IvaPickup_16_5_df['AMOUNT'].astype('float').round(2)
# IVA_PickUp_16_5_Adj['date']=Fecha_Ajuste.strftime('%d/%m/%Y')
# IVA_PickUp_16_5_Adj['reason']=Ajuste_Manual_IvaPickup_16_5_df['REASON']
# IVA_PickUp_16_5_Adj['description']=Ajuste_Manual_IvaPickup_16_5_df['DESCRIPTION']
# IVA_PickUp_16_5_Adj['type']='Condonados'


"""--------------------------------PROPINAS---------------------------------"""
Propinas_SQL=(
"""
select op.store_id ,
       'Devolucion de COMISION cobrada Sobre Propinas del ' || '"""+str(Fecha_Inicio)+"""'||' AL '|| '"""+str(Fecha_Fin)+"""' as description,
       sum(coalesce(op.total_price,0)*commission_percentage) as amount,
       CURRENT_DATE - interval '1w' AS date, --Fecha de ajuste ojo!!! no siempre es el mismo
       'traditional_debt' as reason
from 
(
  select distinct model_id
  from mx_pglr_ms_partner_payment_public.transactions t
  where coalesce(t._fivetran_deleted, false) = false and convert_timezone('UTC','America/Mexico_City',t.created_at::timestamp_ntz)::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""'
) base 
join mx_core_orders_public.orders_vw o on o.id=base.model_id and coalesce(o._fivetran_deleted, false) = false and o.created_at::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""'
left join 
(
  select order_id, max(commission_percentage) as commission_percentage
  from mx_pglr_ms_partner_payment_data.order_commission
  where coalesce(_fivetran_deleted, false) = false
  group by 1
) oc on oc.order_id=base.model_id
join mx_core_orders_public.order_product_vw op on op.order_id=base.model_id and coalesce(op._fivetran_deleted, false) = false
join mx_grability_public.products p on p.id=op.product_id and coalesce(p._fivetran_deleted, false) = false and (p.name ilike '%propina%' and (p.type='Propina' or p.type is null) and p.active=true and p.name not ilike '%Once Relatos Mitológicos y Uno Más de Propina. Toni Llacay%')
where 1=1
and o.state in ('finished', 'pending_review')
group by 1,2,4,5
UNION ALL
select op.store_id ,
       'Devolucion de IVA cobrada Sobre Propinas del ' || '"""+str(Fecha_Inicio)+"""'||' AL '|| '"""+str(Fecha_Fin)+"""' as description,
       sum(coalesce(op.total_price,0)*commission_percentage)*0.16 as amount,
       CURRENT_DATE - interval '1w' AS date, --Fecha de ajuste ojo!!! no siempre es el mismo
       'traditional_debt' as reason
from 
(
  select distinct model_id
  from mx_pglr_ms_partner_payment_public.transactions t
  where coalesce(t._fivetran_deleted, false) = false and convert_timezone('UTC','America/Mexico_City',t.created_at::timestamp_ntz)::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""'
) base 
join mx_core_orders_public.orders_vw o on o.id=base.model_id and coalesce(o._fivetran_deleted, false) = false and o.created_at::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""'
left join 
(
  select order_id, max(commission_percentage) as commission_percentage
  from mx_pglr_ms_partner_payment_data.order_commission
  where coalesce(_fivetran_deleted, false) = false
  group by 1
) oc on oc.order_id=base.model_id
join mx_core_orders_public.order_product_vw op on op.order_id=base.model_id and coalesce(op._fivetran_deleted, false) = false
join mx_grability_public.products p on p.id=op.product_id and coalesce(p._fivetran_deleted, false) = false and (p.name ilike '%propina%' and (p.type='Propina' or p.type is null) and p.active=true and p.name not ilike '%Once Relatos Mitológicos y Uno Más de Propina. Toni Llacay%')
where 1=1
and o.state in ('finished', 'pending_review')
group by 1,2,4,5
"""
)
cs.execute(Propinas_SQL)
Propinas_df = cs.fetch_pandas_all()
if Propinas_df.empty:
    print("Sin información de Propinas" )
else:
    print("Información cargada: Propinas" )
Propinas_Adj=pd.DataFrame(columns=CSV_Headlines)

Propinas_Adj['store_id']=Propinas_df['STORE_ID']
Propinas_Adj['order_id']=''
Propinas_Adj['amount']=Propinas_df['AMOUNT']
Propinas_Adj['date']=Fecha_Ajuste
Propinas_Adj['description']=Propinas_df['DESCRIPTION']
Propinas_Adj['reason']=Propinas_df['REASON']
Propinas_Adj['type']='Propinas'


"""-----------------------AJUSTES DE PLANTILLA-----------------------------"""
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow,Flow
from google.auth.transport.requests import Request
import os
import pickle

SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

# here enter the id of your google sheet
SAMPLE_SPREADSHEET_ID_input = '1sHnqx25QXU9m_wWhN4tL-VdinPJwxViv12fyxfGl5eM'
SAMPLE_RANGE_NAME = 'MX!AN1:AS5000'

def main():
    global values_input, service
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES) # here enter the name of your downloaded JSON file
            creds = flow.run_local_server(port=0)
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    service = build('sheets', 'v4', credentials=creds)

    # Call the Sheets API
    sheet = service.spreadsheets()
    result_input = sheet.values().get(spreadsheetId=SAMPLE_SPREADSHEET_ID_input,
                                range=SAMPLE_RANGE_NAME).execute()
    values_input = result_input.get('values', [])

    if not values_input and not values_expansion:
        print('No data found.')
main()
Drive_Plantilla=pd.DataFrame(values_input[1:], columns=values_input[0])
if Drive_Plantilla.empty:
    print("Sin información de Ajustes en Plantilla" )
else:
    print("Información cargada: Ajustes Plantilla" )

Plantilla_Adj=pd.DataFrame(columns=CSV_Headlines)
Plantilla_Adj['store_id']=Drive_Plantilla['store_id'].astype('int')
Plantilla_Adj['order_id']=Drive_Plantilla['order_id']
Plantilla_Adj['amount']=Drive_Plantilla['amount'].str.replace(",",".").astype('float').round(2)
Plantilla_Adj['date']=Fecha_Ajuste
Plantilla_Adj['description']=Drive_Plantilla['description']
Plantilla_Adj['reason']=Drive_Plantilla['reason']
Plantilla_Adj['type']='Plantilla Drive'

"""-------------------CRUCE VS CONTRATACION--------------------------------"""
Adjustments_df=SO_Adj.append([Ally_Other_Adj,Sushi_Roll_Adj,Propinas_Adj,Plantilla_Adj],ignore_index=True)
"""Adjustments_df=Plantilla_Adj.append([Plantilla_Adj],ignore_index=True)"""
Cruce_Aliados_df=pd.merge(Adjustments_df,Aliados_df,on='store_id',how='left')
CPGS_Infiltrados=Cruce_Aliados_df[(Cruce_Aliados_df['FREQUENCY_TYPE_ID']==7)|(Cruce_Aliados_df['FREQUENCY_TYPE_ID']==8)|(Cruce_Aliados_df['FREQUENCY_TYPE_ID']==9)]
print("Se han encontrado",str(len(CPGS_Infiltrados)),"ajustes para store_id con frecuencia asociada a CPG's" )
Cruce_Aliados_Depurado=Cruce_Aliados_df[-((Cruce_Aliados_df['FREQUENCY_TYPE_ID']==7)|(Cruce_Aliados_df['FREQUENCY_TYPE_ID']==8)|(Cruce_Aliados_df['FREQUENCY_TYPE_ID']==9))]
Cruce_Aliados_Depurado.loc[:]['START_DATE']=pd.to_datetime(Cruce_Aliados_Depurado.loc[:]['START_DATE'])
Cruce_Aliados_Depurado.loc[:]['END_DATE']=pd.to_datetime(Cruce_Aliados_Depurado.loc[:]['END_DATE'])
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[-(Cruce_Aliados_Depurado['store_id'].isnull())]
Problemas_Contrato=Cruce_Aliados_Depurado[-((Cruce_Aliados_Depurado['START_DATE']<=Fecha_Ajuste)&(Cruce_Aliados_Depurado['END_DATE']>=Fecha_Ajuste))]
print("Se han encontrado",str(len(Problemas_Contrato)),"ajustes para store id con problemas de fechas de contrato" )
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[(Cruce_Aliados_Depurado['START_DATE']<=Fecha_Ajuste)&(Cruce_Aliados_Depurado['END_DATE']>=Fecha_Ajuste)]
Errores_Frecuencia=Cruce_Aliados_Depurado[-Cruce_Aliados_Depurado['FREQUENCY_TYPE_ID'].isin(Frecuencia)]
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[Cruce_Aliados_Depurado['FREQUENCY_TYPE_ID'].isin(Frecuencia)]
print("Se han encontrado",str(len(Errores_Frecuencia)),"ajustes para store id con frecuencias no seleccionadas" )

Adjustments_Final=pd.DataFrame(columns=CSV_Headlines)
Adjustments_Final['store_id']=Cruce_Aliados_Depurado['store_id'].astype('int')
Adjustments_Final['order_id']=Cruce_Aliados_Depurado['order_id']
Adjustments_Final['amount']=Cruce_Aliados_Depurado['amount'].astype('float').round(2)
Adjustments_Final['date']=Cruce_Aliados_Depurado['date']
Adjustments_Final['description']=Cruce_Aliados_Depurado['description']
Adjustments_Final['reason']=Cruce_Aliados_Depurado['reason']
Adjustments_Final['type']=Cruce_Aliados_Depurado['type']
Adjustments_CSV=Adjustments_Final.drop(columns=['type'])
Adjustments_CSV.to_csv('Adjustments_MX_del_'+str(FI)+'_al_'+str(FF)+'.csv',index=False)
CPGS_Infiltrados.to_excel('CPGS_Detectados.xlsx',index=False)
Problemas_Contrato.to_excel('Problemas_contrato_Incidencias.xlsx',index=False)
Errores_Frecuencia.to_excel('Ajustes_fuera_frecuencia.xlsx',index=False)

"""------------------------------PARTICIÓN---------------------------------"""
limite=900
ciclos=math.ceil(len(Adjustments_CSV)/limite)
Nombres=[]
for i in range(0,ciclos):
    Nombres.append('df_'+str(i))
df_dict = dict(('df_' + str(x), pd.DataFrame()) for x in range(0,ciclos))
for i in range(0,ciclos):
    df_dict['df_'+str(i)]=Adjustments_CSV.iloc[(limite*i):(limite*(i+1))]
for i in range(0,ciclos):
    df_dict[Nombres[i]].to_csv('Adjustments_MX_'+'Parte_'+str(i+1)+'_de_'+str(ciclos)+'.csv',index=False)
"""--------------------------------RESUMEN---------------------------------"""
Cantidad=Adjustments_Final.groupby('type')['date'].count()
Valores=Adjustments_Final.groupby('type')['amount'].sum()
Resumen=pd.DataFrame(index=Cantidad.index)
Resumen['Cantidad']=Cantidad
Resumen['Valores']=Valores
Resumen['Valores']=Resumen['Valores'].astype('float')
Resumen.loc['Ajustes Totales']= Resumen.sum()
pd.options.display.float_format = '{:.2f}'.format
print(Resumen)
pd.reset_option('^display.', silent=True)
TiempoFinal=datetime.now() - TiempoInicio
print("El proceso ha finalizado correctamente luego de",str(TiempoFinal))
print("PQRS: david.romero@rappi.com, jennifer.galeano@rappi.com")

