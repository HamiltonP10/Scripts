import os
import pandas as pd
import snowflake.connector

account = 'hg51401'
host = 'hg51401.snowflakecomputing.com'
user = 'MARCELLO.SANTOS@RAPPI.COM'
password = 'tp%a!@qZl9B9LL3SxovvriE%'
warehouse = 'GROWTH'
database = 'FIVETRAN'


con = snowflake.connector.connect(
  user = user,
  password = password,
  account = account,
  database = database
)

def execute_snowflake_query(query, with_cursor=False):
    cursor = con.cursor()
    try:
        cursor.execute(query)
        res = cursor.fetchall()
        if with_cursor:
            return (res, cursor)
        else:
            return res
    finally:
        cursor.close()

def sn_to_pd(query):
    result, cursor = execute_snowflake_query(query, with_cursor=True)
    headers = list(map(lambda t: t[0], cursor.description))
    df = pd.DataFrame(result)
    df.columns = headers
    return df

def extract_data_crossing_1st(query):
    df = pandas_df_from_snowflake_query(query)    
    return df