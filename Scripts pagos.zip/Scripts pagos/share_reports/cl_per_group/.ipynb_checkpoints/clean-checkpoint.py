#!/usr/bin/python
import os
import sys
import shutil
import pathlib
PATH = pathlib.Path().parent.resolve()

# Get directory name
mydir= "generated_excel"

try:
    shutil.rmtree(str(PATH.joinpath("generated_excel")))
    print('generated_excel removed')
except OSError as e:
    print("Error: %s - %s." % (e.filename, e.strerror))

try:
	os.mkdir(str(PATH.joinpath("generated_excel")))
except:
	print("folder created")

try:
	os.remove(str(PATH.joinpath("created.csv")))
	print ('created removed')
except:
	print ('created do not exist')
# try:
# 	os.remove('generated_excel')
# 	print ('generated_excel removed')
# except:
# 	print ('generated_excel do not exist')
