--no_cache
with paid_lots as (
select distinct pl.id as paid_lot_id,pay_start_date,pay_end_date
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl
        left join (select distinct store_id, paid_lot_id from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions) trans on pl.id = trans.paid_lot_id
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_payment_references st on st.payment_reference_id = pl.payment_reference_id and not st._fivetran_deleted
where not PL._FIVETRAN_DELETED 
and ((PAY_START_DATE>='2021-07-05'
 and PAY_END_DATE   <='2021-07-11'))-- or PAY_START_DATE = '2020-03-01') 
and pl.status<>'CANCELED' 
and st.store_id in (900041234,900069582,900069587,900069902,900069998,900069573,900069899,900069927,900070191,900070267,900070879,900070007,900070199,900071074,900072158,900072437,900069712,900069547,900113564,900069393,900069646,900069894,900069726,900070256,900072003,900070058,900070898,900115435,900069808,900069882,900070067,900069562,900069810,900069985,900070022,900070230,900071712,900071785,900122417,900069716,900069972,900071309,900130684,900121097,900069744,900040188,900069333,900069579,900069597,900070211,900070484,900069984,900070045,900070682,900127783,900069818,900069823,900070854,900072714,900069541,900069951,900069827,900069601,900069687,900069952,900070043,900070047,900070263,900070857,900070906,900115446,900119455,900070027,900112415,900071059,900068899,900069401,900069516,900069622,900069390,900069669,900069727,900069887,900069888,900070487,900071080,900069745,900069960,900069652,900153341,900154735,900038251,900069388,900069709,900069654,900069676,900069877,900070241,900071037,900072698,900120612,900122639,900142121,900070542,900070684,900028206,900070280,900070220,900019292,900069400,900069630,900069672,900070032,900069664,900069900,900069908,900069989,900070050,900071058,900115426,900069940,900070228,900070271,900071078,900071107,900120031,900069528,900070011,900127788,900070287,900070904,900114512,900038102,900069379,900069546,900069691,900070018,900070657,900071654,900069642,900069811,900069910,900070015,900070098,900070468,900071492,900115776,900119391,900122431,900142299,900071064,900071530,900120033,900053698,900069536,900069557,900069889,900069895,900069935,900070053,900070061,900070654,900113885,900119453,900127787,900070234,900070490,900072455,900118580,900119535,900138358,900070692,900039198,900040186,900042119,900069533,900069621,900069980,900070479,900070902,900119537,900069618,900069871,900071902,900116932,900124172,900069140,900069874,900069632,900069660,900069728,900069748,900069880,900069611,900069650,900069929,900070021,900070215,900070235,900070281,900071212,900071303,900071613,900070179,900115442,900115945,900069740,900069866,900153750,900017232,900040179,900055113,900069518,900069520,900069521,900069524,900069628,900069743,900070030,900069537,900069947,900070041,900070458,900115639,900124171,900069596,900069682,900069730,900071365,900113581,900071890,900153930,900025028,900031493,900069402,900069665,900069725,900069741,900069906,900070036,900070242,900071310,900128071,900070665,900128072,900070277,900025509,900038101,900040183,900040187,900069539,900069576,900070187,900069550,900069556,900069583,900069626,900069684,900069892,900070544,900071084,900116724,900117604,900127784,900069751,900071312,900071910,900072703,900071913,900115443,900024273,900069559,900069569,900069636,900069674,900069701,900069655,900070445,900072010,900123553,900138350,900128073,900069648,900069729,
900071213
)

)


,gross_value_last as (
select distinct go.order_id,max(go.created_at) as max_created
from
(
select distinct model_id
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
inner join paid_lots pl on pl.paid_lot_id = t.paid_lot_id
where not t._fivetran_deleted
) t
inner join br_PGLR_MS_PARTNER_PAYMENT_data.global_offers go on go.order_id = t.model_id AND NOT go._FIVETRAN_DELETED
where description like '%Partner App%'
group by 1
)

,gross_value as (
select go.order_id,sum(go.value) as value_add_gross
from gross_value_last gvl
inner join br_PGLR_MS_PARTNER_PAYMENT_data.global_offers go on go.order_id = gvl.order_id and gvl.max_created = go.created_at AND NOT go._FIVETRAN_DELETED
where description in ('Partner App Discount-Product','Partner App Discount')
group by 1
)

,canc_partner_value as (
select
order_id,sum(PRODUCT_PRICE+WHIM_PRICE-MARKUP) as gross_value
from
(
select distinct model_id
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
inner join paid_lots pl on pl.paid_lot_id = t.paid_lot_id
where not t._fivetran_deleted
) t
left join GLOBAL_FINANCES.br_ORDER_DETAILS dd on dd.order_id = t.model_id
group by 1
)

,md_ptn as (
select model_id,sum(odd.value) as ally_md
from
(
select distinct model_id
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
inner join paid_lots pl on pl.paid_lot_id = t.paid_lot_id
where not t._fivetran_deleted
) t
left join br_core_orders_public.order_discounts od on od.order_id::text = t.model_id::text and coalesce(od._fivetran_deleted,false) = false
left join br_core_orders_public.order_discount_details odd on odd.order_discount_id = od.id and coalesce(odd._fivetran_deleted,false) = false
where offertable_type = 'offer-base-price'
group by 1
)

,v2 as (
select
pl.paid_lot_id,
s.store_id,
s.name as loja,
t.model_id,
pl.pay_start_date,
pl.pay_end_date,
sum(case when t.transaction_reason_id in (1,20) then t.amount else 0 end) as sales,
max(value_add_gross) as value_add_gross,
max(ally_md) as ally_md,
max(gross_value) as gross_value,
sum(case when t.transaction_reason_id in (2,21,27,28) then t.amount else 0 end) as commission,
sum(case when t.transaction_reason_id = 18 then t.amount else 0 end) as compensations,
sum(case when t.transaction_reason_id = 19 then t.amount else 0 end) as cash_mp,
sum(case when t.transaction_reason_id = 3 then t.amount else 0 end) as sale_tax,
sum(case when t.transaction_reason_id = 10 then t.amount else 0 end) as cancellation,
sum(case when t.transaction_reason_id in (23,24,26) then t.amount else 0 end) as shipping_partner,
sum(case when t.transaction_reason_id = 29 then t.amount else 0 end) as rt_pay,
sum(case when t.transaction_reason_id in (31) then t.amount else 0 end) as free_shipping,
sum(case when t.transaction_reason_id in (32) then t.amount else 0 end) as free_shipping_prendido,
sum(case when ar.id = 3 then t.amount else 0 end) as adj_tablet_fee,
sum(case when ar.id in (4,14) then t.amount else 0 end) as adj_commission,
sum(case when a.id is not null and ar.id not in (3,4,14) then t.amount else 0 end) as adjustments_other,
sum(case when t.transaction_reason_id = 8 then t.amount else 0 end) as cofins,
sum(case when t.transaction_reason_id = 12 then t.amount else 0 end) as pis,
sum(case when t.transaction_reason_id = 47 then t.amount else 0 end) as iss,
sum(case when t.transaction_reason_id = 45 then t.amount else 0 end) as meal_vouchers,
sum(case when t.transaction_reason_id = 48 then t.amount else 0 end) as fee_cc_mp,
sum(t.amount) as total_value

from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores s on s.store_id = t.store_id and not s._fivetran_deleted
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.adjustments a on a.id = t.model_id and t.flow_name = 'adjustment' and not a._fivetran_deleted
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.adjustment_reasons ar on ar.id = a.adjustment_reason_id and not ar._fivetran_deleted
left join gross_value gv on gv.order_id = t.model_id
inner join paid_lots pl on pl.paid_lot_id = t.paid_lot_id
left join md_ptn mp on mp.model_id = t.model_id
left join canc_partner_value cpv on cpv.order_id = t.model_id

where not t._fivetran_deleted

group by 1,2,3,4,5,6
)

select
paid_lot_id,
v2.model_id as order_id,
v2.store_id,
ca.city,
v2.loja,
o.created_at::date::varchar as date_created,
o.created_at::varchar as hora,
o.state as estado,
o.payment_method,
case when coalesce(sales,0) >0 then coalesce(sales,0)+coalesce(value_add_gross,0)+coalesce(ally_md,0) else 0 end as valor,
case when coalesce(sales,0) >0 then coalesce(ally_md,0)+coalesce(value_add_gross,0) else 0 end as desc_aliado,
sales,
cash_mp,
shipping_partner,
commission,
compensations,
fee_cc_mp,
free_shipping,
free_shipping_prendido,
meal_vouchers,
adj_tablet_fee+adj_commission+adjustments_other as adjustments,
v2.total_value,
cofins,
pis,
iss,
case when o.state in ('canceled_by_partner_inactivity') then coalesce(gross_value,0)-coalesce(value_add_gross,0)-coalesce(ally_md,0) else 0 end as cbpi,
case when o.state in ('canceled_partner_order_refused') then coalesce(gross_value,0)-coalesce(value_add_gross,0)-coalesce(ally_md,0) else 0 end as cbpr,
to_char(pay_start_date , 'DD/MM/YYYY') as pay_start_date,
to_char(pay_end_date , 'DD/MM/YYYY') as pay_end_date

from v2
left join br_core_orders_public.orders o on o.id = v2.model_id
left join br_grability_public.stores s on s.store_id = v2.store_id and coalesce(s._fivetran_deleted,false) = false
left join br_grability_public.city_addresses ca on ca.id = s.city_address_id and coalesce(ca._fivetran_deleted,false) = false
left join br_grability_public.store_brands sb on sb.id = s.store_brand_id and coalesce(sb._fivetran_deleted,false) = false
