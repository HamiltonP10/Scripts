--no_cache
with paid_lots as (
select distinct pl.id as paid_lot_id,pay_start_date,pay_end_date
from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores st on st.payment_reference_id = pl.payment_reference_id and not st._fivetran_deleted
  where not PL._FIVETRAN_DELETED 
and PAY_START_DATE >='2021-07-19'
 and  PAY_END_DATE <='2021-07-25'
   --and pl.status<>'CANCELED'
    --and st.is_marketplace = false
  --and st.store_id in (select distinct store_id from br_writable.partner_payment_groups where group_name ilike '%califor%')

)

,contract_conditions as (
select distinct sc.store_id,last_value(cc.value) over (partition by sc.store_id order by cc.id) as cancellation_perc
from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_contracts sc on sc.store_id = t.store_id and not sc._fivetran_deleted
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts c on c.id = sc.contract_id and not c._fivetran_deleted
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contract_conditions cc on cc.contract_id = c.id and not cc._fivetran_deleted
where not t._fivetran_deleted and c.is_active = true and c.start_date::date < current_date() and c.end_date::date > current_date()
and cc.contract_condition_type_id = 13
)

,gross_value_last as (
select distinct go.order_id,max(go.created_at) as max_created
from
(
select distinct model_id
from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
inner join paid_lots pl on pl.paid_lot_id = t.paid_lot_id
where not t._fivetran_deleted
) t
inner join mx_PGLR_MS_PARTNER_PAYMENT_data.global_offers go on go.order_id = t.model_id AND NOT go._FIVETRAN_DELETED
where description like '%Partner App%'
group by 1
)

,gross_value as (
select go.order_id,sum(go.value) as value_add_gross
from gross_value_last gvl
inner join mx_PGLR_MS_PARTNER_PAYMENT_data.global_offers go on go.order_id = gvl.order_id and date_trunc(second,gvl.max_created) = date_trunc(second,go.created_at) AND NOT go._FIVETRAN_DELETED
where description in ('Partner App Discount-Product','Partner App Discount')
group by 1
)


,canc_partner_value as (
select
order_id,sum(PRODUCT_PRICE+WHIM_PRICE-MARKUP) as gross_value
from
(
select distinct model_id
from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
inner join paid_lots pl on pl.paid_lot_id = t.paid_lot_id
where not t._fivetran_deleted
) t
left join GLOBAL_FINANCES.mx_ORDER_DETAILS dd on dd.order_id = t.model_id
group by 1
)

,md_ptn as (
select model_id,sum(odd.value) as ally_md
from
(
select distinct model_id
from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
inner join paid_lots pl on pl.paid_lot_id = t.paid_lot_id
where not t._fivetran_deleted
) t
left join mx_core_orders_public.order_discounts od on od.order_id::text = t.model_id::text and coalesce(od._fivetran_deleted,false) = false
left join mx_core_orders_public.order_discount_details odd on odd.order_discount_id = od.id and coalesce(odd._fivetran_deleted,false) = false
where offertable_type = 'offer-base-price'
group by 1
)

,v2 as (
select
t.paid_lot_id,
pl.pay_start_date,
pl.pay_end_date,
s.store_id,
s.name as loja,
t.model_id,
sum(case when t.transaction_reason_id in (1,20) then t.amount else 0 end) as sales,
max(value_add_gross) as value_add_gross,
max(ally_md) as ally_md,
max(gross_value) as gross_value,
sum(case when t.transaction_reason_id in (2,21,27,28) then t.amount else 0 end) as commission,
sum(case when t.transaction_reason_id = 18 then t.amount else 0 end) as compensations,
sum(case when t.transaction_reason_id = 3 then t.amount else 0 end) as sale_tax,
sum(case when t.transaction_reason_id = 10 then t.amount else 0 end) as cancellation,
sum(case when ar.id = 3 then t.amount else 0 end) as adj_tablet_fee,
sum(case when ar.id in (4,14) then t.amount else 0 end) as adj_commission,
sum(case when a.id is not null and ar.id not in (3,4,14) then t.amount else 0 end) as adjustments_other,
sum(case when t.transaction_reason_id = 19 then t.amount else 0 end) as discount_by_marketplace_in_cash,
sum(case when t.transaction_reason_id in (23,24) then t.amount else 0 end) as shipping_partner,
sum(case when t.transaction_reason_id = 29 then t.amount else 0 end) as rt_pay,
sum(case when t.transaction_reason_id in (31) then t.amount else 0 end) as free_shipping,
sum(case when t.transaction_reason_id in (32) then t.amount else 0 end) as free_shipping_tienda,

sum(t.amount) as total_value

from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores s on s.store_id = t.store_id and not s._fivetran_deleted
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.adjustments a on a.id = t.model_id and t.flow_name = 'adjustment' and not a._fivetran_deleted
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.adjustment_reasons ar on ar.id = a.adjustment_reason_id and not ar._fivetran_deleted
left join gross_value gv on gv.order_id = t.model_id
inner join paid_lots pl on pl.paid_lot_id = t.paid_lot_id
left join md_ptn mp on mp.model_id = t.model_id
left join canc_partner_value cpv on cpv.order_id = t.model_id

where not t._fivetran_deleted
and s.is_marketplace = false

group by 1,2,3,4,5,6
)

select
paid_lot_id,
v2.store_id,
v2.loja,
sb.name as brand,
v2.model_id as order_id,
o.created_at::date::varchar as date_created,
o.created_at::varchar as hora,
ca.city,
o.state as estado,
o.payment_method,
case when o.cooking_time > 0 then 'Si' else 'No' end as pago_cred,
case when coalesce(sales,0) >0 then coalesce(sales,0)+coalesce(value_add_gross,0)+coalesce(ally_md,0) else 0 end as valor,
case when coalesce(sales,0) >0 then coalesce(ally_md,0)+coalesce(value_add_gross,0) else 0 end as desc_aliado,
sales,
commission,
rt_pay,
cancellation_perc,
compensations,
adj_tablet_fee+adj_commission+adjustments_other as adjustments,
free_shipping+free_shipping_tienda as free_shipping,
cancellation,
adj_tablet_fee,
adj_commission,
adjustments_other,
sale_tax,
case when o.cooking_time > 0 and o.state not like '%cancel%' then sales else 0 end as cred_fin,
case when o.cooking_time > 0 and o.state like '%cancel%' then sales else 0 end as cred_canceled,
case when (o.cooking_time = 0 or o.cooking_time is null) then sales else 0 end as punto_ventas,
case when o.state in ('canceled_by_partner_inactivity') then coalesce(gross_value,0)-coalesce(value_add_gross,0)-coalesce(ally_md,0) else 0 end as cbpi,
case when o.state in ('canceled_partner_order_refused') then coalesce(gross_value,0)-coalesce(value_add_gross,0)-coalesce(ally_md,0) else 0 end as cbpr,
coalesce(gross_value,0)-coalesce(value_add_gross,0)-coalesce(ally_md,0) as gross_value,
to_char(pay_start_date , 'DD/MM/YYYY') as pay_start_date,
to_char(pay_end_date , 'DD/MM/YYYY') as pay_end_date

from v2
left join mx_core_orders_public.orders o on o.id = v2.model_id and coalesce(o._fivetran_deleted,false) = false
left join mx_grability_public.stores s on s.store_id = v2.store_id and coalesce(s._fivetran_deleted,false) = false
left join mx_grability_public.city_addresses ca on ca.id = s.city_address_id and coalesce(ca._fivetran_deleted,false) = false
left join mx_grability_public.store_brands sb on sb.id = s.store_brand_id and coalesce(sb._fivetran_deleted,false) = false
left join contract_conditions cc on cc.store_id = v2.store_id