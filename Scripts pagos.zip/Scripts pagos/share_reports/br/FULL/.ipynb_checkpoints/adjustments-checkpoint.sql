--query4

with paid_lots as (
select distinct pl.id as paid_lot_id,pay_start_date,pay_end_date
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl
    left join (select distinct store_id, paid_lot_id from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions) trans on pl.id = trans.paid_lot_id
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_payment_references st on st.payment_reference_id = pl.payment_reference_id and not st._fivetran_deleted
  where not PL._FIVETRAN_DELETED 
  and PAY_START_DATE >='2021-07-19'
  and pay_end_date   <='2021-07-25'
 and pl.status<>'CANCELED' 

)

select pl.paid_lot_id,a.store_id,st.name as store_name,t.created_at::date::varchar as fecha, description, t.amount
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.adjustments a
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t on t.model_id = a.id and not t._fivetran_deleted
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores st on st.store_id = t.store_id and not st._fivetran_deleted
left join paid_lots pl on pl.paid_lot_id = t.paid_lot_id