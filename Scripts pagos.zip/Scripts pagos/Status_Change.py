# -*- coding: utf-8 -*-
"""
Created on Fri Jun 10 17:04:12 2022

@author: Hamilton.Pacanchique
"""

## Importación de librerías ##

import pandas as pd 
import os
import json
import requests



email='hamilton.pacanchique@rappi.com'
token ='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjk4NjksImlhdCI6MTY1NDkxMDg0NCwiZXhwIjoxNjU0OTk3MjQ0LCJpc3MiOiJsdXBlLWdvb2dsZS1hdXRoIn0.GlgdSaoJsh28vS5_9kecVPVe0lHF3driUJ974YAM3Vk'
   

environments = {
    
    'MX': 'https://services.mxgrability.rappi.com',
    'PE': 'https://services.rappi.pe',
    'AR': 'https://services.rappi.com.ar',
    'CR': 'https://services.rappi.co.cr',
    'CO': 'https://services.rappi.com',
    'CL': 'https://services.rappi.cl',
    'UY': 'https://services.rappi.com.uy',
    'EC': 'https://services.rappi.com.ec',
    'BR': 'https://services.rappi.com.br',
    'dev': 'http://microservices.dev.rappi.com'
}

dir = os.getcwd()  
dir = dir+"\Archivos"
print (dir)      

####   Extraer información de archivos

dir = os.getcwd()                                                                            ## Traer la información de la ruta actual
dir = dir+"\Archivos"                                                                                       
files = os.listdir(dir)                                                                      ##Listar archivos de la ruta
files = pd.DataFrame(files)
cantidad =len(files)-1
print (files)
       
 
for i in range(0,len(files)) :
    
    filename = files[0][i]
    country = filename[-6:]
    country = country[:2]
    environment = environments[country] 
    data = pd.read_csv(filename, header=0)


    if 'PAUSAR_FRAUDE' in filename:
        
        for l in range(0,len(data)):
            
            status = "PAUSED"
            pl_id  = data.iloc[l,0] 
            
            business_structure= {                                                     ## Se crea la estructura de acuerdo a los nombres de campo
                  "paid_lot_ids": [int(pl_id)],                                      
                  "status": status,
                  "email" : email
                  
                }
            
            headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
                    }
            
          
         
            body_data = json.dumps(business_structure)                                                                                                                   ## Se crea la estructura en formato json                                                
            response = requests.put(f'{environment}/lupe/external/api/microservices/partner-payment/paid-lot/update-status/',data=body_data, headers=headers)             ## Se ejecuta la solicitud al ms
         
            print('*********ACTUALIZACIÓN PAIDLOT: '+str(pl_id)+' NUEVO ESTADO: '+status+' ********')
            print(body_data)
            print(pl_id)
            print('adjustment: '+ str(response.status_code))
            print(response.json()) 
        
                       
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        
        

            