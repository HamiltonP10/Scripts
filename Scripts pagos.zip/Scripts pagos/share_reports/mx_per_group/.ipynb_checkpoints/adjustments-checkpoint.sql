with paid_lots as (
select distinct pl.id as paid_lot_id,pay_start_date,pay_end_date
from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores st on st.payment_reference_id = pl.payment_reference_id and not st._fivetran_deleted
  where not PL._FIVETRAN_DELETED 
 -- and PAY_START_DATE>='2020-03-01' 
  and pl.status<>'CANCELED'
    and st.is_marketplace = false
  --and st.store_id in (1923234530 , 1923234531)--(select store_id from br_writable.partner_payment_groups where country = 'MX')
)

select pl.paid_lot_id,a.store_id,st.name as store_name,t.created_at::date::varchar as fecha, description, t.amount
from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.adjustments a
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t on t.model_id = a.id and not t._fivetran_deleted
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores st on st.store_id = t.store_id and not st._fivetran_deleted
inner join paid_lots pl on pl.paid_lot_id = t.paid_lot_id