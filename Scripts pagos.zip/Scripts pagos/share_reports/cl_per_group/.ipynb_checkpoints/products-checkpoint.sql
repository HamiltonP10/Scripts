--no_cache
------ Relacion Productos --------
with paid_lots as
(
  select distinct pl.id as paid_lot_id
  from cl_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl
  left join cl_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
  where not PL._FIVETRAN_DELETED 
and PAY_START_DATE >='2022-07-25'
and PAY_END_DATE   <='2022-07-31'
  and pl.status<>'CANCELED'
  --and pl.store_id in (900018685,900018686,900018687,900018688)  
)

,ord as
(
  select
        model_id as order_id,
        o.created_at as order_created_at,
        o.state as order_status,
        o.payment_method,
        o.cooking_time,
        s.store_id,
        s.store_brand_id as brand_id,
        s.name as store_name,
        sb.name as brand_name,
        ca.city,
        t.paid_lot_id,
        max(case when t.transaction_reason_id = 1 then 1 else 0 end) as order_type
  from cl_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
  inner join paid_lots pl on pl.paid_lot_id=t.paid_lot_id
  left join cl_core_orders_public.orders o on o.id = t.model_id and not o._fivetran_deleted
  left join cl_grability_public.stores s on s.store_id = t.store_id and not s._fivetran_deleted
  left join cl_grability_public.store_brands sb on sb.id = s.store_brand_id and not sb._fivetran_deleted
  left join cl_grability_public.city_addresses ca on ca.id = s.city_address_id and not ca._fivetran_deleted

  where not t._fivetran_deleted
        and s.is_marketplace = false
        and t.transaction_reason_id in (1,20)
  group by 1,2,3,4,5,6,7,8,9,10,11
)

,merge as
(
  select
        o.paid_lot_id,
        o.order_id,
        op.store_id,
        ss.name,
        brand_name,
        o.order_created_at::timestamp as order_created_at,
        o.order_status,
        o.city,
        o.payment_method,
        case when o.cooking_time > 0 then 'tablet' else 'fuera_tablet' end as order_type,
        o.COOKING_TIME,
        op.product_id,
        p.name as NProducto,

        sum(op.units) as units,
        sum(op.total_price - (coalesce (opb.total_debt_value,0))) as Valor

  from ord o
  left join cl_core_orders_public.order_product op on o.order_id = op.order_id and op._fivetran_deleted = 'FALSE'
  left join cl_grability_public.stores ss on op.store_id = ss.store_id and ss._fivetran_deleted = 'FALSE'
  left join (select distinct order_product_id, total_debt_value from cl_core_orders_public.order_product_debts where _fivetran_deleted = 'FALSE') opb  on op.id = opb.order_product_id
  left join cl_grability_public.products p on p.id=op.product_id  and p._fivetran_deleted = 'FALSE'

  group by 1,2,3,4,5,6,7,8,9,10,11,12,13
)

,offer_base as
(
select dd.discount_order_id as oid,coalesce(odd.product_id,odd2.product_id) as product_id, sum(discount_value) as descuentoAliado
from GLOBAL_FINANCES.cl_DISCOUNT_DETAILS dd
left join cl_core_orders_public.order_discount_details odd on odd.id = dd.order_discount_detail_id and coalesce(odd._fivetran_deleted,false)=false
left join 
(
select od.order_id,max(coalesce(odd.product_id,gop.product_id)) as product_id 
from cl_core_orders_public.order_discounts od 
left join cl_core_orders_public.order_discount_details odd on odd.order_discount_id = od.id and coalesce(odd._fivetran_deleted,false) = false
left join cl_pg_ms_global_offers_public.global_offer_products gop on gop.global_offer_id = odd.offertable_id and coalesce(gop._fivetran_deleted,false) = false
inner join cl_core_orders_public.order_product op on op.product_id = gop.product_id and op.order_id = od.order_id and coalesce(op._fivetran_deleted,false) = false
where lower(odd.offertable_type) like '%global%' and coalesce(odd._fivetran_deleted,false) = false
group by 1
) odd2 on odd2.order_id = dd.discount_order_id
where assumed_by = 'Ally'
group by 1,2
)

,offer_base_r as
(
select distinct od.order_id as oid,odd.product_id, sum(value) as descuentorappi
from cl_core_orders_public.order_discounts od
left join cl_core_orders_public.order_discount_details odd on odd.order_discount_id = od.id and odd._fivetran_deleted = 'FALSE' and od._fivetran_deleted = 'FALSE'
where odd.offertable_type = 'offer-base-price-rappi' and coalesce(od._fivetran_deleted,false) = false
group by 1,2
)

,datos as
(
  select a.*,
        coalesce(ob.descuentoAliado,0) as descuentoAliado,
        coalesce(obr.descuentorappi,0) as descuentorappi,
        (a.Valor - coalesce(ob.descuentoAliado,0)) as Real,
        case when a.payment_method not in ('cash') and a.order_status in ('finished','pending_review','canceled_by_user_app_with_charge') then 'Si' else 'No' end as Baseretenciones
  from merge a
  left join offer_base ob on ob.oid = a.order_id and a.product_id = ob.product_id
  left join offer_base_r obr on obr.oid = a.order_id and a.product_id = obr.product_id
)

------Antojos Puros
,antojos_puros as
(
  SELECT
        spi.store_Id as store_id ,
        sb.name as store_name ,
        st.name as name ,
        PARTNER_PAYMENT.order_id as id,
        PARTNER_PAYMENT.order_created_at::date as created_at,
        PARTNER_PAYMENT.order_created_at as time,
        PARTNER_PAYMENT.city ,
        PARTNER_PAYMENT.order_status as state ,
        PARTNER_PAYMENT.payment_method as payment_method ,
        case when order_type = 'fuera_tablet' then 'NO' else 'SI' end as "Pago a Credito",
        1 as Units,
        ow.name as producto,
        ow.whim_value as valor,
        0 as descuentoAliado,
        0 as descuentorappi,
        ow.whim_value as real

  from datos PARTNER_PAYMENT
  left join CL_CORE_ORDERS_PUBLIC.order_reference_point orp on orp.order_id=PARTNER_PAYMENT.order_id and orp._fivetran_deleted <> TRUE
  left join (select distinct order_id, sum(price) as whim_value, listagg(name, '|') as name from cl_core_orders_public.order_whims where _fivetran_deleted <> TRUE and state = 'confirmed' group by 1) ow on ow.order_id=PARTNER_PAYMENT.order_id
  left join cl_core_orders_public.order_product op on op.order_id=PARTNER_PAYMENT.order_id and op._fivetran_deleted <> TRUE
  left join cl_grability_public.store_place_information spi on spi.id=orp.google_place_id and spi._fivetran_deleted <> TRUE
  inner join ( select stores.* from cl_grability_public.stores ) st on st.store_id=spi.store_Id and st._fivetran_deleted <> TRUE
  left join (select distinct conditionable_id from cl_grability_public.delivery_conditions where type = 'cashless_required' and _fivetran_deleted <> TRUE ) dc on dc.conditionable_id=spi.store_id
  left join cl_grability_public.store_brands sb on st.store_brand_id=sb.id and sb._fivetran_deleted <> TRUE
  where
        orp.order_id is not null
        and op.order_id is null
        and ow.order_id is not null
        and st.type in ('restaurant','dompedro_restaurantes','restaurantes_tucuruvi')
        and dc.conditionable_id is not null
        and st.is_marketplace = 'f'
        and order_status in ('finished','pending_review')
)

,antojos as
(
  select
        o.paid_lot_id,
        o.store_id,
        o.name as name,
        o.order_id as id,
        o.order_created_at::date as created_at,
        o.order_created_at as time,
        o.city ,
        o.order_status,
        o.payment_method,
        case when o.order_type = 'fuera_tablet' then 'NO' else 'SI'end as "Pago a Credito",
        1 as Units,
        replace(replace(replace(replace(replace(replace(listagg(ow.name, '|'),',',' '),'.',' '),';',' '),' ',' '),'
        ',' '),'
         ',' ') ::text as producto,

        sum(ow.price) as valor,
        0 as descuentoAliado,
        sum(ow.price) as real

  from
  (select distinct
  paid_lot_id,store_id,brand_name,name,order_id,order_created_at,city,order_status,payment_method,order_type
  from merge) o
  left join cl_core_orders_public.order_whims ow on ow.order_id=o.order_id and ow._fivetran_deleted <> TRUE and ow.state = 'confirmed'
  where ow.price is not null
  group by 1,2,3,4,5,6,7,8,9,10,11
),

fin as
(
  select
          datos.paid_lot_id,
          coalesce(datos.store_id,antojos_puros.store_id) as store_id ,
          coalesce(datos.name,antojos_puros.store_name)  as "Store Name",
          datos.order_id as "ID",
          datos.order_created_at::date::varchar as "created_at",
          datos.order_created_at::varchar as "Time",
          datos.city, datos.order_status as "State",
          datos.payment_method,
          case when (datos.order_type = 'fuera_tablet') then 'NO' else 'SI'end as "Pago a Credito",
          coalesce(datos.units, antojos_puros.units) as units,
          replace(replace(replace(replace(replace(replace(coalesce(datos.NProducto , antojos_puros.producto),',',' '),'.',' '),';',' '),' ',' '),'
          ',' '),'
           ',' ') ::text as producto,
          coalesce(datos.valor, antojos_puros.valor) as valor,
          datos.descuentoAliado,
          coalesce(datos.real, antojos_puros.real) as "Valor Real"
  from datos
  left join antojos_puros on antojos_puros.id = datos.order_id
  union all
  select *
  from antojos
)

select *
from fin