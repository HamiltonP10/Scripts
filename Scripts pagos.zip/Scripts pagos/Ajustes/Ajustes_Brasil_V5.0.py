# -*- coding: utf-8 -*-
"""
Created on Tue Jan  5 14:30:50 2021

@author: David.Romero
"""
"""--------------------------------PARÁMETROS------------------------------"""

#Parametros de Busqueda
FI="2021-08-16"            #Search start date
FF="2021-08-22"            #Search end date
FA="2021-08-22"            #Adjustment creation date
Frecuencia=(1,3)           #Frequency codes for search



"""------------------------------------------------------------------------"""
"""--------------PELASE DO NOT MODIFY ANYTHING FROM HERE ON----------------"""
#Importación de Librerias
import snowflake.connector as sf
import pandas as pd
import math
from datetime import datetime
TiempoInicio= datetime.now()
#Creación de la conexión con Snowflake
con = sf.connect(
user= 'BI_PAGOS_USER',
password= 'TvPVriohtYT*%oqvnZ$@UzY2',
account= 'hg51401',
warehouse='VARIABLE_LOAD',
database='FIVETRAN',
schema='PUBLIC'
)
#Cursor o consola de Sql en Python
cs=con.cursor()
Fecha_Ajuste=pd.to_datetime(FA).date()
Fecha_Inicio=pd.to_datetime(FI).date()
Fecha_Fin=pd.to_datetime(FF).date()
pd.set_option('display.max_columns', None)

print("Bom dia, o tempo médio de execução é de 3 min")
print("Os ajustamentos serão criados para o período "+str(Fecha_Inicio)+" a "+str(Fecha_Fin),"Freq. =",Frecuencia)

"""------------------------------Checking Querys---------------------------"""
Check_2_sql=(
"""
--CHECK 2 -- orders pendientes
--no_cache
with orders_period as (
  select o.id as order_id, o.payment_method, o.total_value, o.tip, o.cooking_time, o.created_at, o.address_description, o.state
  from br_core_orders_public.orders o
  left join br_core_orders_calculated_information.orders o2 on o2.order_id = o.id
  left join br_grability_public.stores s on s.store_id = o2.store_id
  left join br_PG_MS_PARTNER_PAYMENT_PUBLIC.stores s2 on s2.store_id = s.store_id
  left join (select distinct order_id from br_core_orders_public.order_modifications where type in ('hand_to_domiciliary','ready_for_pick_up')) om on om.order_id = o.id
  left join (select distinct conditionable_id from br_grability_public.delivery_conditions where type in ('cashless_required','no_pay') and coalesce(_fivetran_deleted,false)=false) dc on dc.conditionable_id = s.store_id
  where o.created_at::date>='"""+str(Fecha_Inicio)+"""'
  and o.created_at::date<='"""+str(Fecha_Fin)+"""'
  --and s.store_id in (900162799,900161393)
  --and gs.store_brand_id in (114296,114297,112580)
  and coalesce(o._fivetran_deleted,false)=false
  and
  (
(s.is_marketplace=false and conditionable_id is not null and (o.cooking_time > 0 or (o.state in ('finished','pending_review') and o2.city_address_id <> 10 and s.city_address_id <> 10) or (om.order_id is not null and o2.city_address_id <> 10 and s.city_address_id <> 10)) and (o.state in ('finished','pending_review') or o.state like '%cancel%'))
or
(s.is_marketplace=true and o.state in ('finished','pending_review'))
)
  )
,cr as
(
select op.order_id
, params
, max(get_path(get_path(PARSE_JSON(get_path(params, 'cancellation_info')), 'reason'),
'description')) as reason_id
, max(get_path(get_path(PARSE_JSON(get_path(params, 'cancellation_info')), 'reason'), 'id')) as reasons_ids
from orders_period op
inner join br_core_orders_public.order_modifications om on om.order_id = op.order_id
where type in ('canceled_from_cms', 'cancel_by_support_with_charge')
group by 1, 2
)
,stores as (
  select s.store_id, s.name as tienda, sb.name as brand_name,s.is_marketplace
  from br_grability_public.stores s
  left join br_grability_public.city_addresses ca on s.city_address_id = ca.id and coalesce(ca._fivetran_deleted,false)=false
  left join br_grability_public.store_brands sb on s.store_brand_id=sb.id  and coalesce(sb._fivetran_deleted,false)=false
  left join (select distinct conditionable_id, listagg(type,',') as marca
             from br_grability_public.delivery_conditions dc
             where type in ('cashless_required','no_pay')
             and coalesce(dc._fivetran_deleted,false)=false
             group by 1) dc on s.store_id = dc.conditionable_id
  WHERE  coalesce(s._fivetran_deleted,false)=false and s.type = 'restaurant'
  )
,productos as (
  select op.order_id, op.store_id, op.product_id, op.units, sum(op.total_price - coalesce(opd.total_debt_value, 0)) as valor_productos
  from orders_period o
  join br_core_orders_public.order_product op on o.order_id=op.order_id and coalesce(op._fivetran_deleted,false)=false
  left join br_core_orders_public.order_product_debts opd on op.id=opd.order_product_id and coalesce(opd._fivetran_deleted,false)=false
  group by 1,2,3,4
  )
,descuentos as (
  select o.order_id, odd.product_id, odd.applied_units,
  sum(case when odd.offertable_type='offer-base-price' then odd.value else 0 end) as markdown,
  sum(case when go.description IN ('Partner App Discount-Product','Partner App Discount')
      and odd.value >0 and odd.type = '7' then odd.value else 0 end) as desc_productos_partner_app,
  sum(case when go.type = 'free_shipping'and go.description = 'Automatic restaurants-tech offer'
      and odd.type = '7' then odd.value else 0 end) as free_shipping,
  sum(case when go.description IN ('Partner App Discount-Shipping') and odd.value >0 and odd.type = '7'
      then odd.value else 0 end) as free_shipping_partner_app
  from orders_period o
  left join br_core_orders_public.order_discounts od on o.order_id=od.order_id and coalesce(od._fivetran_deleted,false) =false
  left join br_core_orders_public.order_discount_details odd on od.id=odd.order_discount_id and coalesce(odd._fivetran_deleted,false) =false
  left join br_PG_MS_GLOBAL_OFFERS_PUBLIC.global_offers go on go.id = odd.offertable_id
  group by 1,2,3
  )
,descuentos_orden as (
  select order_id, sum(coalesce(desc_productos_partner_app,0)) as desc_productos_partner_app,
  sum(coalesce(free_shipping,0)+coalesce(free_shipping_partner_app, 0)) as free_shipping
  from Descuentos
  group by 1
  )
,valor_ventas as (
         select
       op.order_id,
       max(store_id) as store_id,
       sum(coalesce(op.valor_productos,0)) as valor_venta_gross,
       sum(coalesce(op.valor_productos,0) - coalesce(opm.markdown,0)) as valor_venta
       from productos op
       left join descuentos opm on op.order_id=opm.order_id and op.product_id=opm.product_id and op.units=opm.applied_units
       group by 1
  )
,antojos as (
  select  o.order_id,
  sum(price) as venta_antojo, listagg(name, ', ') as name
  from orders_period o
  left join br_core_orders_public.order_whims ow on o.order_id=ow.order_id and coalesce(ow._fivetran_deleted,false)=false and ow.state = 'confirmed'
  where ow.price is not null
  group by 1
  )
,antojo_puro as (
  select a.order_id, spi.store_id, sum(venta_antojo) as antojo_puro
  from antojos a
  left join br_core_orders_public.order_reference_point orp on orp.order_id=a.order_id and coalesce(orp._fivetran_deleted,false)=false
  left join br_core_orders_public.order_product op on op.order_id=a.order_id and coalesce(op._fivetran_deleted,false)=false
  left join br_grability_public.store_place_information spi on spi.id=orp.google_place_id and coalesce(spi._fivetran_deleted,false)=false
  inner join stores st on st.store_id=spi.store_Id
  where op.order_id is null
  group by 1,2
  )
,orders_total as (
  select coalesce(op.store_id,ap.store_id) as store_id,
  o.order_id,
  o.created_at as order_created_at,
  o.state,
  sum(coalesce(op.valor_venta,0)+coalesce(a.venta_antojo, 0)+coalesce(ap.antojo_puro, 0)-coalesce(d.desc_productos_partner_app, 0)) as grab_value,
  count(distinct o.order_id) as grab_ord
  from orders_period o
  left join valor_ventas op on o.order_id = op.order_id
  left join antojos a on o.order_id = a.order_id
  left join antojo_puro ap on o.order_id = ap.order_id
  left join descuentos_orden d on o.order_id = d.order_id
  left join cr on cr.order_id = o.order_id
  left join br_PGLR_MS_PARTNER_PAYMENT_data.order_data od on od.id = o.order_id
  where (op.store_id is not null or ap.store_id is not null)
   and (od.cancel_reason is null or
 od.cancel_reason not in (1, 13, 14, 16, 25, 27, 28, 32, 33, 39, 42, 51, 53, 65, 66, 68, 74, 75, 77, 79, 79, 84, 84, 85, 85, 91, 91, 92, 92, 103, 103, 105, 110, 111, 117, 118, 120, 129, 131, 136, 137, 143, 146, 157, 163, 169, 172, 181))
  group by 1,2,3,4
  )
/*,paid_lots as
(
select distinct pl.id as paid_lot_id
from informatica.br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl
left join informatica.br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
where not PL._FIVETRAN_DELETED and [PAY_START_DATE=1_start_date_pa] and [PAY_END_DATE=2_end_date_pa] and [pl.status=estado_pl_v2]
)*/
,ord as (
select 
t.store_id,
t.model_id,
sum(t.amount) as v2_value,
count(distinct t.model_id) as v2_ord
from br_PG_MS_PARTNER_PAYMENT_PUBLIC.transactions t
--join paid_lots pl on pl.paid_lot_id=t.paid_lot_id
where
t.transaction_reason_id in (1,20)
and dateadd(hour,-3,t.created_at)::date>= '"""+str(Fecha_Inicio)+"""'
and dateadd(hour,-3,t.created_at)::date<= '"""+str(Fecha_Fin)+"""'
group by 1,2
)
select
coalesce(ot.store_id,v2.store_id) as store_id,
ot.order_id,
s.tienda as store,
grab_value,
v2_value,
v2_value::float/nullif(grab_value::float,0) as perc_value,
grab_ord,
v2_ord,
v2_ord::float/nullif(grab_ord::float,0) as perc_ord,
order_created_at,
state
from orders_total ot
left join ord v2 on v2.store_id = ot.store_id and v2.model_id = ot.order_id
inner join stores s on s.store_id = coalesce(ot.store_id,v2.store_id)
where v2.model_id is null
and grab_value > 0
--and s.store_id in (900155017,900154444,900154850,900154391,900152669,900153934,900156963,900153140,900153513,900155368,900156015,900154033,900154866,900152679,900156170,900152106,900151976,900153094,900152193,900154670,900154425,900154529,900154174,900152672,900153919,900152639,900153137,900152644,900155058,900152359,900154405,900154928,900152620,900118156,900152643,900152489,900154339,900157031,900154809,900153151,900155037,900152678,900152352)
--and frequency_type in (2)
order by 3 desc
"""
    )

cs.execute(Check_2_sql)
Check_2_df = cs.fetch_pandas_all()
Check_2_df=Check_2_df[-(Check_2_df['STATE']=='canceled_partner_after_take')]
Check_2_df.to_csv('BR_Check_2.csv',index=False)
if Check_2_df.empty:
    print("Check2 não foi gerado para Marcello Santos" )
else:
    print("Check2 foi gerado para Marcello Santos" )
"""------------------------------Prime Dominos-----------------------------"""
Prime_Dominos_sql=(
"""

--PRIME DOMINOS
with
pl_restriction as (
select store_id,max(dateadd(hour,-3,created_at)::date) as maxdate
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions
where paid_lot_id is not null
group by 1
)

,prime as (
select distinct model_id,t.store_id,sum(t.amount) as shipping_init
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores s on s.store_id = t.store_id
left join pl_restriction pr on pr.store_id = s.store_id

where
not t._fivetran_deleted
and transaction_reason_id = 24
and lower(s.name) like '%domino%s%'
and dateadd(hour,-3,t.created_at)::date > coalesce(maxdate,'2000-01-01'::date)
and dateadd(hour,-3,t.created_at)::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""'
group by 1,2
)

,theo as (
select oc.order_id,sum(oc.value) as shipping_theo
from prime
join br_core_orders_public.order_charges oc on oc.order_id = prime.model_id
where oc.charge_type = 'shipping' and coalesce(oc._fivetran_deleted,false)=false
group by 1
)

select p.model_id,store_id,case when shipping_theo < 9.34 then shipping_theo else 9.34 end as correct,shipping_init,
case when shipping_theo < 9.34 then shipping_theo else 9.34 end - shipping_init as value_to_add
from prime p
left join theo t on p.model_id = t.order_id
where value_to_add > 0

"""
    )
cs.execute(Prime_Dominos_sql)
Prime_Dominos_df = cs.fetch_pandas_all()
if Prime_Dominos_df.empty:
    print("Sem informações do Prime Dominos" )
else:
    print("Informação carregada: Prime Dominos" )
Dinamic_Prime_Dominos=Prime_Dominos_df.groupby('STORE_ID')['VALUE_TO_ADD'].sum()
Dinamic_Prime_Dominos=pd.DataFrame(Dinamic_Prime_Dominos)
Dinamic_Prime_Dominos=Dinamic_Prime_Dominos.reset_index()
CSV_Headlines=['store_id','description','amount','date','reason']
Prime_Dominos_Adj=pd.DataFrame(columns=CSV_Headlines)
Prime_Dominos_Adj['store_id']=Dinamic_Prime_Dominos['STORE_ID']
Prime_Dominos_Adj['amount']=Dinamic_Prime_Dominos['VALUE_TO_ADD']
Prime_Dominos_Adj['date']=Fecha_Ajuste
Prime_Dominos_Adj['reason']='marketplace_return'
Prime_Dominos_Adj['description']='Ajuste frete prime Dominos'+' del '+str(Fecha_Inicio)+' al '+str(Fecha_Fin)
Prime_Dominos_Adj['type']='Prime Dominos'
"""-------------------------------Prime Madero-----------------------------"""
Prime_Madero_sql=(
    """
    
--PRIME MADERO
with
pl_restriction as (
select store_id,max(dateadd(hour,-3,created_at)::date) as maxdate
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions
where paid_lot_id is not null
group by 1
)

,prime as (
select distinct model_id,t.created_at::date as date_, t.store_id,sum(t.amount) as shipping_init
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores s on s.store_id = t.store_id
left join pl_restriction pr on pr.store_id = s.store_id

where
not t._fivetran_deleted
and transaction_reason_id = 24
and lower(s.name) like '%madero%' or lower(s.name) like '%jeronim%'
and dateadd(hour,-3,t.created_at)::date > coalesce(maxdate,'2000-01-01'::date)
and dateadd(hour,-3,t.created_at)::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""'

group by 1,2,3
)

,theo as (
select oc.order_id,sum(oc.value) as shipping_theo
from prime
join br_core_orders_public.order_charges oc on oc.order_id = prime.model_id
where oc.charge_type = 'shipping' and coalesce(oc._fivetran_deleted,false)=false
group by 1
)

select p.model_id,p.store_id,p.date_, shipping_theo as correct,shipping_init,
 shipping_theo - shipping_init as value_to_add
from prime p
left join theo t on p.model_id = t.order_id
left join br_pglr_ms_partner_payment_public.transactions tt on p.model_id = tt.model_id
where value_to_add > 0
and tt.paid_lot_id is null
and tt.transaction_reason_id = 24
    """   
    )
cs.execute(Prime_Madero_sql)
Prime_Madero_df = cs.fetch_pandas_all()
if Prime_Madero_df.empty:
    print("Sem informações do Prime Madero" )
else:
    print("Informação carregada: Prime Madero" )

Dinamic_Prime_Madero=Prime_Madero_df.groupby('STORE_ID')['VALUE_TO_ADD'].sum()
Dinamic_Prime_Madero=pd.DataFrame(Dinamic_Prime_Madero)
Dinamic_Prime_Madero=Dinamic_Prime_Madero.reset_index()

CSV_Headlines=['store_id','description','amount','date','reason']
Prime_Madero_Adj=pd.DataFrame(columns=CSV_Headlines)
Prime_Madero_Adj['store_id']=Dinamic_Prime_Madero['STORE_ID']
Prime_Madero_Adj['amount']=Dinamic_Prime_Madero['VALUE_TO_ADD']
Prime_Madero_Adj['date']=Fecha_Ajuste
Prime_Madero_Adj['reason']='marketplace_return'
Prime_Madero_Adj['description']='Ajuste frete prime Madero'+' del '+str(Fecha_Inicio)+' al '+str(Fecha_Fin)
Prime_Madero_Adj['type']='Prime Madero'

"""-----------------------------Prime Antiquarius---------------------------"""
Prime_Antiquarius_sql=(
"""

--PRIME ANTIQUARIUS
with
pl_restriction as (
select store_id,max(dateadd(hour,-3,created_at)::date) as maxdate
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions
where paid_lot_id is not null
group by 1
)

,prime as (
select distinct model_id,t.store_id,sum(t.amount) as shipping_init
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores s on s.store_id = t.store_id
left join pl_restriction pr on pr.store_id = s.store_id

where
not t._fivetran_deleted
and transaction_reason_id = 24
and lower(s.name) like '%antiquarius%'
and dateadd(hour,-3,t.created_at)::date > coalesce(maxdate,'2000-01-01'::date)
and dateadd(hour,-3,t.created_at)::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""'

group by 1,2
)

,theo as (
select oc.order_id,sum(oc.value) as shipping_theo
from prime
join br_core_orders_public.order_charges oc on oc.order_id = prime.model_id
where oc.charge_type = 'shipping' and coalesce(oc._fivetran_deleted,false)=false
group by 1
)

select p.model_id,store_id,case when shipping_theo < 11.00 then shipping_theo else 11.00 end as correct,shipping_init,
case when shipping_theo < 11.00 then shipping_theo else 11.00 end - shipping_init as value_to_add
from prime p
left join theo t on p.model_id = t.order_id
where value_to_add > 0

"""
    )
cs.execute(Prime_Antiquarius_sql)
Prime_Antiquarius_df = cs.fetch_pandas_all()
if Prime_Antiquarius_df.empty:
    print("Sem informações do Prime Antiquarius" )
else:
    print("Informação carregada: Prime Antiquarius" )

Dinamic_Prime_Antiquarius=Prime_Antiquarius_df.groupby('STORE_ID')['VALUE_TO_ADD'].sum()
Dinamic_Prime_Antiquarius=pd.DataFrame(Dinamic_Prime_Antiquarius)
Dinamic_Prime_Antiquarius=Dinamic_Prime_Antiquarius.reset_index()

CSV_Headlines=['store_id','description','amount','date','reason']
Prime_Antiquarius_Adj=pd.DataFrame(columns=CSV_Headlines)
Prime_Antiquarius_Adj['store_id']=Dinamic_Prime_Antiquarius['STORE_ID']
Prime_Antiquarius_Adj['amount']=Dinamic_Prime_Antiquarius['VALUE_TO_ADD']
Prime_Antiquarius_Adj['date']=Fecha_Ajuste
Prime_Antiquarius_Adj['reason']='marketplace_return'
Prime_Antiquarius_Adj['description']='Ajuste frete prime Antiquarius'+' del '+str(Fecha_Inicio)+' al '+str(Fecha_Fin)
Prime_Antiquarius_Adj['type']='Prime Antiquarius'

"""-----------------------------Prime Gurume---------------------------"""
Prime_Gurume_sql=(
"""
--PRIME GURUME
with
pl_restriction as (
select store_id,max(dateadd(hour,-3,created_at)::date) as maxdate
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions
where paid_lot_id is not null
group by 1
)

,prime as (
select distinct model_id,t.store_id,sum(t.amount) as shipping_init
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
left join br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores s on s.store_id = t.store_id
left join pl_restriction pr on pr.store_id = s.store_id

where
not t._fivetran_deleted
and transaction_reason_id = 24
and lower(s.name) like '%gurumê%'
and dateadd(hour,-3,t.created_at)::date > coalesce(maxdate,'2000-01-01'::date)
and dateadd(hour,-3,t.created_at)::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""'

group by 1,2
)

,theo as (
select oc.order_id,sum(oc.value) as shipping_theo
from prime
join br_core_orders_public.order_charges oc on oc.order_id = prime.model_id
where oc.charge_type = 'shipping' and coalesce(oc._fivetran_deleted,false)=false
group by 1
)

select p.model_id,store_id,case when shipping_theo < 10.90 then shipping_theo else 10.90 end as correct,shipping_init,
case when shipping_theo < 10.90 then shipping_theo else 10.90 end - shipping_init as value_to_add
from prime p
left join theo t on p.model_id = t.order_id
where value_to_add > 0

"""
)
cs.execute(Prime_Gurume_sql)
Prime_Gurume_df = cs.fetch_pandas_all()
if Prime_Gurume_df.empty:
    print("Sem informações do Prime Gurume" )
else:
    print("Informação carregada: Prime Gurume" )

Dinamic_Prime_Gurume=Prime_Gurume_df.groupby('STORE_ID')['VALUE_TO_ADD'].sum()
Dinamic_Prime_Gurume=pd.DataFrame(Dinamic_Prime_Gurume)
Dinamic_Prime_Gurume=Dinamic_Prime_Gurume.reset_index()

CSV_Headlines=['store_id','description','amount','date','reason']
Prime_Gurume_Adj=pd.DataFrame(columns=CSV_Headlines)
Prime_Gurume_Adj['store_id']=Dinamic_Prime_Gurume['STORE_ID']
Prime_Gurume_Adj['amount']=Dinamic_Prime_Gurume['VALUE_TO_ADD']
Prime_Gurume_Adj['date']=Fecha_Ajuste
Prime_Gurume_Adj['reason']='marketplace_return'
Prime_Gurume_Adj['description']='Ajuste frete prime Gurume'+' del '+str(Fecha_Inicio)+' al '+str(Fecha_Fin)
Prime_Gurume_Adj['type']='Prime Gurume'


"""-----------------------------Voucher Edenred ---------------------------"""
Prime_Voucher_Edenred_sql=(
"""
--EDENRED
with pl_restriction as
(
select t.store_id,max(dateadd(hour,-3,created_at)::date) as maxdate
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
where paid_lot_id is not null
group by 1
)
,o as
(
select model_id as order_id, t.store_id, o2.total_value,o2.tip,sum(case when transaction_reason_id = 45 then (-1)*amount else 0 end) as amount
from br_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
left join pl_restriction pl on pl.store_id = t.store_id
left join br_core_orders_public.orders o2 on o2.id = t.model_id
where dateadd(hour,-3,t.created_at)::date between '"""+str(Fecha_Inicio)+"""' and '"""+str(Fecha_Fin)+"""'
and not t._fivetran_deleted
and dateadd(hour,-3,t.created_at)::date > coalesce(maxdate,'2020-01-01'::date)
and o2.payment_method = 'edenred'
group by 1,2,3,4
)
select order_id,store_id,(amount-total_value-tip) as ajuste_vale
from o
"""
    )
cs.execute(Prime_Voucher_Edenred_sql)
Prime_Voucher_Edenred_df = cs.fetch_pandas_all()
if Prime_Voucher_Edenred_df.empty:
    print("Sem informações do Voucher Edenred" )
else:
    print("Informação carregada: Voucher Edenred" )

Dinamic_Voucher_Edenred=Prime_Voucher_Edenred_df.groupby('STORE_ID')['AJUSTE_VALE'].sum()
Dinamic_Voucher_Edenred=pd.DataFrame(Dinamic_Voucher_Edenred)
Dinamic_Voucher_Edenred=Dinamic_Voucher_Edenred.reset_index()

CSV_Headlines=['store_id','description','amount','date','reason']
Prime_Voucher_Edenred_Adj=pd.DataFrame(columns=CSV_Headlines)
Prime_Voucher_Edenred_Adj['store_id']=Dinamic_Voucher_Edenred['STORE_ID']
Prime_Voucher_Edenred_Adj['amount']=Dinamic_Voucher_Edenred['AJUSTE_VALE']
Prime_Voucher_Edenred_Adj['date']=Fecha_Ajuste
Prime_Voucher_Edenred_Adj['reason']='others'
Prime_Voucher_Edenred_Adj['description']='Ajuste voucher edenred'+' del '+str(Fecha_Inicio)+' al '+str(Fecha_Fin)
Prime_Voucher_Edenred_Adj['type']='Voucher Edenred'

"""-----------------------AJUSTES DE PLANTILLA-----------------------------"""
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow,Flow
from google.auth.transport.requests import Request
import os
import pickle

SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

# here enter the id of your google sheet
SAMPLE_SPREADSHEET_ID_input = '1sHnqx25QXU9m_wWhN4tL-VdinPJwxViv12fyxfGl5eM'
SAMPLE_RANGE_NAME = 'BR!AN1:AR15000'

def main():
    global values_input, service
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES) # here enter the name of your downloaded JSON file
            creds = flow.run_local_server(port=0)
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    service = build('sheets', 'v4', credentials=creds)

    # Call the Sheets API
    sheet = service.spreadsheets()
    result_input = sheet.values().get(spreadsheetId=SAMPLE_SPREADSHEET_ID_input,
                                range=SAMPLE_RANGE_NAME).execute()
    values_input = result_input.get('values', [])

    if not values_input and not values_expansion:
        print('No data found.')
main()
Drive_Plantilla=pd.DataFrame(values_input[1:], columns=values_input[0])
if Drive_Plantilla.empty:
    print("Sem informações do Ajustamentos Plantilla" )
else:
    print("Informação carregada: Ajustamentos Plantilla" )

CSV_Headlines=['store_id','description','amount','date','reason']
Plantilla_Adj=pd.DataFrame(columns=CSV_Headlines)
Plantilla_Adj['store_id']=Drive_Plantilla['store_id'].astype('int')
Plantilla_Adj['amount']=Drive_Plantilla['amount'].str.replace(",",".").astype('float').round(2)
Plantilla_Adj['date']=Fecha_Ajuste.strftime('%d/%m/%Y')
Plantilla_Adj['reason']=Drive_Plantilla['reason']
Plantilla_Adj['description']=Drive_Plantilla['description']
Plantilla_Adj['type']='Plantilla Drive'

Aliados_sql=(
   """ 
select DISTINCT
			      st.store_id,
            st.name,
            spr.PAYMENT_REFERENCE_ID,
            st.IS_MARKETPLACE,
            sc.CONTRACT_ID, 
            con.frequency_type_id as FREQUENCY, 
            con.created_at as creacion_contrato,
            con.START_DATE,
            con.END_DATE,
            iff(COUNT(DISTINCT case when (convert_timezone('UTC','America/Sao_Paulo',current_date::TIMESTAMP_NTZ) between con.START_DATE and con.END_DATE) and (convert_timezone('UTC','America/Sao_Paulo',current_date::TIMESTAMP_NTZ) between sl.START_DATE and sl.END_DATE) AND ob.slot_id is not null THEN CON.ID ELSE NULL END) over (partition by st.store_id)>0 and COUNT(DISTINCT case when ob.slot_id is null THEN sl.ID ELSE NULL END) over (partition by st.store_id)=0,'SI','NO') AS CONTRATO_OK,
            'BR' as pais
                --cc.contract_condition_type_id, cc.value
        from BR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores st
        left join
        (
            select sc.store_id, max(sc.contract_id) as contract_id from
                BR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_contracts sc
          left join BR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts c on sc.contract_id = c.id
                where c.end_date >= current_date()
          group by 1
        ) sc 
        on sc.store_id=st.store_id 
        left join BR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts con on con.id=sc.contract_id and not con._fivetran_deleted
        left join BR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.slots sl on sl.CONTRACT_ID=con.id and not sl._fivetran_deleted
        left join BR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.objectives ob on ob.slot_id=sl.id and not ob._fivetran_deleted
        left join
              (
                SELECT store_id,
                     max(PAYMENT_REFERENCE_ID) as PAYMENT_REFERENCE_ID
                FROM
                (
                select *, row_number () over (partition by store_id order by created_at desc) as unico
                from BR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_payment_references spr
                where not spr._fivetran_deleted and created_at is not null
               )
                where unico=1 group by 1
              )spr on spr.store_id= st.store_id
        where not st._fivetran_deleted
"""
    )
cs.execute(Aliados_sql)
Aliados_df = cs.fetch_pandas_all()
if Aliados_df.empty:
    print("Sem informações do Aliados" )
else:
    print("Informação carregada: Aliados (Freq., Contratos, etc.)" )

"""-------------------CRUCE VS CONTRATACION--------------------------------"""
Adjustments_df=Prime_Dominos_Adj.append([Prime_Madero_Adj,Prime_Antiquarius_Adj,Prime_Gurume_Adj,Plantilla_Adj],ignore_index=True)
Adjustments_df['amount']=round(Adjustments_df['amount'].astype('float'),2)
Columnas_Aliados=list(Aliados_df.columns)
Columnas_Aliados[0]='store_id'
Aliados_df.columns=Columnas_Aliados
Cruce_Aliados_df=pd.merge(Adjustments_df,Aliados_df,on='store_id',how='left')
CPGS_Infiltrados=Cruce_Aliados_df[(Cruce_Aliados_df['FREQUENCY']==7)|(Cruce_Aliados_df['FREQUENCY']==8)|(Cruce_Aliados_df['FREQUENCY']==9)]
print("Foi encontrado",str(len(CPGS_Infiltrados)),"configurações para store_id com uma frequência associada a CPGs" )
Cruce_Aliados_Depurado=Cruce_Aliados_df[-((Cruce_Aliados_df['FREQUENCY']==7)|(Cruce_Aliados_df['FREQUENCY']==8)|(Cruce_Aliados_df['FREQUENCY']==9))]
Cruce_Aliados_Depurado.loc[:]['START_DATE']=pd.to_datetime(Cruce_Aliados_Depurado.loc[:]['START_DATE'])
Cruce_Aliados_Depurado.loc[:]['END_DATE']=pd.to_datetime(Cruce_Aliados_Depurado.loc[:]['END_DATE'])
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[-(Cruce_Aliados_Depurado['store_id'].isnull())]
Problemas_Contrato=Cruce_Aliados_Depurado[-((Cruce_Aliados_Depurado['START_DATE']<=Fecha_Ajuste)&(Cruce_Aliados_Depurado['END_DATE']>=Fecha_Ajuste))]
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[(Cruce_Aliados_Depurado['START_DATE']<=Fecha_Ajuste)&(Cruce_Aliados_Depurado['END_DATE']>=Fecha_Ajuste)]
print("Foi encontrado",str(len(Problemas_Contrato)),"configurações para id de loja com problemas de data de contrato" )
Errores_Frecuencia=Cruce_Aliados_Depurado[-Cruce_Aliados_Depurado['FREQUENCY'].isin(Frecuencia)]
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[Cruce_Aliados_Depurado['FREQUENCY'].isin(Frecuencia)]
print("Foi encontrado",str(len(Errores_Frecuencia)),"configurações para ID de loja com frequências não selecionadas")


Adjustments_Final=pd.DataFrame(columns=CSV_Headlines)
Adjustments_Final['store_id']=Cruce_Aliados_Depurado['store_id'].astype('int')
Adjustments_Final['amount']=Cruce_Aliados_Depurado['amount'].astype('float').round(2)
Adjustments_Final['date']=Cruce_Aliados_Depurado['date']
Adjustments_Final['reason']=Cruce_Aliados_Depurado['reason']
Adjustments_Final['description']=Cruce_Aliados_Depurado['description']
Adjustments_Final['type']=Cruce_Aliados_Depurado['type']
Adjustments_CSV=Adjustments_Final.drop(columns=['type'])
Adjustments_CSV.to_csv('Adjustments_BR_del_'+str(FI)+'_al_'+str(FF)+'.csv',index=False)
CPGS_Infiltrados.to_excel('CPGS_Detectados.xlsx',index=False)
Problemas_Contrato.to_excel('Problemas_contrato_Incidencias.xlsx',index=False)
Errores_Frecuencia.to_excel('Ajustes_fuera_frecuencia.xlsx',index=False)

"""------------------------------PARTICION---------------------------------"""
limite=900
ciclos=math.ceil(len(Adjustments_CSV)/limite)
Nombres=[]
for i in range(0,ciclos):
    Nombres.append('df_'+str(i))
df_dict = dict(('df_' + str(x), pd.DataFrame()) for x in range(0,ciclos))
for i in range(0,ciclos):
    df_dict['df_'+str(i)]=Adjustments_CSV.iloc[(limite*i):(limite*(i+1))]
for i in range(0,ciclos):
    df_dict[Nombres[i]].to_csv('Adjustments_BR_'+'Parte_'+str(i+1)+'_de_'+str(ciclos)+'.csv',index=False)

"""--------------------------------RESUMEN---------------------------------"""
Cantidad=Adjustments_Final.groupby('type')['date'].count()
Valores=Adjustments_Final.groupby('type')['amount'].sum()
Resumen=pd.DataFrame(index=Cantidad.index)
Resumen['Quantidad']=Cantidad
Resumen['Valores']=Valores
Resumen['Valores']=Resumen['Valores'].astype('float')
Resumen.loc['Ajustes Totales']= Resumen.sum()
pd.options.display.float_format = '{:.2f}'.format
print(Resumen)
pd.reset_option('^display.', silent=True)
TiempoFinal=datetime.now() - TiempoInicio
print("O processo foi concluído com sucesso após",str(TiempoFinal))
print("PQRS: david.romero@rappi.com, jennifer.galeano@rappi.com")

