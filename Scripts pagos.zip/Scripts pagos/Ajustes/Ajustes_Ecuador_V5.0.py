# -*- coding: utf-8 -*-
"""
Created on Thu Jan 28 15:24:22 2021
@author: David.Romero
"""

"""Last updated: 22/03/2022   Hamilton.Pacanchique"""

"""--------------------------------PARÁMETROS------------------------------"""

#Parametros de Busqueda
FI="2022-05-30"            #Fecha de Inicio de Búsqueda
FF="2022-06-05"            #Fecha de Fin de Búsqueda
FA="2022-06-05"            #Fecha de Fin de Búsqueda
Frecuencia=(1,5)           #Numero de frecuencia asociada a la búsqueda

"""------------------------------------------------------------------------"""
"""--------------NO MODIFICAR NADA DE AQUÍ EN ADELANTE---------------------"""
#Importación de Librerias
import snowflake.connector as sf
import pandas as pd
import math
from datetime import datetime
TiempoInicio= datetime.now()
#Creación de la conexión con Snowflake
con = sf.connect(
user= 'hamilton.pacanchique@rappi.com',
account= 'hg51401',
warehouse='PAGOS_ANALYSTS',
database='FIVETRAN',
schema='PUBLIC',
authenticator='externalbrowser'
)
#Cursor o consola de Sql en Python
cs=con.cursor()
Fecha_Ajuste=pd.to_datetime(FA).date()
Fecha_Inicio=pd.to_datetime(FI).date()
Fecha_Fin=pd.to_datetime(FF).date()
print("Buen Día, el tiempo promedio de ejecución es de 1 minuto")
print("Los ajustes se crearán para el periodo "+str(Fecha_Inicio)+" al "+str(Fecha_Fin))


"""----------------------------StockOut y TC Query-------------------------"""
SO_sql=(
        """
SELECT 
      t.created_at::DATE,
      T.PAID_LOT_ID,
      t.model_id,
      o.state,
      s.store_id,
      om.support_reason,
      STT.PORCENTAJE_CANCELACION,
      COM.commission_percentage,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 1 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 20 THEN T.AMOUNT ELSE 0 END) AS VENTA,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 10 THEN T.AMOUNT ELSE 0 END)AJ_CANCELLATION_VALUE,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 1 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 20 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 23 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 24 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 18 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 29 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 32 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 10 THEN T.AMOUNT ELSE 0 END) AS      SUB_TOTAL,
       SUM(CASE WHEN T.TRANSACTION_REASON_ID = 2 THEN T.AMOUNT ELSE 0 END) +  SUM(CASE WHEN T.TRANSACTION_REASON_ID = 28 THEN T.AMOUNT ELSE 0 END)
    +  SUM(CASE WHEN T.TRANSACTION_REASON_ID = 27 THEN T.AMOUNT ELSE 0 END) +  SUM(CASE WHEN T.TRANSACTION_REASON_ID = 21 THEN T.AMOUNT ELSE 0 END) AS CM_COMISSION,
    SUM(CASE WHEN T.TRANSACTION_REASON_ID = 3 THEN T.AMOUNT ELSE 0 END) AS IVA,
    SUM(CASE WHEN T.TRANSACTION_REASON_ID = 49 THEN T.AMOUNT ELSE 0 END) AS PERCEPTION,
    SUM(CASE WHEN T.TRANSACTION_REASON_ID = 50 THEN T.AMOUNT ELSE 0 END) AS CBDA,
    SUM(T.AMOUNT) TOTAL_ORDER
FROM EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.TRANSACTIONS T
    JOIN EC_CORE_ORDERS_PUBLIC.ORDERS Ol ON T.model_id = Ol.ID
                                      AND Ol.STATE ILIKE 'CANCEL%'
    JOIN EC_CORE_ORDERS_PUBLIC.ORDERS O ON O.ID = T.model_id
    LEFT JOIN EC_PGLR_MS_STORES_PUBLIC.STORES_vw S ON S.STORE_ID = T.STORE_ID AND S._FIVETRAN_DELETED = FALSE
    LEFT JOIN EC_PGLR_MS_STORES_PUBLIC.STORE_BRANDS_vw SB ON SB.ID = S.STORE_BRAND_ID
    LEFT JOIN ops_global.CANCELLATION_REASONS tas on tas.order_id = t.model_id
    LEFT JOIN ( SELECT  DISTINCT ORDER_ID, 
                   MAX(replace((params:cancelation_reason), '"')  ) as support_reason,
                   max(case when type ilike '%integration%' then created_at end) as integration 
                FROM EC_CORE_ORDERS_PUBLIC.ORDER_MODIFICATIONS
                WHERE _FIVETRAN_DELETED = FALSE 
                GROUP BY 1
                 )OM ON OM.ORDER_ID = T.model_id
    LEFT JOIN (SELECT 
                  ST.STORE_ID, 
                   max(VALUE) AS PORCENTAJE_CANCELACION
               FROM EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_contracts st 
                  LEFT JOIN EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts c on st.contract_id = c.id
                  LEFT JOIN EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contract_conditions cc on cc.contract_id = c.id
                WHERE cc.contract_condition_type_id = 13 group by 1) stt on stt.store_id = t.store_id 
    LEFT JOIN (select * 
                      from (select distinct
                                      order_id,
                                      commission_percentage,
                                      rank() over(partition by order_id order by order_version desc) as rank
                                      from EC_PGLR_MS_PARTNER_PAYMENT_DATA.order_commission where _fivetran_deleted <> TRUE
                                 ) T where rank=1 ) COM ON COM.ORDER_ID = T.MODEL_ID
    INNER JOIN EC_PGLR_MS_PARTNER_PAYMENT_DATA.ORDER_DATA OD ON T.MODEL_ID = OD.ID AND NOT OD._FIVETRAN_DELETED
    INNER JOIN EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.CONTRACTS CON ON CON.ID = OD.CONTRACT_ID AND NOT CON._FIVETRAN_DELETED AND CON.FREQUENCY_TYPE_ID NOT IN (7,8,9)
where  T.CREATED_AT::DATE BETWEEN (dateadd(day,-40,current_date())) AND (current_date())  and support_reason  in ('crsan_closed_store','crsan_product_not_available') AND (LEVEL_3 = 'store_closed' OR LEVEL_3 = 'stockout_no_automation_typification') AND TAS.COUNTRY = 'EC'
group by 1,2,3,4,5,6,7,8
having TOTAL_ORDER > 0
"""
)

cs.execute(SO_sql)
SO_df = cs.fetch_pandas_all()
if SO_df.empty:
    print("Sin información de Riesgos RT" )
else:
    print("Información cargada: Stockout y tienda cerrada" )

#SO_df.groupby('STORE_ID')['TOTAL_ORDER'].sum()
SO_df_Filter=SO_df[(SO_df['T.CREATED_AT::DATE']>=Fecha_Inicio)]
SO_df_Filter=SO_df_Filter[SO_df_Filter['T.CREATED_AT::DATE']<=Fecha_Fin]
Dinamic_SO=SO_df_Filter.groupby('STORE_ID')['TOTAL_ORDER'].sum()
Dinamic_SO=pd.DataFrame(Dinamic_SO)
Dinamic_SO=Dinamic_SO.reset_index()

"""-------------Aliados (Store Id, Contrato, Fechas, Freq) Query-----------"""
Aliados_sql=(
   """ 
  select DISTINCT
			      st.store_id,
            st.name,
            spr.PAYMENT_REFERENCE_ID,
            st.IS_MARKETPLACE,
            sc.CONTRACT_ID, 
            con.frequency_type_id as FREQUENCY, 
            con.created_at as creacion_contrato,
            con.START_DATE,
            con.END_DATE,
            iff(COUNT(DISTINCT case when (convert_timezone('UTC','America/Guayaquil',current_date::TIMESTAMP_NTZ) between con.START_DATE and con.END_DATE) and (convert_timezone('UTC','America/Guayaquil',current_date::TIMESTAMP_NTZ) between sl.START_DATE and sl.END_DATE) AND ob.slot_id is not null THEN CON.ID ELSE NULL END) over (partition by st.store_id)>0 and COUNT(DISTINCT case when ob.slot_id is null THEN sl.ID ELSE NULL END) over (partition by st.store_id)=0,'SI','NO') AS CONTRATO_OK,
            'EC' as pais
                --cc.contract_condition_type_id, cc.value
        from EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores st
        left join
        (
                select sc.store_id, max(sc.contract_id) as contract_id from
                EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_contracts sc
          left join EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts c on sc.contract_id = c.id
                where c.end_date >= current_date()
          group by 1
        ) sc 
        on sc.store_id=st.store_id 
        left join EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts con on con.id=sc.contract_id and not con._fivetran_deleted
        left join EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.slots sl on sl.CONTRACT_ID=con.id and not sl._fivetran_deleted
        left join EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.objectives ob on ob.slot_id=sl.id and not ob._fivetran_deleted
        left join
              (
                SELECT store_id,
                     max(PAYMENT_REFERENCE_ID) as PAYMENT_REFERENCE_ID
                FROM
                (
                select *, row_number () over (partition by store_id order by created_at desc) as unico
                from EC_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_payment_references spr
                where not spr._fivetran_deleted and created_at is not null
               )
                where unico=1 group by 1
              )spr on spr.store_id= st.store_id
        where not st._fivetran_deleted
"""
    )
cs.execute(Aliados_sql)
Aliados_df = cs.fetch_pandas_all()
if Aliados_df.empty:
    print("Sin información de Aliados" )
else:
    print("Información cargada: Aliados (Freq., Contratos, etc.)" )
Cruce_Aliados_SO=pd.merge(Dinamic_SO,Aliados_df,on='STORE_ID',how='left')
Cruce_Aliados_SO=Cruce_Aliados_SO[Cruce_Aliados_SO['FREQUENCY'].isin(Frecuencia)]
Cruce_Aliados_SO['TOTAL_ORDER']=round(Cruce_Aliados_SO['TOTAL_ORDER'].astype('float'),2)
CSV_Headlines=['store_id','description','amount','date','reason']
SO_Adj=pd.DataFrame(columns=CSV_Headlines)
SO_Adj['store_id']=Cruce_Aliados_SO['STORE_ID']
SO_Adj['order_id']=''
SO_Adj['amount']=Cruce_Aliados_SO['TOTAL_ORDER']*-1
SO_Adj['date']=Fecha_Ajuste
SO_Adj['description']='Ordenes Canceladas por Producto Faltante y Tienda Cerrada'+' del '+str(Fecha_Inicio)+' al '+str(Fecha_Fin)
SO_Adj['reason']='others_rest_over_pay'
SO_Adj['type']='Stockout y TC'

"""-----------------------AJUSTES DE PLANTILLA-----------------------------"""
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow,Flow
from google.auth.transport.requests import Request
import os
import pickle

SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

# here enter the id of your google sheet
SAMPLE_SPREADSHEET_ID_input = '1sHnqx25QXU9m_wWhN4tL-VdinPJwxViv12fyxfGl5eM'
SAMPLE_RANGE_NAME = 'EC!AN1:AS5000'

def main():
    global values_input, service
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES) # here enter the name of your downloaded JSON file
            creds = flow.run_local_server(port=0)
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    service = build('sheets', 'v4', credentials=creds)

    # Call the Sheets API
    sheet = service.spreadsheets()
    result_input = sheet.values().get(spreadsheetId=SAMPLE_SPREADSHEET_ID_input,
                                range=SAMPLE_RANGE_NAME).execute()
    values_input = result_input.get('values', [])

    if not values_input and not values_expansion:
        print('No data found.')
main()
Drive_Plantilla=pd.DataFrame(values_input[1:], columns=values_input[0])
if Drive_Plantilla.empty:
    print("Sin información de Ajustes en Plantilla" )
else:
    print("Información cargada: Ajustes Plantilla" )

CSV_Headlines=['store_id','order_id','amount','date','description','reason']
Plantilla_Adj=pd.DataFrame(columns=CSV_Headlines)
Plantilla_Adj['store_id']=Drive_Plantilla['store_id'].astype('int')
Plantilla_Adj['order_id']=Drive_Plantilla['order_id']
Plantilla_Adj['amount']=Drive_Plantilla['amount'].str.replace(",",".").astype('float').round(2)
Plantilla_Adj['date']=Fecha_Ajuste
Plantilla_Adj['description']=Drive_Plantilla['description']
Plantilla_Adj['reason']=Drive_Plantilla['reason']
Plantilla_Adj['type']='Plantilla Drive'

"""-------------------CRUCE VS CONTRATACION--------------------------------"""
Adjustments_df=SO_Adj.append([Plantilla_Adj],ignore_index=True)
Columnas_Aliados=list(Aliados_df.columns)
Columnas_Aliados[0]='store_id'
Aliados_df.columns=Columnas_Aliados
Cruce_Aliados_df=pd.merge(Adjustments_df,Aliados_df,on='store_id',how='left')
CPGS_Infiltrados=Cruce_Aliados_df[(Cruce_Aliados_df['FREQUENCY']==7)|(Cruce_Aliados_df['FREQUENCY']==8)|(Cruce_Aliados_df['FREQUENCY']==9)]
print("Se han encontrado",str(len(CPGS_Infiltrados)),"ajustes para store_id con frecuencia asociada a CPG's" )
Cruce_Aliados_Depurado=Cruce_Aliados_df[-((Cruce_Aliados_df['FREQUENCY']==7)|(Cruce_Aliados_df['FREQUENCY']==8)|(Cruce_Aliados_df['FREQUENCY']==9))]
Cruce_Aliados_Depurado.loc[:]['START_DATE']=pd.to_datetime(Cruce_Aliados_Depurado.loc[:]['START_DATE'])
Cruce_Aliados_Depurado.loc[:]['END_DATE']=pd.to_datetime(Cruce_Aliados_Depurado.loc[:]['END_DATE'])
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[-(Cruce_Aliados_Depurado['store_id'].isnull())]
Problemas_Contrato=Cruce_Aliados_Depurado[-((Cruce_Aliados_Depurado['START_DATE']<=Fecha_Ajuste)&(Cruce_Aliados_Depurado['END_DATE']>=Fecha_Ajuste))]
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[(Cruce_Aliados_Depurado['START_DATE']<=Fecha_Ajuste)&(Cruce_Aliados_Depurado['END_DATE']>=Fecha_Ajuste)]
print("Se han encontrado",str(len(Problemas_Contrato)),"ajustes para store id con problemas de fechas de contrato" )
Errores_Frecuencia=Cruce_Aliados_Depurado[-Cruce_Aliados_Depurado['FREQUENCY'].isin(Frecuencia)]
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[Cruce_Aliados_Depurado['FREQUENCY'].isin(Frecuencia)]
print("Se han encontrado",str(len(Errores_Frecuencia)),"ajustes para store id con frecuencias no seleccionadas")

Adjustments_Final=pd.DataFrame(columns=CSV_Headlines)
Adjustments_Final['store_id']=Cruce_Aliados_Depurado['store_id'].astype('int')
Adjustments_Final['order_id']=Cruce_Aliados_Depurado['order_id']
Adjustments_Final['amount']=Cruce_Aliados_Depurado['amount'].astype('float').round(2)
Adjustments_Final['date']=Cruce_Aliados_Depurado['date']
Adjustments_Final['description']=Cruce_Aliados_Depurado['description']
Adjustments_Final['reason']=Cruce_Aliados_Depurado['reason']
Adjustments_Final['type']=Cruce_Aliados_Depurado['type']
Adjustments_CSV=Adjustments_Final.drop(columns=['type'])
Adjustments_CSV.to_csv('Adjustments_EC_del_'+str(FI)+'_al_'+str(FF)+'.csv',index=False)
CPGS_Infiltrados.to_excel('CPGS_Detectados.xlsx',index=False)
Problemas_Contrato.to_excel('Problemas_contrato_Incidencias.xlsx',index=False)
Errores_Frecuencia.to_excel('Ajustes_fuera_frecuencia.xlsx',index=False)

"""------------------------------PARTICION---------------------------------"""
limite=900
ciclos=math.ceil(len(Adjustments_CSV)/limite)
Nombres=[]
for i in range(0,ciclos):
    Nombres.append('df_'+str(i))
df_dict = dict(('df_' + str(x), pd.DataFrame()) for x in range(0,ciclos))
for i in range(0,ciclos):
    df_dict['df_'+str(i)]=Adjustments_CSV.iloc[(limite*i):(limite*(i+1))]
for i in range(0,ciclos):
    df_dict[Nombres[i]].to_csv('Adjustments_EC_'+'Parte_'+str(i+1)+'_de_'+str(ciclos)+'.csv',index=False)

"""--------------------------------RESUMEN---------------------------------"""
Cantidad=Adjustments_Final.groupby('type')['date'].count()
Valores=Adjustments_Final.groupby('type')['amount'].sum()
Resumen=pd.DataFrame(index=Cantidad.index)
Resumen['Cantidad']=Cantidad
Resumen['Valores']=Valores
Resumen['Valores']=Resumen['Valores'].astype('float')
Resumen.loc['Ajustes Totales']= Resumen.sum()
pd.options.display.float_format = '{:.2f}'.format
print(Resumen)
pd.reset_option('^display.', silent=True)
TiempoFinal=datetime.now() - TiempoInicio
print("El proceso ha finalizado correctamente luego de",str(TiempoFinal))
print("PQRS: david.romero@rappi.com, jennifer.galeano@rappi.com")



