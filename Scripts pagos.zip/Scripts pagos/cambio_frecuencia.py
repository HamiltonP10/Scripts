## Importaci�n de librerias necesarias

import pandas as pd
import time
import json
import requests
import snowflake.connector as sf
import pathlib

##Definición conexión snowflake
con = sf.connect(
user= 'hamilton.pacanchique@rappi.com',
account= 'hg51401',
warehouse='PAGOS_ANALYSTS',
database='FIVETRAN',
schema='PUBLIC',
authenticator='externalbrowser'
)

frequency = input('Ingrese la frecuencia: ')
country = input('Ingrese las iniciales del pa��s: ')
frequency= int(frequency)


## Definición de función Snow extrae y pasa a pandas  
def sf_query (query): 
    PATH = pathlib.Path().parent.resolve()                                                                 ## Trae la información de la libreria donde está el archivo
    cur = con.cursor()
    cur.execute(open(str(PATH.joinpath(query)), "r").read(), _show_progress_bar= True)                     ## Trae el archivo pasandole el nombre y la extensión   
    result = cur.fetchall()
    colnames = [desc[0] for desc in cur.description]
    df = pd.DataFrame(result) 
    df.columns = colnames
    return df


######## Change Environment

environments = {
    
    'MX': 'https://services.mxgrability.rappi.com',
    'PE': 'https://services.rappi.pe',
    'AR': 'https://services.rappi.com.ar',
    'CR': 'https://services.rappi.co.cr',
    'CO': 'https://services.rappi.com',
    'CL': 'https://services.rappi.cl',
    'UY': 'https://services.rappi.com.uy',
    'EC': 'https://services.rappi.com.ec',
    'BR': 'https://services.rappi.com.br',
    'dev': 'http://microservices.dev.rappi.com'
}
    
#########Ejecución del query

print('Downloading Base')
df_base = sf_query('query.sql')                                                                              ##Se ejecuta el método creado anteriormente
contract_id = list(df_base['ID'])                                                                            ## Extracción del contract_id

#####
df = pd.DataFrame()
df['contract_id'] = contract_id
df['freq'] = frequency
lista = df.values.tolist()                                                                                 ## Cambia el formato de los campos a [[campo1,campo2]]
environment = environments[country]                                                                        ## Se elige el environment de acuerdo al pa�s seleccionado


print('Se modificar� contract_id: '+(str(contract_id).replace('[','')).replace(']','') +' del pa��s: '+country+ ' a la frecuencia: '+str(frequency) )  
continuar= input('�Desea continuar?: Y/N ')


#####  INICIO PROCESO DE ACTUALIZACI�N  ######

if continuar in ('Y','y'):
    
        for i in range(0,len(lista)):                                                                                         ##  Se crea ciclo de acuerdo a la cantidad de registros a actualizar
            
            contract_id = lista[i][0]                                                                                        ##  Selecciona contract id de acuerdo a la posici�n 
            freq =  lista[i][1]
            print(contract_id)
            
            business_structure= {                                                                                           ## Se crea la estructura de acuerdo a los nombres de campo
                  "frequency_type_id": freq,         
                  "email": "hamilton.pacanchique@rappi.com"
                }
            
            headers = {
                'Content-Type': 'application/json'
            }
            
            body_data = json.dumps(business_structure)                                                                                        ## Se crea la estructura en formato json                                                
            response = requests.put(f'{environment}/api/partner-payment/contract/update/{contract_id}',data=body_data, headers=headers)       ## Se ejecuta la solicitud al ms
            
            
            print(body_data)
            print('##############frequency##############')
            print('adjustment: '+ str(response.status_code))
            print(response.json())
else:
    print('Se cancel� la solicitud' )  
           
    
time.sleep(1)


