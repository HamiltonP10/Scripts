# -*- coding: utf-8 -*-
"""
Created on Wed Feb  3 14:48:33 2021

@author: David.Romero
"""

"""--------------------------------PARÁMETROS------------------------------"""

#Parametros de Busqueda
FI="2022-07-11"            #Fecha de Inicio de Búsqueda
FF="2022-07-17"            #Fecha de Fin de Búsqueda
FA="2022-07-17"            #Fecha de Fin de Búsqueda
Frecuencia=(1,5)           #Numero de frecuencia asociada a la búsqueda



"""------------------------------------------------------------------------"""
"""--------------NO MODIFICAR NADA DE AQUÍ EN ADELANTE---------------------"""
#Importación de Librerias
import snowflake.connector as sf
import math
import warnings
import pandas as pd
from datetime import datetime
warnings.simplefilter(action='ignore')
TiempoInicio= datetime.now()
#Creación de la conexión con Snowflake
con = sf.connect(
user= 'hamilton.pacanchique@rappi.com',
account= 'hg51401',
warehouse='PAGOS_ANALYSTS',
database='FIVETRAN',
schema='PUBLIC',
authenticator='externalbrowser'
)
#Cursor o consola de Sql en Python
cs=con.cursor()
Fecha_Ajuste=pd.to_datetime(FA).date()
Fecha_Ajuste=pd.to_datetime(FA).date()
Fecha_Inicio=pd.to_datetime(FI).date()
Fecha_Fin=pd.to_datetime(FF).date()
print("Buen Día, el tiempo promedio de ejecución es de 2 minutos")
print("Los ajustes se crearán para el periodo "+str(Fecha_Inicio)+" al "+str(Fecha_Fin),"Freq. =",Frecuencia)

"""----------------------------StockOut y TC Query-------------------------"""
SO_sql=("""SELECT 
      t.created_at::DATE,
      T.PAID_LOT_ID,
      t.model_id,
      o.state,
      s.store_id,
      om.support_reason,
      STT.PORCENTAJE_CANCELACION,
      COM.commission_percentage,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 1 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 20 THEN T.AMOUNT ELSE 0 END) AS VENTA,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 10 THEN T.AMOUNT ELSE 0 END)AJ_CANCELLATION_VALUE,
      SUM(CASE WHEN T.TRANSACTION_REASON_ID = 1 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 20 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 23 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 24 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 18 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 29 THEN T.AMOUNT ELSE 0 END)
      + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 32 THEN T.AMOUNT ELSE 0 END) + SUM(CASE WHEN T.TRANSACTION_REASON_ID = 10 THEN T.AMOUNT ELSE 0 END) AS      SUB_TOTAL,
       SUM(CASE WHEN T.TRANSACTION_REASON_ID = 2 THEN T.AMOUNT ELSE 0 END) +  SUM(CASE WHEN T.TRANSACTION_REASON_ID = 28 THEN T.AMOUNT ELSE 0 END)
    +  SUM(CASE WHEN T.TRANSACTION_REASON_ID = 27 THEN T.AMOUNT ELSE 0 END) +  SUM(CASE WHEN T.TRANSACTION_REASON_ID = 21 THEN T.AMOUNT ELSE 0 END) AS CM_COMISSION,
    SUM(CASE WHEN T.TRANSACTION_REASON_ID = 3 THEN T.AMOUNT ELSE 0 END) AS IVA,
    SUM(CASE WHEN T.TRANSACTION_REASON_ID = 49 THEN T.AMOUNT ELSE 0 END) AS PERCEPTION,
    SUM(CASE WHEN T.TRANSACTION_REASON_ID = 50 THEN T.AMOUNT ELSE 0 END) AS CBDA,
    SUM(T.AMOUNT) TOTAL_ORDER
FROM AR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.TRANSACTIONS T
    JOIN AR_CORE_ORDERS_PUBLIC.ORDERS Ol ON T.model_id = Ol.ID
                                      AND Ol.STATE ILIKE 'CANCEL%'
    JOIN AR_CORE_ORDERS_PUBLIC.ORDERS O ON O.ID = T.model_id
    LEFT JOIN AR_PGLR_MS_STORES_PUBLIC.STORES_vw S ON S.STORE_ID = T.STORE_ID AND S._FIVETRAN_DELETED = FALSE
    LEFT JOIN AR_PGLR_MS_STORES_PUBLIC.STORE_BRANDS_vw SB ON SB.ID = S.STORE_BRAND_ID
    LEFT JOIN OPS_GLOBAL.CANCELLATION_REASONS tas on tas.order_id = t.model_id
    LEFT JOIN ( SELECT  DISTINCT ORDER_ID, 
                   MAX(replace((params:cancelation_reason), '"')  ) as support_reason,
                   max(case when type ilike '%integration%' then created_at end) as integration 
                FROM AR_CORE_ORDERS_PUBLIC.ORDER_MODIFICATIONS
                WHERE _FIVETRAN_DELETED = FALSE 
                GROUP BY 1
                 )OM ON OM.ORDER_ID = T.model_id
    LEFT JOIN (SELECT 
                  ST.STORE_ID, 
                   max(VALUE) AS PORCENTAJE_CANCELACION
               FROM AR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_contracts st 
                  LEFT JOIN AR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts c on st.contract_id = c.id
                  LEFT JOIN AR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contract_conditions cc on cc.contract_id = c.id
                WHERE  cc.contract_condition_type_id = 13 group by 1) stt on stt.store_id = t.store_id 
    LEFT JOIN (select * 
                      from (select distinct
                                      order_id,
                                      commission_percentage,
                                      rank() over(partition by order_id order by order_version desc) as rank
                                      from AR_PGLR_MS_PARTNER_PAYMENT_DATA.order_commission where _fivetran_deleted <> TRUE
                                 ) T where rank=1 ) COM ON COM.ORDER_ID = T.MODEL_ID
    INNER JOIN AR_PGLR_MS_PARTNER_PAYMENT_DATA.ORDER_DATA OD ON T.MODEL_ID = OD.ID AND NOT OD._FIVETRAN_DELETED
    INNER JOIN AR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.CONTRACTS CON ON CON.ID = OD.CONTRACT_ID AND NOT CON._FIVETRAN_DELETED AND CON.FREQUENCY_TYPE_ID NOT IN (7,8,9)
where  T.CREATED_AT::DATE BETWEEN (dateadd(day,-40,current_date())) AND (current_date())  and support_reason  in ('crsan_closed_store','crsan_product_not_available') AND TAS.COUNTRY = 'AR' ---- AND (LEVEL_3 = 'store_closed' OR LEVEL_3 = 'stockout_no_automation_typification')
group by 1,2,3,4,5,6,7,8
having TOTAL_ORDER > 0
"""
)
cs.execute(SO_sql)
SO_df = cs.fetch_pandas_all()
if SO_df.empty:
    print("Sin información de Riesgos RT" )
else:
    print("Información cargada: Stockout y tienda cerrada" )
SO_df_Filter=SO_df[(SO_df['T.CREATED_AT::DATE']>=Fecha_Inicio)]
SO_df_Filter=SO_df_Filter[SO_df_Filter['T.CREATED_AT::DATE']<=Fecha_Fin]



"""-------------------------Ally Another Reason Query----------------------"""


Ally_another_sql=(
    """with modifications as (
 select 
   order_id,
   max(case when type ilike '%cancel%' then created_at::date end) as cancelation_time,
   max(case when type = 'taken_visible_order' and params:partner_id is not null then created_at::timestamp_ntz end ) as taken_partner,
   max(case when type = 'assign_to_partner_integration_v2' and params:partner_id is not null then created_at::timestamp_ntz end ) as taken_partner_integrado,
   max(case when type = 'taken_visible_order' and params:storekeeper_id is not null then created_at::timestamp_ntz end) as taken_rt,
   max(case when type = 'release_order_request' then created_at::timestamp_ntz end) as request_liberacion,
   max(case when type = 'replace_storekeeper' then created_at::timestamp_ntz end) as reemplazo_manual,
  max(case when type = 'release_order_by_cms_request' then created_at::timestamp_ntz end) as libero
 from ar_core_orders_public.order_modifications
 where not _fivetran_deleted 
 group by 1
),
reasons as (
 select *
 from (select order_id,
           row_number() over (partition by order_id order by created_at desc, id desc) as rank,
           created_at::timestamp_ntz as cancelation_time,
           type as cancelation_state,
           replace(PARSE_JSON(params:cancellation_info):reason:reason_id, '"') as cancelation_reason
        from ar_core_orders_public.order_modifications 
        where not _fivetran_deleted 
        and type ilike '%cancel%'
      )
 where rank = 1 
)
SELECT distinct 
      t.created_at::DATE,
      T.PAID_LOT_ID,
      t.model_id,
      o.state,
      s.store_id,
      r.cancelation_reason as support_reason,
      STT.PORCENTAJE_CANCELACION,
      COM.commission_percentage,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 1 THEN T.AMOUNT ELSE 0 END) + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 20 THEN T.AMOUNT ELSE 0 END) AS VENTA,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 10 THEN T.AMOUNT ELSE 0 END)AJ_CANCELLATION_VALUE,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 1 THEN T.AMOUNT ELSE 0 END) + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 20 THEN T.AMOUNT ELSE 0 END)
      + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 23 THEN T.AMOUNT ELSE 0 END) + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 24 THEN T.AMOUNT ELSE 0 END)
      + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 18 THEN T.AMOUNT ELSE 0 END) + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 29 THEN T.AMOUNT ELSE 0 END)
      + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 32 THEN T.AMOUNT ELSE 0 END) + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 10 THEN T.AMOUNT ELSE 0 END) AS      SUB_TOTAL,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 6 THEN T.AMOUNT ELSE 0 END)RT_RETEFUENTE_CC_DC,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 9 THEN T.AMOUNT ELSE 0 END)RT_ICA_CC_DC,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 2 THEN T.AMOUNT ELSE 0 END) +  SUM(DISTINCT CASE WHEN T.TRANSACTION_REASON_ID = 28 THEN T.AMOUNT ELSE 0 END)
      + SUM( CASE WHEN T.TRANSACTION_REASON_ID = 27 THEN T.AMOUNT ELSE 0 END) +  SUM( CASE WHEN T.TRANSACTION_REASON_ID = 21 THEN T.AMOUNT ELSE 0 END) AS CM_COMISSION,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 11 THEN T.AMOUNT ELSE 0 END) AS BANK_SPENDINGS,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 3 THEN T.AMOUNT ELSE 0 END) AS IVA,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 4 THEN T.AMOUNT ELSE 0 END) AS RETEFUNETE,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 5 THEN T.AMOUNT ELSE 0 END) AS RETEICA,
      SUM( CASE WHEN T.TRANSACTION_REASON_ID = 25 THEN T.AMOUNT ELSE 0 END) AS RETEIVA,
      SUM( T.AMOUNT) TOTAL_ORDER
    FROM ar_PGLR_MS_PARTNER_PAYMENT_PUBLIC.TRANSACTIONS T
    JOIN ar_CORE_ORDERS_PUBLIC.ORDERS Ol ON T.model_id = Ol.ID AND Ol.STATE ILIKE 'CANCEL%'
    JOIN ar_CORE_ORDERS_PUBLIC.ORDERS O ON O.ID = T.model_id
    LEFT JOIN AR_PGLR_MS_STORES_PUBLIC.STORES_vw S ON S.STORE_ID = T.STORE_ID AND S._FIVETRAN_DELETED = FALSE
    LEFT JOIN AR_PGLR_MS_STORES_PUBLIC.STORE_BRANDS_vw SB ON SB.ID = S.STORE_BRAND_ID
    left join modifications m on m.order_id = t.model_id
    left join reasons r on r.order_id = t.model_id
    join (select distinct order_id
               from ar_pg_ms_realtime_interface_public.notifications
               where (sender_type ilike '%rappite%' or sender_type ilike '%personals%')
          and notification_type in (
  'RT_PROBLEMS_WITH_RESTAURANT_NOT_RELEASED_ORDER', 
  'RT_OTHER_RT_PICKED_UP_MY_ORDER_V3',
  'RT_OTHER_RT_PICKED_UP_MY_ORDER', 
  'RT_PROBLEMS_WITH_RESTAURANT_ORDER_DOES_NOT_APPEAR', 
  'RT_PROBLEMS_WITH_RESTAURANT_LATE')
               ) riesgo on riesgo.order_id = t.model_id
    left join (select distinct store_type, 
                 first_value(sub_group) over(partition by store_type order by _fivetran_synced desc) as subvertical, 
                 first_value("GROUP") over(partition by store_type order by _fivetran_synced desc) as vertical 
               from ar_grability_public.verticals 
               where not _fivetran_deleted
               ) v on s.type = v.store_type 
    LEFT JOIN (SELECT 
                ST.STORE_ID, 
                max(VALUE) AS PORCENTAJE_CANCELACION
               FROM ar_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_contracts st 
               LEFT JOIN ar_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts c on st.contract_id = c.id
               LEFT JOIN ar_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contract_conditions cc on cc.contract_id = c.id
               WHERE c.IS_ACTIVE = TRUE AND cc.contract_condition_type_id = 13
              group by 1) stt on stt.store_id = t.store_id 
   LEFT JOIN (select * 
              from (select distinct
                      order_id,
                      commission_percentage,
                      rank() over(partition by order_id order by order_version, created_at desc) as rank
                      from ar_PGLR_MS_PARTNER_PAYMENT_DATA.order_commission where _fivetran_deleted <> TRUE
                    ) T where rank=1 ) COM ON COM.ORDER_ID = T.MODEL_ID
    INNER JOIN AR_PGLR_MS_PARTNER_PAYMENT_DATA.ORDER_DATA OD ON T.MODEL_ID = OD.ID AND NOT OD._FIVETRAN_DELETED
    INNER JOIN AR_PGLR_MS_PARTNER_PAYMENT_PUBLIC.CONTRACTS CON ON CON.ID = OD.CONTRACT_ID AND NOT CON._FIVETRAN_DELETED AND CON.FREQUENCY_TYPE_ID NOT IN (7,8,9)
where 
T.CREATED_AT::DATE BETWEEN (dateadd(day,-40,current_date())) AND (dateadd(day,-1,current_date())) 
and subvertical in ('Restaurantes')
and (taken_partner is not null or taken_partner_integrado is not null) 
and o.state ilike '%cancel%'
and cancelation_reason = 'crsan_ally_another_reason'
and request_liberacion is null and reemplazo_manual is null and libero is null
group by 1,2,3,4,5,6,7,8
having TOTAL_ORDER > 0
""")
cs.execute(Ally_another_sql)
All_Another_df = cs.fetch_pandas_all()
if All_Another_df.empty:
    print("Sin información de Riesgos RT" )
else:
    print("Información cargada: Riesgos RT" )
    
"""-------------Aliados (Store Id, Contrato, Fechas, Freq) Query-----------"""
Aliados_sql=(
   """ 
  select DISTINCT
			      st.store_id as STORE_ID,
            st.name,
            spr.PAYMENT_REFERENCE_ID,
            st.IS_MARKETPLACE,
            sc.CONTRACT_ID, 
            con.frequency_type_id as FREQUENCY, 
            con.created_at::DATE as creacion_contrato,
            con.START_DATE::DATE AS START_DATE,
            con.END_DATE::DATE AS END_DATE,
            iff(COUNT(DISTINCT case when (convert_timezone('UTC','America/Buenos_Aires',current_date::TIMESTAMP_NTZ) between con.START_DATE and con.END_DATE) and (convert_timezone('UTC','America/Buenos_Aires',current_date::TIMESTAMP_NTZ) between sl.START_DATE and sl.END_DATE) AND ob.slot_id is not null THEN CON.ID ELSE NULL END) over (partition by st.store_id)>0 and COUNT(DISTINCT case when ob.slot_id is null THEN sl.ID ELSE NULL END) over (partition by st.store_id)=0,'SI','NO') AS CONTRATO_OK,
            'ar' as pais
                --cc.contract_condition_type_id, cc.value
        from ar_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores st
        left join
        (
             select sc.store_id, max(sc.contract_id) as contract_id from
                ar_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_contracts sc
          left join ar_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts c on sc.contract_id = c.id
                where c.end_date >= current_date()
          group by 1
        ) sc 
        on sc.store_id=st.store_id 
        left join ar_PGLR_MS_PARTNER_PAYMENT_PUBLIC.contracts con on con.id=sc.contract_id and not con._fivetran_deleted
        left join ar_PGLR_MS_PARTNER_PAYMENT_PUBLIC.slots sl on sl.CONTRACT_ID=con.id and not sl._fivetran_deleted
        left join ar_PGLR_MS_PARTNER_PAYMENT_PUBLIC.objectives ob on ob.slot_id=sl.id and not ob._fivetran_deleted
        left join
              (
                SELECT store_id,
                     max(PAYMENT_REFERENCE_ID) as PAYMENT_REFERENCE_ID
                FROM
                (
                select *, row_number () over (partition by store_id order by created_at desc) as unico
                from ar_PGLR_MS_PARTNER_PAYMENT_PUBLIC.store_payment_references spr
                where not spr._fivetran_deleted and created_at is not null
               )
                where unico=1 group by 1
              )spr on spr.store_id= st.store_id
        where not st._fivetran_deleted
"""
    )
cs.execute(Aliados_sql)
Aliados_df = cs.fetch_pandas_all()
if Aliados_df.empty:
    print("Sin información de Aliados" )
else:
    print("Información cargada: Aliados (Freq., Contratos, etc.)" )
"""-----------------------------CRUCES ALIADOS-----------------------------"""
Cruce_Aliados_SO=pd.merge(SO_df_Filter,Aliados_df,on='STORE_ID',how='left')
Cruce_Aliados_SO=Cruce_Aliados_SO[Cruce_Aliados_SO['FREQUENCY'].isin(Frecuencia)]
Cruce_Aliados_SO['TOTAL_ORDER']=round(Cruce_Aliados_SO['TOTAL_ORDER'].astype('float'),2)
All_Another_df_Filter=All_Another_df[(All_Another_df['T.CREATED_AT::DATE']>=Fecha_Inicio)]
All_Another_df_Filter=All_Another_df_Filter[All_Another_df_Filter['T.CREATED_AT::DATE']<=Fecha_Fin]
Cruce_Aliados_Ally_OR=pd.merge(All_Another_df_Filter,Aliados_df,on='STORE_ID',how='left')
Cruce_Aliados_Ally_OR=Cruce_Aliados_Ally_OR[Cruce_Aliados_Ally_OR['FREQUENCY'].isin(Frecuencia)]
Cruce_Aliados_Ally_OR['TOTAL_ORDER']=round(Cruce_Aliados_Ally_OR['TOTAL_ORDER'].astype('float'),2)


CSV_Headlines=['store_id','order_id','amount','date','description','reason']
SO_Adj=pd.DataFrame(columns=CSV_Headlines)
SO_Adj['store_id']=Cruce_Aliados_SO['STORE_ID']
SO_Adj['order_id']=''
SO_Adj['amount']=Cruce_Aliados_SO['TOTAL_ORDER']*-1
SO_Adj['date']=Fecha_Ajuste
SO_Adj['description']='Ordenes Canceladas por Producto Faltante y Tienda Cerrada'+' del '+str(Fecha_Inicio)+' al '+str(Fecha_Fin)
SO_Adj['reason']='others_rest_over_pay'
SO_Adj['type']='Stockout y TC'

Ally_Other_Adj=pd.DataFrame(columns=CSV_Headlines)
Ally_Other_Adj['store_id']=Cruce_Aliados_Ally_OR['STORE_ID']
Ally_Other_Adj['order_id']=''
Ally_Other_Adj['amount']=Cruce_Aliados_Ally_OR['TOTAL_ORDER']*-1
Ally_Other_Adj['date']=Fecha_Ajuste
Ally_Other_Adj['description']='Ordenes canceladas por demora de entrega a RT'+' del '+str(Fecha_Inicio)+' al '+str(Fecha_Fin)
Ally_Other_Adj['reason']='others_rest_over_pay'
Ally_Other_Adj['type']='Riesgos RT'



"""-----------------------AJUSTES DE PLANTILLA-----------------------------"""
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow,Flow
from google.auth.transport.requests import Request
import os
import pickle
# here enter the id of your google sheet
SAMPLE_SPREADSHEET_ID_input = '1sHnqx25QXU9m_wWhN4tL-VdinPJwxViv12fyxfGl5eM'
SAMPLE_RANGE_NAME = 'AR!AN1:AS5000'

def main():
    global values_input, service
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES) # here enter the name of your downloaded JSON file
            creds = flow.run_local_server(port=0)
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    service = build('sheets', 'v4', credentials=creds)

    # Call the Sheets API
    sheet = service.spreadsheets()
    result_input = sheet.values().get(spreadsheetId=SAMPLE_SPREADSHEET_ID_input,
                                range=SAMPLE_RANGE_NAME).execute()
    values_input = result_input.get('values', [])

    if not values_input and not values_expansion:
        print('No data found.')
main()
Drive_Plantilla=pd.DataFrame(values_input[1:], columns=values_input[0])
if Drive_Plantilla.empty:
    print("Sin información de Ajustes en Plantilla" )
else:
    print("Información cargada: Ajustes Plantilla" )


Plantilla_Adj=pd.DataFrame(columns=CSV_Headlines)
Plantilla_Adj['store_id']=Drive_Plantilla['store_id'].astype('int')
Plantilla_Adj['order_id']=Drive_Plantilla['order_id']
Plantilla_Adj['amount']=Drive_Plantilla['amount'].str.replace(",",".").astype('float').round(2)
Plantilla_Adj['date']=Fecha_Ajuste
Plantilla_Adj['description']=Drive_Plantilla['description']
Plantilla_Adj['reason']=Drive_Plantilla['reason']
Plantilla_Adj['type']='Plantilla Drive'

"""-------------------CRUCE VS CONTRATACION--------------------------------"""
Adjustments_df=SO_Adj.append([Ally_Other_Adj,Plantilla_Adj],ignore_index=True)
Columnas_Aliados=list(Aliados_df.columns)
Columnas_Aliados[0]='store_id'
Aliados_df.columns=Columnas_Aliados
Cruce_Aliados_df=pd.merge(Adjustments_df,Aliados_df,on='store_id',how='left')
CPGS_Infiltrados=Cruce_Aliados_df[(Cruce_Aliados_df['FREQUENCY']==7)|(Cruce_Aliados_df['FREQUENCY']==8)|(Cruce_Aliados_df['FREQUENCY']==9)]
print("Se han encontrado",str(len(CPGS_Infiltrados)),"ajustes para store_id con frecuencia asociada a CPG's" )
Cruce_Aliados_Depurado=Cruce_Aliados_df[-((Cruce_Aliados_df['FREQUENCY']==7)|(Cruce_Aliados_df['FREQUENCY']==8)|(Cruce_Aliados_df['FREQUENCY']==9))]
Cruce_Aliados_Depurado.loc[:]['START_DATE']=pd.to_datetime(Cruce_Aliados_Depurado.loc[:]['START_DATE'])
Cruce_Aliados_Depurado.loc[:]['END_DATE']=pd.to_datetime(Cruce_Aliados_Depurado.loc[:]['END_DATE'])
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[-(Cruce_Aliados_Depurado['store_id'].isnull())]
Problemas_Contrato=Cruce_Aliados_Depurado[-((Cruce_Aliados_Depurado['START_DATE']<=Fecha_Ajuste)&(Cruce_Aliados_Depurado['END_DATE']>=Fecha_Ajuste))]
print("Se han encontrado",str(len(Problemas_Contrato)),"ajustes para store id con problemas de fechas de contrato" )
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[(Cruce_Aliados_Depurado['START_DATE']<=Fecha_Ajuste)&(Cruce_Aliados_Depurado['END_DATE']>=Fecha_Ajuste)]
Errores_Frecuencia=Cruce_Aliados_Depurado[-Cruce_Aliados_Depurado['FREQUENCY'].isin(Frecuencia)]
Cruce_Aliados_Depurado=Cruce_Aliados_Depurado[Cruce_Aliados_Depurado['FREQUENCY'].isin(Frecuencia)]
print("Se han encontrado",str(len(Errores_Frecuencia)),"ajustes para store id con frecuencias no seleccionadas" )

Adjustments_Final=pd.DataFrame(columns=CSV_Headlines)
Adjustments_Final['store_id']=Cruce_Aliados_Depurado['store_id'].astype('int')
Adjustments_Final['order_id']=Cruce_Aliados_Depurado['order_id']
Adjustments_Final['amount']=Cruce_Aliados_Depurado['amount'].astype('float').round(2)
Adjustments_Final['date']=Cruce_Aliados_Depurado['date']
Adjustments_Final['description']=Cruce_Aliados_Depurado['description']
Adjustments_Final['reason']=Cruce_Aliados_Depurado['reason']
Adjustments_Final['type']=Cruce_Aliados_Depurado['type']
Adjustments_CSV=Adjustments_Final.drop(columns=['type'])
Adjustments_CSV.to_csv('Adjustments_AR_del_'+str(FI)+'_al_'+str(FF)+'.csv',index=False)
CPGS_Infiltrados.to_excel('CPGS_Detectados.xlsx',index=False)
Problemas_Contrato.to_excel('Problemas_contrato_Incidencias.xlsx',index=False)
Errores_Frecuencia.to_excel('Ajustes_fuera_frecuencia.xlsx',index=False)

"""------------------------------PARTICION---------------------------------"""
limite=900
ciclos=math.ceil(len(Adjustments_CSV)/limite)
Nombres=[]
for i in range(0,ciclos):
    Nombres.append('df_'+str(i))
df_dict = dict(('df_' + str(x), pd.DataFrame()) for x in range(0,ciclos))
for i in range(0,ciclos):
    df_dict['df_'+str(i)]=Adjustments_CSV.iloc[(limite*i):(limite*(i+1))]
for i in range(0,ciclos):
    df_dict[Nombres[i]].to_csv('Adjustments_AR_'+'Parte_'+str(i+1)+'_de_'+str(ciclos)+'.csv',index=False)
"""--------------------------------RESUMEN---------------------------------"""
Cantidad=Adjustments_Final.groupby('type')['date'].count()
Valores=Adjustments_Final.groupby('type')['amount'].sum()
Resumen=pd.DataFrame(index=Cantidad.index)
Resumen['Cantidad']=Cantidad
Resumen['Valores']=Valores
Resumen['Valores']=Resumen['Valores'].astype('float')
Resumen.loc['Ajustes Totales']= Resumen.sum()
pd.options.display.float_format = '{:.2f}'.format
print(Resumen)
pd.reset_option('^display.', silent=True)
TiempoFinal=datetime.now() - TiempoInicio
print("El proceso ha finalizado correctamente luego de",str(TiempoFinal))
print("PQRS: david.romero@rappi.com, jennifer.galeano@rappi.com")




