select * from br_pglr_ms_partner_payment_public.contracts
where id IN (select distinct contract_id 
             from br_pglr_ms_partner_payment_public.store_contracts 
             where store_id in (900628247))
             