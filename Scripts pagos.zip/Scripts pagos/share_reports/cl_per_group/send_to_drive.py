from __future__ import print_function
import pickle
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from oauth2client.service_account import ServiceAccountCredentials
from apiclient.discovery import build
from apiclient.http import MediaFileUpload
from apiclient import errors
from pathlib import Path
import multiprocessing
from multiprocessing import Queue
from multiprocessing import Pool
import datetime
import csv

q = Queue()
# If modifying these scopes, delete the file token.pickle.
SCOPES = ['https://www.googleapis.com/auth/drive']

google_drive_folder = '1_YHUpp2n-2Rgdq7O9bOi1yFVP0B-M_sa'


creds = None
# The file token.pickle stores the user's access and refresh tokens, and is
# created automatically when the authorization flow completes for the first
# time.
if os.path.exists('token.pickle'):
    with open('token.pickle', 'rb') as token:
        creds = pickle.load(token)
# If there are no (valid) credentials available, let the user log in.
if not creds or not creds.valid:
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    else:
        flow = InstalledAppFlow.from_client_secrets_file(
            'credentials.json', SCOPES)
        creds = flow.run_local_server(port=0)
    # Save the credentials for the next run
    with open('token.pickle', 'wb') as token:
        pickle.dump(creds, token)

service = build('drive', 'v3', credentials=creds)



def uploadFile(file):
    file_name = file.name
    file_path = file.absolute()
    parent_id = google_drive_folder
    file_metadata = {
    'name': file_name,
    'description': 'xxxxx',
    'mimeType': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'parents': [parent_id]
    }
    media = MediaFileUpload(file_path,
                            mimetype='*/*',
                            resumable=True)
    file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()
    print ('File ID: ' + file.get('id'))
    f = open('created.csv','a')
    f.write(file.get('id') +';' + file_name.replace('.xlsx','') + ';'+str(datetime.datetime.utcnow()) +'\n')

def searching_all_files(directory):
    dirpath = Path(directory)
    assert(dirpath.is_dir())
    file_list = []
    for x in dirpath.iterdir():
        if x.is_file():
            file_list.append(x)
        elif x.is_dir():
            file_list.extend(searching_all_files(x))
    return file_list



def run():

    f = open('created.csv','a')
    f.close()
    lista = []
    with open('created.csv','r') as f:
        reader = csv.reader(f, delimiter=';')
        for i, line in enumerate(reader):
            lista.append(line[1] + '.xlsx')
    files = searching_all_files('generated_excel')

    real_files = []
    for file in files:
        # print(file.name)
        contained = False
        for i in lista:
            if (file.name == i):
                # print(file.name)
                contained = True
        if not contained and 'xlsx' in file.name:
            real_files.append(file)
    print(real_files)

    try:
        with Pool(5) as p:
            data = p.map(uploadFile, real_files)
    except Exception as e:
        print(str(e))
run() 


