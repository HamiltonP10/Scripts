---query2New
--no_cache
with paid_lots_ini as (
select distinct pl.id as paid_lot_id,pay_start_date,pay_end_date
from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores st on st.payment_reference_id = pl.payment_reference_id and not st._fivetran_deleted
where not PL._FIVETRAN_DELETED 
-- and PAY_START_DATE>='2020-03-01' 
and pl.status<>'CANCELED' and st.is_marketplace = false
)

,orders as
(
    with paid_lots as (
      select
        t.paid_lot_id,
        model_id as order_id,
        t.store_id,
        sum(amount) as compensations,
        min(dateadd(hour,-6,t.created_at)::timestamp_ntz) as created_at
      from
        mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.transactions t
      join
        paid_lots_ini pl on pl.paid_lot_id=t.paid_lot_id
      left join
        mx_core_orders_public.orders o on o.id = t.model_id and coalesce(o._fivetran_deleted,false)=false
      left join
        mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.stores s on s.store_id = t.store_id and coalesce(s._fivetran_deleted,false)=false
      where not t._fivetran_deleted --and
        --o.created_at::date between '2019-11-01' and '2019-11-15'
        and transaction_reason_id = 18
        and coalesce(t._fivetran_deleted,false)=false
        and s.is_marketplace = false
      group by
        1,2,3
      having
        abs(sum(amount)) > 0
      )

      select
      os.*, pl.store_id,pl.paid_lot_id,pl.compensations as rappicreditos_real
      from mx_core_orders_public.orders os
      inner join paid_lots pl on os.id = pl.order_id
      where not os._fivetran_deleted
  )

,details as
(
select
paid_lot_id,
store_id,
order_id,
reason,
case when reason = 'product_missing' then 1
when reason = 'product_difference' then 2
when reason = 'product_poor' then 3
else 4 end as priority,
COMMENTS as raw,
TRIM(REGEXP_REPLACE(substring(COMMENTS, CHARINDEX('Product ID: ', COMMENTS) + 12, 10), '[^[:digit:]]', '')) as product_id,
replace(TRIM(REGEXP_REPLACE(substring(COMMENTS, CHARINDEX('Product Price: ', COMMENTS) + 15, 10), '[^[:digit:]]', ' ')),' ','.') as product_price,
TRIM(REGEXP_REPLACE(substring(COMMENTS, CHARINDEX('Quantity: ', COMMENTS) + 10, 3), '[^[:digit:]]', '')) as quantity,
case when SPLIT_PART(commentS,'Comentário do usuário:',2) = ''
        then case when SPLIT_PART(commentS,'User comment:',2) = ''
            then SPLIT_PART(commentS,'Comentario de usuario:',2)
            else SPLIT_PART(commentS,'User comment:',2) end
        else SPLIT_PART(commentS,'Comentário do usuário:',2) end as comentario,
rappicreditos_real,
o.created_at
from orders o
inner join mx_PGLR_MS_PARTNER_PAYMENT_data.compensations c on c.order_id = o.id
)

,crossed as
(
select d.*,p.name as product_name,s.name as store_name,row_number() over (partition by order_id order by priority) as rownr
from details d
left join mx_grability_public.products p on d.product_id::text = p.id::text
left join mx_grability_public.stores s on s.store_id::text = d.store_id::text
)


select
paid_lot_id,
STORE_ID  ,

store_name as TIENDA  ,
created_at::varchar as FECHA ,
ORDER_ID  ,
case when reason = 'product_missing' then 'Pedido Incompleto'
when reason = 'product_difference' then 'Producto Diferente'
when reason = 'product_poor' then 'Producto Mal Estado'
when reason = 'product_not_delivered' then 'No llego pedido'
end as CATEGORIA ,
-- raw as DESCRIPTION ,
PRODUCT_NAME  ,
try_cast(PRODUCT_PRICE as float) as PRODUCT_PRICE ,
abs(RAPPICREDITOS_REAL) as RAPPICREDITOS_REAL,
comentario as comentario
from crossed
where rownr =1