import snowflake.connector
from snowflake.sqlalchemy import URL
from sqlalchemy import create_engine
import csv
import pandas as pd
import os
import csv
import datetime


country = 'CL-GROUP'


def send_bibr_infos(kissflow_data):
    try:
        con = snowflake.connector.connect(
            account = 'hg51401',
            user = 'yeison.consuegra@rappi.com',
            password = 'AlbanisSantiago12345_',
            database = 'FIVETRAN',
            schema = 'br_writable',
            warehouse = 'GROWTH'#,
           # role='RETAIL_CPG_ROLE'
        )
        cur = con.cursor()
        kissflow_data = [kissflow_data[i:i + 10000] for i in range(0, len(kissflow_data), 10000)]
        for kissflow_chunk in kissflow_data:
            cur.execute(('MERGE INTO {table_name} as Target '
                    "USING (SELECT DISTINCT COUNTRY,PAID_LOT_ID,last_value(URL) over (partition by PAID_LOT_ID,country order by GENERATED_UTC_AT asc) as URL,last_value(GENERATED_UTC_AT) over (partition by PAID_LOT_ID,country order by GENERATED_UTC_AT asc) as GENERATED_UTC_AT FROM "
                    "(VALUES {vals}) "
                    'AS s ({COUNTRY}, {PAID_LOT_ID}, {URL}, {GENERATED_UTC_AT}) '
                    ') AS Source '
                    'ON Target.COUNTRY = Source.COUNTRY and Target.PAID_LOT_ID = Source.PAID_LOT_ID '
                    'WHEN NOT MATCHED THEN '
                    'INSERT ({COUNTRY}, {PAID_LOT_ID}, {URL}, {GENERATED_UTC_AT}) VALUES (Source.{COUNTRY}, Source.{PAID_LOT_ID}, Source.{URL}, Source.{GENERATED_UTC_AT}) '
                    'WHEN MATCHED THEN '
                    'UPDATE SET {URL}=Source.{URL}, {GENERATED_UTC_AT}=Source.{GENERATED_UTC_AT};'
                    .format(table_name='BR_WRITABLE.partner_payment_reports',
                            vals=','.join([str(i) for i in kissflow_chunk]),
                            COUNTRY='COUNTRY',
                            PAID_LOT_ID='PAID_LOT_ID',
                            URL='URL',
                            GENERATED_UTC_AT='GENERATED_UTC_AT'
                            )))
        con.commit()
        cur.close()
    except Exception as e:
        print(e)

colnames = ['URL','PAID_LOT_ID','GENERATED_UTC_AT']
df = pd.read_csv("created.csv",sep=';',header=None)
df.columns = colnames
df['URL'] = 'https://drive.google.com/open?id=' + df['URL'].astype(str)
df['COUNTRY'] = country
df = df[['COUNTRY','PAID_LOT_ID','URL','GENERATED_UTC_AT']]
print(df.head())
tuples = [tuple(x) for x in df.values]
send_bibr_infos(tuples)
