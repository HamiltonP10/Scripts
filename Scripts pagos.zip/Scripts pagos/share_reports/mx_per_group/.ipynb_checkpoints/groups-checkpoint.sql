  -- select distinct g.group_name,pl.id as paid_lot_id
-- from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl
-- left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
-- left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.STORE_PAYMENT_REFERENCES st on st.payment_reference_id = pl.payment_reference_id and not st._fivetran_deleted
-- join br_writable.partner_payment_groups g on g.store_id = st.store_id and g.country = 'MX'
-- where not PL._FIVETRAN_DELETED 
--   and PAY_START_DATE>= '2020-08-03' 
--   and PAY_END_DATE  <= '2020-08-09'
--   and pl.status<>'CANCELED'
--   and g.store_id in (1923230195)
--  -- and g.group_name ilike '%donald%'
--  -- and st.is_marketplace = false


select distinct g.group_name,pl.id as paid_lot_id
from mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.PAID_LOTS pl
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.balance_requests br on br.id=pl.balance_request_id AND NOT br._FIVETRAN_DELETED
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.STORE_PAYMENT_REFERENCES pr on pr.payment_reference_id = pl.payment_reference_id and not pr._fivetran_deleted
left join mx_PGLR_MS_PARTNER_PAYMENT_PUBLIC.STORES st on st.store_id = pr.store_id and not st._fivetran_deleted
join br_writable.partner_payment_groups g on g.store_id = st.store_id and g.country = 'MX'
where not PL._FIVETRAN_DELETED
and PAY_START_DATE >='2021-07-19'
 and  PAY_END_DATE <='2021-07-25'
  and pl.status<>'CANCELED'
  and g.group_name ilike '%hut%'
  --or g.group_name not ilike '%baxter%')
  --and g.group_name ilike '%carl%'